from .oracle_db import OracleCRUD
from .postgre_db import PostgesCRUD

__all__ = ["OracleCRUD", "PostgesCRUD"]
