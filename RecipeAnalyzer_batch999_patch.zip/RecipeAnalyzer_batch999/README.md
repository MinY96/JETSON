# RecipeAnalyzer — FTP 수집 중 999건 단위 UPSERT 패치

대상: [MinY96/RecipeAnalyzer](https://github.com/MinY96/RecipeAnalyzer) `master` 브랜치의 `src/collectors/ftp/collector.py` (2026-10-26 확인본).

## 목적 및 동작

기존 `run.py`는 변경하지 않습니다. `collector.run()`이 장비를 순회하는 동안 **신규/수정 Recipe를 최대 999건만 메모리에 모아** 아래 순서로 처리합니다.

1. FTP에서 신규/변경 Recipe 탐색 및 파일 다운로드
2. `CollectionState.append(info)`로 `upserts`에 누적
3. `len(upserts) == 999`에 도달하면 `join_mes_info(upserts)` → `update_database(..., finalize=False)` 실행
4. DB UPSERT 성공 후 `upserts.clear()` → 동일 FTP 연결에서 계속 수집
5. 장비 전체 수집이 완료되면 마지막 잔여 배치를 저장
6. 장비 전체의 기존 키와 FTP에서 실제 발견한 키를 비교해 삭제를 판정
7. 유지 상태 초기화 및 `dm_update_history` 저장은 장비당 **마지막 1회** 실행
8. 이후 `run.py`의 기존 `recipe_parser.run()` 실행

`KLA2139`, `KLA2365`, `PUMA` 모두 적용되며, `KLA2365`/`PUMA`의 Device → Layer 구조 내에서도 동일한 상태 객체를 공유하므로 중간 누적 리스트는 생성하지 않습니다.

## 적용 명령어

저장소를 로컬 PC에 받아 놓은 상태에서 실행합니다.

```powershell
cd C:\path\to\RecipeAnalyzer
python C:\path\to\apply_recipe_batching.py .\src\collectors\ftp\collector.py
python -m compileall -q .\src\collectors\ftp\collector.py
python run.py
```

`apply_recipe_batching.py`는 해당 파일의 기존 코드를 현재 GitHub 버전에 맞게 수정합니다. 실행 전 **같은 폴더에 `collector.py.bak`** 백업 파일을 자동 생성합니다. 원본과 함수 구조가 달라진 경우 수정 작업을 중단하며, 이미 적용된 코드에 중복 적용하지 않습니다.

복원하려면 `collector.py.bak` 파일을 `collector.py`로 되돌립니다.

## 테스트

```powershell
python test_batching.py
```

DB/FTP 연결 없는 단위 테스트 6개:

- 0/998/999/1000/1998/2000건 배치 크기
- 저장 실패 시 999건 버퍼 보존
- 빈 배치는 DB 호출하지 않음
- `update_database(finalize=False)`에서는 이력/삭제 UPDATE 하지 않음
- 삭제/유지 Recipe SQL `ANY(%s)` 분할 처리
- 수집 마지막에 잔여 배치 및 최종 삭제 판정
- 패치 코드 AST 구문 유효성, 이중 적용 거부

**제한:** 테스트는 모의 객체 기반으로만 수행했습니다. 실제 FTP, Oracle MES 조회, PostgreSQL UPSERT 및 파싱 후속 작업은 운영 전 스테이징에서 별도로 검증해야 합니다.

## 안전성/유의사항

- FTP에서 발견한 Recipe는 다운로드 실패 시에도 `seen_keys`에 포함되어 단순 다운로드 실패 때문에 삭제 처리되지 않습니다.
- 폴더 조회 중 예외가 발생하면 수집 예외를 상위로 전파해 최종 삭제/집계 단계로 진입하지 않습니다.
- DB 저장에 실패하면 현재 999건 버퍼는 비우지 않으며 예외를 상위로 전파합니다.
- FTP 수집 결과 0건인데 DB에 기존 데이터가 있다면 전체 삭제로 처리하지 않고 예외를 발생시킵니다.
- 삭제·유지 SQL은 `recipe_key = ANY(%s)`로 값을 바인딩합니다. 삭제와 유지도 한 번에 최대 999개 키씩 갱신합니다.
- 이미 성공적으로 완료된 배치는 이전 트랜잭션에서 저장되므로 **장비 전체를 원자적 트랜잭션으로 처리하지는 않습니다.**
- `run.py`가 모든 장비 수집 후 파싱하므로, 수집 중단 후 다음 실행의 `status` 초기화가 아직 파싱되지 않은 데이터를 놓칠 수 있습니다. 운영에서는 재실행/파싱 재처리 정책을 별도로 검증하는 것이 좋습니다.
- `ftp_download_tree` 내부에서 파일 다운로드 실패를 자체적으로 출력하고 삼키는 경로는 기존대로 유지했습니다. 업무상 `ins.dat`/`Sensitivity1.xml`이 필수라면 해당 파일 확인 후 UPSERT하도록 추가 보완하는 것이 안전합니다.
- FTP 세션을 유지한 채 Oracle/PostgreSQL에 접속하므로 MES/DB 작업이 장시간 걸릴 경우 FTP 유휴 연결 종료 여부를 확인해야 합니다.

## 변경되는 원본 함수

`move_layer_folder`, `move_device_folder`, `collect_kla2139`, `collect_kla2365`, `collect_puma`, `update_database`, `collect_equip_data`.

신규 추가: `UPSERT_BATCH_SIZE = 999`, `CollectionState`.

`join_mes_info`, `run.py`, `worker.py`, 데이터베이스 CRUD 모듈은 변경하지 않습니다.
