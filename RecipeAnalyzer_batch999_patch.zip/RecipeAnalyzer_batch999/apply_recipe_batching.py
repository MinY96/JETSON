#!/usr/bin/env python3
"""Patch RecipeAnalyzer/master src/collectors/ftp/collector.py for streaming upserts.

Usage: python apply_recipe_batching.py /path/to/RecipeAnalyzer/src/collectors/ftp/collector.py
Makes a .py.bak copy before writing. Fails closed for unexpected source layouts.
"""
from __future__ import annotations

import ast
from pathlib import Path
import re
import shutil
import sys
import textwrap


BUFFER_CLASS = r'''
UPSERT_BATCH_SIZE = 999


@dataclass
class CollectionState:
    """장비 단위 공유 상태. upserts는 최대 999건만 누적한다."""

    equip: Equipment
    batch_size: int = UPSERT_BATCH_SIZE
    upserts: list[dict[str, Any]] = field(default_factory=list)
    seen_keys: set[str] = field(default_factory=set)
    unchanged_keys: set[str] = field(default_factory=set)
    new_cnt: int = 0
    update_cnt: int = 0

    def __post_init__(self) -> None:
        if not 1 <= self.batch_size <= UPSERT_BATCH_SIZE:
            raise ValueError("batch_size must be between 1 and 999")

    def append(self, recipe_info: dict[str, Any]) -> None:
        self.upserts.append(recipe_info)
        if len(self.upserts) >= self.batch_size:
            self.flush()

    def flush(self) -> None:
        """MES 조회 및 DB 저장 성공 시에만 버퍼를 비운다."""
        if not self.upserts:
            return
        enriched = join_mes_info(self.upserts)
        update_database(self.equip, enriched, [], [], finalize=False)
        # Update 실패 시 위 호출에서 예외가 발생하므로 데이터와 카운터는 그대로 남음.
        self.new_cnt += sum(item["status"] == "new" for item in self.upserts)
        self.update_cnt += sum(item["status"] == "update" for item in self.upserts)
        print(
            f"[{self.equip.name}] {len(self.upserts):,}건 UPSERT 완료 "
            f"(누적 신규 {self.new_cnt:,} / 수정 {self.update_cnt:,})"
        )
        self.upserts.clear()
'''


REPLACEMENTS = {
"move_layer_folder": r'''
def move_layer_folder(
    ftp: FTP,
    device: str,
    layer: str,
    equip: Equipment,
    equip_dir: Path,
    equip_db: pd.DataFrame,
    state: CollectionState,
) -> None:
    """Layer 하위 Recipe를 수집하며 동일한 upsert 버퍼를 사용한다."""
    current = ftp.pwd()
    try:
        ftp.cwd(layer)
        lines = collect_lines(ftp)
        recipes = (
            transform_recipe_info(line, equip, equip_dir, "Sensitivity1.xml")
            for line in lines
            if is_recipe_kla2365(line, device, layer)
        )
        for (
            rcp_key, _, total_layer, recipe, edit_time,
            backup_recipe_dir, backup_recipe_path,
        ) in recipes:
            # 다운로드 실패 시에도 FTP에 실제 존재하는 키는 삭제 대상에서 제외.
            state.seen_keys.add(rcp_key)
            is_upsert, file_status = is_file_update(
                equip_db, rcp_key, edit_time, backup_recipe_path
            )
            if not is_upsert:
                state.unchanged_keys.add(rcp_key)
                continue
            try:
                backup_recipe_dir.mkdir(parents=True, exist_ok=True)
                ftp_download_tree(ftp, recipe, backup_recipe_dir)
                backup_time = (
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    if backup_recipe_path.exists() else None
                )
            except Exception as exc:
                print(f"[{equip.name}] FTP 다운로드 실패 ({recipe}): {exc}")
                # 기존 장비별 복구 동작과 동일한 위치로 되돌린다.
                ftp.cwd(current)
                ftp.cwd(layer)
                continue
            # 중요: DB 오류를 위 다운로드 except가 삼키지 않도록 try 바깥에서 호출.
            state.append({
                "recipe_key": rcp_key,
                "model": equip.model,
                "equip": equip.name,
                "device": device,
                "layer": total_layer,
                "level": total_layer[:4],
                "recipe": recipe,
                "folder_path": f"{equip.ftp_info.remote_directory}/{recipe}",
                "file_path": f"{equip.ftp_info.remote_directory}/{recipe}/Sensitivity1.xml",
                "dt_edit_time": edit_time,
                "backup_folder_path": f"/{equip.name}/{recipe}",
                "backup_file_path": f"/{equip.name}/{recipe}/Sensitivity1.xml",
                "dt_backup": backup_time,
                "status": file_status,
            })
    finally:
        ftp.cwd(current)
''',
"move_device_folder": r'''
def move_device_folder(
    ftp: FTP,
    device: str,
    equip: Equipment,
    equip_dir: Path,
    equip_db: pd.DataFrame,
    state: CollectionState,
) -> None:
    """Device 안의 여러 Layer를 방문하되 중간 리스트를 생성하지 않는다."""
    current = ftp.pwd()
    try:
        ftp.cwd(device)
        lines = collect_lines(ftp)
        layers = [transform_folder(line) for line in lines if is_layer(line)]
        for layer in layers:
            move_layer_folder(ftp, device, layer, equip, equip_dir, equip_db, state)
    finally:
        ftp.cwd(current)
''',
"collect_kla2139": r'''
def collect_kla2139(
    equip: Equipment, equip_dir: Path, equip_db: pd.DataFrame,
    state: CollectionState,
) -> None:
    """KLA2139: 단일 Recipe 폴더 목록 순회 중 999건마다 UPSERT."""
    with FTP(
        timeout=equip.ftp_info.timeout_seconds, encoding=equip.ftp_info.encoding
    ) as ftp:
        ftp.connect(host=equip.ftp_info.host, port=equip.ftp_info.port)
        ftp.login(equip.ftp_info.username, equip.ftp_info.password)
        ftp.cwd(equip.ftp_info.remote_directory)
        lines = collect_lines(ftp)
        recipes = (
            transform_recipe_info(line, equip, equip_dir)
            for line in lines if is_recipe(line)
        )
        for (
            rcp_key, device, layer, recipe, edit_time,
            backup_recipe_dir, backup_recipe_path,
        ) in recipes:
            state.seen_keys.add(rcp_key)
            is_upsert, file_status = is_file_update(
                equip_db, rcp_key, edit_time, backup_recipe_path
            )
            if not is_upsert:
                state.unchanged_keys.add(rcp_key)
                continue
            try:
                backup_recipe_dir.mkdir(parents=True, exist_ok=True)
                ftp_download_tree(ftp, recipe, backup_recipe_dir)
                backup_time = (
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    if backup_recipe_path.exists() else None
                )
            except Exception as exc:
                print(f"[{equip.name}] FTP 다운로드 실패 ({recipe}): {exc}")
                ftp.cwd(equip.ftp_info.remote_directory)
                continue
            # 부분 DB UPSERT 오류는 상위 호출자로 전파되어 최종 삭제 정산 중단.
            state.append({
                "recipe_key": rcp_key,
                "model": equip.model,
                "equip": equip.name,
                "device": device,
                "layer": layer,
                "level": layer[:4],
                "recipe": recipe,
                "folder_path": f"{equip.ftp_info.remote_directory}/{recipe}",
                "file_path": f"{equip.ftp_info.remote_directory}/{recipe}/ins.dat",
                "dt_edit_time": edit_time,
                "backup_folder_path": f"/{equip.name}/{recipe}",
                "backup_file_path": f"/{equip.name}/{recipe}/ins.dat",
                "dt_backup": backup_time,
                "status": file_status,
            })
''',
"collect_kla2365": r'''
def collect_kla2365(
    equip: Equipment, equip_dir: Path, equip_db: pd.DataFrame,
    state: CollectionState,
) -> None:
    """KLA2365: Device → Layer → Recipe 간 버퍼 공유."""
    with FTP(
        timeout=equip.ftp_info.timeout_seconds, encoding=equip.ftp_info.encoding
    ) as ftp:
        ftp.connect(host=equip.ftp_info.host, port=equip.ftp_info.port)
        ftp.login(equip.ftp_info.username, equip.ftp_info.password)
        lines = collect_lines(ftp)
        devices = [transform_folder(line) for line in lines if is_device(line)]
        for device in devices:
            move_device_folder(ftp, device, equip, equip_dir, equip_db, state)
''',
"collect_puma": r'''
def collect_puma(
    equip: Equipment, equip_dir: Path, equip_db: pd.DataFrame,
    state: CollectionState,
) -> None:
    """PUMA: Device → Layer → Recipe 간 버퍼 공유."""
    with FTP(
        timeout=equip.ftp_info.timeout_seconds, encoding=equip.ftp_info.encoding
    ) as ftp:
        ftp.connect(host=equip.ftp_info.host, port=equip.ftp_info.port)
        ftp.login(equip.ftp_info.username, equip.ftp_info.password)
        lines = collect_lines(ftp)
        devices = [transform_folder(line) for line in lines if is_device(line)]
        for device in devices:
            move_device_folder(ftp, device, equip, equip_dir, equip_db, state)
''',
"update_database": r'''
def update_database(
    equip: Equipment,
    upserts: pd.DataFrame,
    remove_keys: List[str],
    unchange_keys: List[str],
    *,
    finalize: bool = True,
    new_cnt: int | None = None,
    update_cnt: int | None = None,
) -> None:
    """부분 UPSERT는 매 배치, 삭제/유지/집계는 장비 끝에서 한 번만."""
    if not upserts.empty:
        PostgresCRUD.upsert("dm_recipe_info", "dm_recipe_info_pkey", upserts)

    if not finalize:
        return

    # 안전한 파라미터 바인딩 및 여러 번에 나누어 UPDATE.
    for start in range(0, len(remove_keys), UPSERT_BATCH_SIZE):
        keys = remove_keys[start : start + UPSERT_BATCH_SIZE]
        PostgresCRUD.execute(
            """
            UPDATE dm_recipe_info
            SET is_remove = true, status = 'remove'
            WHERE equip = %s AND recipe_key = ANY(%s)
            """,
            (equip.name, keys),
        )

    for start in range(0, len(unchange_keys), UPSERT_BATCH_SIZE):
        keys = unchange_keys[start : start + UPSERT_BATCH_SIZE]
        PostgresCRUD.execute(
            """
            UPDATE dm_recipe_info
            SET status = null
            WHERE equip = %s AND recipe_key = ANY(%s)
            """,
            (equip.name, keys),
        )

    if new_cnt is None or update_cnt is None:
        counts = (
            upserts["status"].value_counts()
            if "status" in upserts.columns else pd.Series(dtype=int)
        )
        if new_cnt is None:
            new_cnt = int(counts.get("new", 0))
        if update_cnt is None:
            update_cnt = int(counts.get("update", 0))

    PostgresCRUD.upsert(
        "dm_update_history",
        "dm_update_history_pkey",
        pd.DataFrame([{
            "model": equip.model,
            "equip": equip.name,
            "new_rcp": new_cnt,
            "update_rcp": update_cnt,
            "remove_rcp": len(remove_keys),
            "aggregation_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }]),
    )
    print(
        f"신규: {new_cnt:,}개, 수정: {update_cnt:,}개, "
        f"삭제: {len(remove_keys):,}개, 유지: {len(unchange_keys):,}개"
    )
''',
"collect_equip_data": r'''
def collect_equip_data(equip: Equipment, equip_dir: Path) -> None:
    """장비 단위 수집: 999건 단위 저장 + 수집 완료 후 삭제/이력 정산."""
    equip_db = PostgresCRUD.select_query(
        """
        SELECT recipe_key, dt_edit_time, device, layer, recipe, backup_file_path
        FROM dm_recipe_info
        WHERE equip = %s
            AND is_remove=false""",
        (equip.name,),
    )
    state = CollectionState(equip=equip)
    match equip.model:
        case "KLA2139":
            collect_kla2139(equip, equip_dir, equip_db, state)
        case "KLA2365":
            collect_kla2365(equip, equip_dir, equip_db, state)
        case "PUMA":
            collect_puma(equip, equip_dir, equip_db, state)
        case _:
            raise ValueError(f"지원하지 않는 장비 모델: {equip.model}")

    # 999건 미만으로 남은 마지막 배치 처리.
    state.flush()

    old_keys = set(equip_db["recipe_key"])
    # FTP 빈 목록이 일시적 오류인 경우 대량 오삭제를 막기 위한 방어.
    if old_keys and not state.seen_keys:
        raise RuntimeError(
            f"[{equip.name}] FTP 수집 Recipe가 0건입니다. "
            "일괄 삭제 오판 방지를 위해 최종 삭제/이력 정산을 중단합니다."
        )
    remove_keys = list(old_keys - state.seen_keys)
    update_database(
        equip,
        pd.DataFrame(columns=["status"]),
        remove_keys,
        list(state.unchanged_keys),
        new_cnt=state.new_cnt,
        update_cnt=state.update_cnt,
    )
''',
}


def replace_top_level_function(source: str, name: str, replacement: str) -> str:
    pattern = re.compile(
        rf"^def {re.escape(name)}\([\s\S]*?(?=^def |^class |^@dataclass|\Z)",
        re.MULTILINE,
    )
    patched, matches = pattern.subn(lambda _: textwrap.dedent(replacement).strip() + "\n\n", source)
    if matches != 1:
        raise ValueError(f"Expected exactly one {name} function, found {matches}")
    return patched


def make_patch(source: str) -> str:
    if "class CollectionState" in source:
        raise ValueError("Already patched: CollectionState exists")
    anchor = "from typing import Any, Dict, List, Tuple\n"
    if source.count(anchor) != 1:
        raise ValueError("Source changed: expected typing import line was not found")
    source = source.replace(anchor, anchor + "from dataclasses import dataclass, field\n", 1)
    for name, replacement in REPLACEMENTS.items():
        source = replace_top_level_function(source, name, replacement)
    anchor = "def move_layer_folder("
    if source.count(anchor) != 1:
        raise ValueError("Source changed: move_layer_folder location was not unique")
    source = source.replace(anchor, textwrap.dedent(BUFFER_CLASS).strip() + "\n\n\n" + anchor, 1)
    ast.parse(source)
    for expected in ("class Collector:", "def join_mes_info(", "def parse_edit_time("):
        if source.count(expected) != 1:
            raise ValueError(f"Unexpected module structure: {expected}")
    return source


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python apply_recipe_batching.py path/to/src/collectors/ftp/collector.py")
    target = Path(sys.argv[1])
    if not target.is_file() or target.name != "collector.py":
        raise SystemExit("Target must be an existing collector.py")
    original = target.read_text(encoding="utf-8")
    modified = make_patch(original)
    backup = target.with_name("collector.py.bak")
    if backup.exists():
        raise SystemExit(f"Backup already exists; refusing to overwrite: {backup}")
    shutil.copy2(target, backup)
    target.write_text(modified, encoding="utf-8")
    print(f"Patched: {target}\nOriginal backup: {backup}")


if __name__ == "__main__":
    main()
