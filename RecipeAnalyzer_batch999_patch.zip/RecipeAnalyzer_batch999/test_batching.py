"""Self-contained tests for batch helper and patch compatibility (no FTP/DB required)."""
from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path
import sys
from types import SimpleNamespace
from typing import Any
import unittest
from unittest.mock import Mock

sys.path.insert(0, str(Path(__file__).parent))
from apply_recipe_batching import BUFFER_CLASS, REPLACEMENTS, make_patch


class BufferTests(unittest.TestCase):
    def make_state(self):
        upserts = []
        joined = []

        def join_mes_info(batch):
            joined.append(len(batch))
            return list(batch)

        def update_database(equip, dataframe, remove_keys, unchanged_keys, *, finalize):
            self.assertEqual(equip.name, "EQ1")
            self.assertFalse(finalize)
            self.assertEqual(remove_keys, [])
            self.assertEqual(unchanged_keys, [])
            upserts.append(len(dataframe))

        ns = {
            "dataclass": dataclass,
            "field": field,
            "Any": Any,
            "Equipment": SimpleNamespace,
            "join_mes_info": join_mes_info,
            "update_database": update_database,
        }
        exec(compile(BUFFER_CLASS, "<buffer>", "exec"), ns)
        return ns["CollectionState"](equip=SimpleNamespace(name="EQ1")), joined, upserts, ns

    def test_batch_sizes(self):
        for count, expected in (
            (0, []), (998, [998]), (999, [999]),
            (1000, [999, 1]), (1998, [999, 999]),
            (2000, [999, 999, 2]),
        ):
            with self.subTest(count=count):
                state, joined, upserts, _ = self.make_state()
                for i in range(count):
                    state.append({"recipe_key": str(i), "status": "new" if i % 2 == 0 else "update"})
                    self.assertLessEqual(len(state.upserts), 999)
                state.flush()
                self.assertEqual(joined, expected)
                self.assertEqual(upserts, expected)
                self.assertEqual(state.upserts, [])
                self.assertEqual(state.new_cnt, (count + 1) // 2)
                self.assertEqual(state.update_cnt, count // 2)

    def test_failed_save_keeps_batch(self):
        state, _, _, ns = self.make_state()
        def fail(*args, **kwargs):
            raise RuntimeError("db down")
        ns["update_database"] = fail
        for i in range(998):
            state.append({"recipe_key": str(i), "status": "new"})
        with self.assertRaisesRegex(RuntimeError, "db down"):
            state.append({"recipe_key": "998", "status": "new"})
        self.assertEqual(len(state.upserts), 999)
        self.assertEqual(state.new_cnt, 0)

    def test_empty_flush(self):
        state, joined, saved, _ = self.make_state()
        state.flush()
        self.assertEqual(joined, [])
        self.assertEqual(saved, [])


    def test_finalization_history_once_and_chunked_updates(self):
        from datetime import datetime
        import pandas as pd
        crud = SimpleNamespace(upsert=Mock(), execute=Mock())
        ns = {
            "Equipment": SimpleNamespace, "pd": pd, "PostgresCRUD": crud,
            "datetime": datetime, "UPSERT_BATCH_SIZE": 999,
            "List": list,
        }
        exec(compile(REPLACEMENTS["update_database"], "<update_database>", "exec"), ns)
        update = ns["update_database"]
        equip = SimpleNamespace(name="EQ1", model="KLA2139")
        update(equip, pd.DataFrame([{"status": "new"}]), [], [], finalize=False)
        self.assertEqual(crud.upsert.call_count, 1)
        self.assertEqual(crud.execute.call_count, 0)

        update(equip, pd.DataFrame(columns=["status"]),
               [f"removed{i}" for i in range(1500)],
               [f"same{i}" for i in range(2000)],
               new_cnt=2000, update_cnt=3)
        self.assertEqual(crud.execute.call_count, 5)  # 2 delete + 3 unchanged
        self.assertEqual(crud.upsert.call_count, 2)
        self.assertEqual(crud.upsert.call_args.args[0], "dm_update_history")
        history = crud.upsert.call_args.args[2]
        self.assertEqual(int(history.iloc[0]["new_rcp"]), 2000)
        self.assertEqual(int(history.iloc[0]["update_rcp"]), 3)
        self.assertEqual(int(history.iloc[0]["remove_rcp"]), 1500)
        for call in crud.execute.call_args_list:
            params = call.args[1]
            self.assertEqual(params[0], "EQ1")
            self.assertLessEqual(len(params[1]), 999)

    def test_collect_finalization_after_ftp(self):
        import pandas as pd
        crud = SimpleNamespace(select_query=Mock(return_value=pd.DataFrame({"recipe_key": ["old", "unchanged"]})))
        records = []
        def fake_ftp_collector(equip, equip_dir, equip_db, state):
            state.seen_keys.add("unchanged")
            state.unchanged_keys.add("unchanged")
            for i in range(1000):
                state.seen_keys.add(f"rcp{i}")
                state.append({"recipe_key": f"rcp{i}", "status": "new"})
        def fake_update(equip, dataframe, removed, unchanged, **kwargs):
            records.append((len(dataframe), removed, unchanged, kwargs))
        ns = {
            "Equipment": SimpleNamespace, "Path": Path, "PostgresCRUD": crud,
            "pd": pd, "CollectionState": lambda equip: self.make_state()[0],
            "collect_kla2139": fake_ftp_collector,
            "collect_kla2365": fake_ftp_collector,
            "collect_puma": fake_ftp_collector,
            "update_database": fake_update,
        }
        # mock CollectionState separately: bind update_database in its compiled globals
        state, _, _, state_ns = self.make_state()
        state_ns["update_database"] = fake_update
        ns["CollectionState"] = lambda equip: state
        exec(compile(REPLACEMENTS["collect_equip_data"], "<collect_equip_data>", "exec"), ns)
        ns["collect_equip_data"](SimpleNamespace(name="EQ1", model="KLA2139"), Path("."))
        self.assertEqual([row[0] for row in records], [999, 1, 0])
        self.assertEqual(records[-1][1], ["old"])
        self.assertEqual(records[-1][2], ["unchanged"])
        self.assertEqual(records[-1][3]["new_cnt"], 1000)



class PatcherTests(unittest.TestCase):
    def test_patch_syntax_and_target_names(self):
        stub = "from typing import Any, Dict, List, Tuple\n\n"
        stub += "def parse_edit_time(line):\n    return line\n\n"
        for name in REPLACEMENTS:
            stub += f"def {name}():\n    pass\n\n"
        stub += "def join_mes_info(upserts):\n    return upserts\n\n"
        stub += "class Collector:\n    pass\n"
        patched = make_patch(stub)
        ast.parse(patched)
        self.assertIn("class CollectionState", patched)
        self.assertIn('finalize=False', patched)
        with self.assertRaisesRegex(ValueError, "Already patched"):
            make_patch(patched)


if __name__ == "__main__":
    unittest.main()
