from pathlib import Path

from pydantic import Field

from src.schemas.base import BaseSchema


class ApiSettings(BaseSchema):
    api_prefix: str = "/api/v1"

    recipe_store_dir: Path = Path(".image_processing_data/recipes")
    label_store_dir: Path = Path(".image_processing_data/labels")
    test_dataset_store_dir: Path = Path(".image_processing_data/test_datasets")
    evaluation_store_dir: Path = Path(".image_processing_data/evaluations")
    evaluation_checkpoint_interval: int = Field(default=50, ge=1, le=10_000)
    evaluation_worker_count: int = Field(default=1, ge=1, le=4)
    synthetic_asset_store_dir: Path = Path(".image_processing_data/synthetic/assets")
    synthetic_diffusion_cache_dir: Path = Path(".image_processing_data/models/diffusion")
    synthetic_diffusion_local_files_only: bool = True
    synthetic_diffusion_device: str = Field(default="cuda", min_length=1, max_length=64)
    max_synthetic_candidates: int = Field(default=16, ge=1, le=64)

    max_test_dataset_images: int = Field(default=100_000, ge=1, le=1_000_000)

    max_upload_files: int = Field(default=8, ge=1, le=64)
    max_upload_bytes_per_file: int = Field(
        default=25 * 1024 * 1024,
        ge=1024,
    )
    max_image_pixels: int = Field(
        default=64_000_000,
        ge=1,
    )
    max_total_decoded_bytes: int = Field(
        default=512 * 1024 * 1024,
        ge=1024,
    )
    max_json_binary_bytes: int = Field(
        default=32 * 1024 * 1024,
        ge=1024,
    )
    max_zip_binary_bytes: int = Field(
        default=128 * 1024 * 1024,
        ge=1024,
    )
    max_inline_array_items: int = Field(
        default=100_000,
        ge=1,
    )
