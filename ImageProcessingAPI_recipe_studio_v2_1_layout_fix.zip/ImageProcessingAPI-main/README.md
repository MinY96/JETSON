# Image Processing Studio

OpenCV 기반 Image Processing API와 React 기반 Visual Studio UI를 하나의 저장소에서 관리하는 프로젝트입니다.

## Repository structure

```text
ImageProcessingAPI/
├─ backend/      # Python / FastAPI / OpenCV processing engine
├─ frontend/     # React / TypeScript / Vite UI
├─ .gitignore
└─ README.md
```

## Backend

```powershell
cd backend
.\.venv\Scripts\Activate.ps1
python -m pytest -q
```

Backend 상세 내용은 [`backend/README.md`](backend/README.md)를 참고하세요.

## Frontend

```powershell
cd frontend
npm install
npm run dev
```

Frontend 상세 내용은 [`frontend/README.md`](frontend/README.md)를 참고하세요.

## Development URLs

```text
Frontend  http://localhost:5173
Backend   http://localhost:8000
Swagger   http://localhost:8000/docs
```

Frontend Vite dev server는 `/api` 요청을 Backend `localhost:8000`으로 proxy합니다.

## Main UI

- Recipe Studio
- Image Lab
- Synthetic NG Generator
- Dataset / Annotation
- Evaluation Job Queue
- Settings / Model Registry
