"""Mock-based v2 tests: no running database required (drivers still required)."""
from contextlib import contextmanager
from types import SimpleNamespace

import pandas as pd
import pytest

from database import OracleCRUD, PostgesCRUD
import database.oracle_db as oracle_module
import database.postgre_db as postgre_module


class FakeOracleCursor:
    description = [("EQUIP_ID",), ("RECIPE_NAME",)]

    def __init__(self, recorded):
        self.recorded = recorded
        self.arraysize = 0
        self.prefetchrows = 0

    def execute(self, sql, params=None):
        self.recorded.append((sql, params))

    def fetchall(self):
        return [("A301", "R001")]


class FakePgCursor:
    description = [SimpleNamespace(name="equip_id"), SimpleNamespace(name="recipe_name")]
    rowcount = 2

    def __init__(self, recorded):
        self.recorded = recorded

    def mogrify(self, query, params=None):
        self.recorded.append(("mogrify", query, params))
        # Encodes the effect of binding a single string into the base query.
        return query.replace("%s", "'PHOTO'").encode("utf-8")


@contextmanager
def fake_pg_transaction(recorded):
    yield SimpleNamespace(encoding="UTF8"), FakePgCursor(recorded)


@pytest.fixture
def pg_mock(monkeypatch):
    recorded = []
    monkeypatch.setattr(postgre_module, "transaction", lambda: fake_pg_transaction(recorded))

    def fake_execute_values(cursor, sql_text, values, **kwargs):
        recorded.append(("execute_values", sql_text, values, kwargs))
        return [("A301", "R001")]

    monkeypatch.setattr(postgre_module, "execute_values", fake_execute_values)
    return recorded


@pytest.fixture
def oracle_mock(monkeypatch):
    recorded = []

    @contextmanager
    def fake_cursor_scope():
        yield FakeOracleCursor(recorded)

    monkeypatch.setattr(oracle_module, "cursor_scope", fake_cursor_scope)
    return recorded


def test_postgresql_conditions_exists_values_and_batch(pg_mock):
    conditions = [{"equip_id": f"A{i}", "recipe_name": f"R{i}"} for i in range(5)]
    conditions.append(dict(conditions[0]))  # repeated tuple must not be queried twice
    result = PostgesCRUD.select_query_by_conditions(
        "SELECT equip_id, recipe_name FROM recipe_info WHERE area = %s",
        conditions,
        params=("PHOTO",),
        batch_size=2,
    )
    calls = [row for row in pg_mock if row[0] == "execute_values"]
    assert len(calls) == 3
    assert sum(len(row[2]) for row in calls) == 5
    assert all("WHERE EXISTS" in row[1] for row in calls)
    assert all("IS NOT DISTINCT FROM" in row[1] for row in calls)
    assert all("'PHOTO'" in row[1] for row in calls)
    assert result.shape == (3, 2)


def test_pg_all_null_and_percent_literal(pg_mock):
    PostgesCRUD.select_query_by_conditions(
        "SELECT equip_id, recipe_name FROM recipe_info WHERE recipe_name LIKE '%X%'",
        [{"equip_id": None, "recipe_name": "A"}],
    )
    sql_text = [row[1] for row in pg_mock if row[0] == "execute_values"][0]
    assert 'src."equip_id" IS NULL' in sql_text
    assert "%%X%%" in sql_text  # escaped for execute_values, then decoded by it


def test_oracle_bind_and_null_and_batch(oracle_mock):
    conditions = [
        {"equip_id": "A301", "recipe_name": "R001"},
        {"equip_id": "A302", "recipe_name": None},
        {"equip_id": "A301", "recipe_name": "R001"},
        {"equip_id": "BE03", "recipe_name": "R003"},
    ]
    frame = OracleCRUD.select_query_by_conditions(
        "SELECT EQUIP_ID, RECIPE_NAME FROM RECIPE_INFO WHERE AREA = :area",
        conditions,
        params={"area": "PHOTO"},
        batch_size=2,
    )
    assert len(oracle_mock) == 2
    assert ":cnd_0_0" in oracle_mock[0][0]
    assert "src.recipe_name IS NULL" in oracle_mock[0][0]
    assert oracle_mock[0][1]["area"] == "PHOTO"
    assert frame.shape == (2, 2)
    assert frame.columns.tolist() == ["equip_id", "recipe_name"]


@pytest.mark.parametrize("crud", [OracleCRUD, PostgesCRUD])
def test_empty_conditions(crud):
    result = crud.select_query_by_conditions("SELECT * FROM recipe_info", [])
    assert isinstance(result, pd.DataFrame) and result.empty


@pytest.mark.parametrize("crud", [OracleCRUD, PostgesCRUD])
def test_mismatched_keys(crud):
    with pytest.raises(ValueError, match="same keys"):
        crud.select_query_by_conditions(
            "SELECT * FROM recipe_info",
            [{"equip_id": "A301"}, {"recipe_name": "R001"}],
        )


def test_oracle_rejects_unsafe_column():
    with pytest.raises(ValueError, match="Oracle condition columns"):
        OracleCRUD.select_query_by_conditions(
            "SELECT * FROM recipe_info", [{"equip_id; DROP TABLE x": "A301"}]
        )


def test_batch_size_validation():
    with pytest.raises(ValueError, match="batch_size"):
        PostgesCRUD.select_query_by_conditions("SELECT * FROM t", [{}], batch_size=0)
    with pytest.raises(ValueError, match="batch_size"):
        OracleCRUD.select_query_by_conditions("SELECT * FROM t", [{}], batch_size=0)
