"""Driver-independent tests of the real upsert AST; needs only pandas, numpy and pytest.

Uses a minimal SQL/transaction stand-in because Oracle/Postgres clients and a
running database are not available in all development environments.
"""
import ast
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest


class SQLText:
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return self.value

    def format(self, *parts):
        return SQLText(self.value.format(*(str(x) for x in parts)))

    def join(self, parts):
        return SQLText(self.value.join(map(str, parts)))

    def as_string(self, connection):
        return self.value


class Identifier(SQLText):
    def __init__(self, *parts):
        super().__init__(".".join('"' + part.replace('"', '""') + '"' for part in parts))


@pytest.fixture
def upsert_harness():
    source = (Path(__file__).resolve().parents[1] / "database" / "postgre_db.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    helpers = [item for item in tree.body if isinstance(item, ast.FunctionDef) and item.name in ("_table_identifier", "_db_value")]
    db_class = next(item for item in tree.body if isinstance(item, ast.ClassDef) and item.name == "PostgesCRUD")
    upsert = next(item for item in db_class.body if isinstance(item, ast.FunctionDef) and item.name == "upsert")
    # Compile unchanged production method in isolation without importing DB drivers.
    module = ast.Module(body=helpers + [ast.ClassDef(name="PostgesCRUD", bases=[], keywords=[], body=[upsert], decorator_list=[])], type_ignores=[])
    ast.fix_missing_locations(module)
    calls = []
    cursor = SimpleNamespace(rowcount=0)

    def execute(query, params):
        calls.append(("catalog", query, params))

    def fetchall():
        return [("equip_id", False), ("recipe_name", False)]

    cursor.execute = execute
    cursor.fetchall = fetchall
    conn = SimpleNamespace()

    @contextmanager
    def transaction():
        calls.append(("begin",))
        try:
            yield conn, cursor
        except Exception:
            calls.append(("rollback",))
            raise
        else:
            calls.append(("commit",))

    def execute_values(cursor, statement, values, page_size):
        calls.append(("execute_values", statement, values, page_size))
        cursor.rowcount = len(values)

    ns = dict(
        Any=object, pd=pd, np=np,
        sql=SimpleNamespace(SQL=SQLText, Identifier=Identifier),
        transaction=transaction, execute_values=execute_values,
    )
    exec(compile(module, "database/postgre_db.py", "exec"), ns)
    return ns["PostgesCRUD"], calls


def test_upsert_chunks_deduplicates_and_updates_nonkeys(upsert_harness):
    cls, calls = upsert_harness
    df = pd.DataFrame([
        {"equip_id": "A301", "recipe_name": "R001", "value": 1},
        {"equip_id": "A301", "recipe_name": "R001", "value": 2},
        {"equip_id": "BE03", "recipe_name": "R002", "value": 3},
        {"equip_id": "A302", "recipe_name": "R003", "value": 4},
        {"equip_id": "A303", "recipe_name": "R004", "value": 5},
    ])
    affected = cls.upsert("public.recipe_info", "recipe_info_key", df, chunk_size=2)
    pages = [x for x in calls if x[0] == "execute_values"]
    assert len(pages) == 3
    assert affected == 4  # first chunk keeps last of duplicate key
    assert pages[0][2] == [("A301", "R001", 2)]
    assert 'INSERT INTO "public"."recipe_info"' in pages[0][1]
    assert 'ON CONFLICT ON CONSTRAINT "recipe_info_key" DO UPDATE SET "value" = EXCLUDED."value"' in pages[0][1]
    assert calls[-1] == ("commit",)


def test_upsert_nullable_and_key_only(upsert_harness):
    cls, calls = upsert_harness
    df = pd.DataFrame({"equip_id": ["A301", "A302"], "recipe_name": [None, pd.NA]})
    assert cls.upsert("recipe_info", "recipe_info_key", df) == 2
    page = next(x for x in calls if x[0] == "execute_values")
    assert page[2] == [("A301", None), ("A302", None)]
    assert "DO NOTHING" in page[1]


def test_upsert_rejects_missing_keys_and_invalid_table(upsert_harness):
    cls, _ = upsert_harness
    df = pd.DataFrame({"equip_id": ["A301"], "value": [2]})
    with pytest.raises(ValueError, match="missing constraint columns"):
        cls.upsert("recipe_info", "recipe_info_key", df)
    with pytest.raises(ValueError, match="table"):
        cls.upsert("schema.table.inject", "key", df)
    with pytest.raises(ValueError, match="positive"):
        cls.upsert("recipe_info", "key", df, chunk_size=0)


def test_upsert_null_conversion_and_sql_identifiers(upsert_harness):
    cls, calls = upsert_harness
    df = pd.DataFrame({
        "equip_id": ["A301"], "recipe_name": ["R1"],
        'str"ange': [np.float64(float("nan"))],
        "when": [pd.Timestamp("2026-10-21")],
    })
    assert cls.upsert("public.recipe_info", "recipe_info_key", df) == 1
    page = next(x for x in calls if x[0] == "execute_values")
    assert '"str""ange" = EXCLUDED."str""ange"' in page[1]
    assert page[2][0][2] is None
    assert str(page[2][0][3]).startswith("2026-10-21")


def test_upsert_rollback_on_failed_second_chunk(upsert_harness):
    cls, calls = upsert_harness
    func = cls.upsert.__globals__
    old = func["execute_values"]
    counter = 0

    def fail_second(*args, **kwargs):
        nonlocal counter
        counter += 1
        if counter == 2:
            raise RuntimeError("simulated constraint violation")
        return old(*args, **kwargs)

    func["execute_values"] = fail_second
    df = pd.DataFrame({"equip_id": ["A", "B"], "recipe_name": ["R1", "R2"]})
    with pytest.raises(RuntimeError):
        cls.upsert("recipe_info", "recipe_info_key", df, chunk_size=1)
    assert ("rollback",) in calls
    assert ("commit",) not in calls
