"""DM Recipe FTP equipment scanner with bounded 999-row UPSERT batches."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from ftplib import FTP
from pathlib import Path
from typing import Any
import logging
import os
import re
import pandas as pd
from dateutil.relativedelta import relativedelta
from src.config.config import RECIPE_BATCH_SIZE
from src.domain.entities.equipment import Equipment, create_equipment
from src.collectors.ftp.client import (
    FTPEntry, FTPDirectoryError, FTPRecipeUnavailable, FTPRequiredFileMissing,
    list_entries, safe_download_recipe,
)
from src.databases import OracleCRUD, PostgresCRUD

log = logging.getLogger(__name__)
UPSERT_BATCH_SIZE = RECIPE_BATCH_SIZE
COLS = ['recipe_key', 'model', 'equip', 'device', 'recipe', 'folder_path',
        'file_path', 'dt_edit_time', 'backup_folder_path', 'backup_file_path',
        'dt_backup', 'status', 'tech_prod', 'tech', 'prod_group', 'level', 'layer',
        'is_remove', 'parse_status', 'parse_error']


def parse_edit_time(line: str) -> str:
    """FTP LIST 수정시각을 YYYY-MM-DD HH:MM 문자열로 변환한다.

    Args:
        line: FTP 또는 Recipe 텍스트 한 행.

    Returns:
        str: 처리 결과를 반환한다."""
    now = datetime.now()
    # Unix FTP: 'Oct 26 14:32' or 'Oct  6 2025' ; no year => current year.
    match = re.search(r'\b([A-Za-z]{3})\s+(\d{1,2})\s+(\d{2}:\d{2}|\d{4})\b', line)
    if match:
        month, day, last = match.groups()
        if ':' in last:
            value = datetime.strptime(f'{now.year} {month} {day} {last}', '%Y %b %d %H:%M')
        else:
            value = datetime.strptime(f'{month} {day} {last}', '%b %d %Y')
    else:
        # Localized Korean LIST variants: 8월 30일 2012년 / 8월 30일 14:32
        localized = re.search(r'(\d{1,2})월\s*(\d{1,2})일\s*(\d{4})년?', line)
        local_clock = re.search(r'(\d{1,2})월\s*(\d{1,2})일\s*(\d{1,2}:\d{2})', line)
        if localized:
            m, d, y = localized.groups()
            value = datetime(int(y), int(m), int(d))
        elif local_clock:
            m, d, clock = local_clock.groups()
            hour, minute = map(int, clock.split(':'))
            value = datetime(now.year, int(m), int(d), hour, minute)
        else:
            # Unknown listing format means we cannot reliably compute changes/deletions.
            raise ValueError(f'Unable to parse FTP date: {line!r}')
    if value > now:
        value -= relativedelta(years=1)
    return value.strftime('%Y-%m-%d %H:%M')


def recipe_filter(name: str) -> bool:
    """KLA2139 Recipe 폴더 이름이 지정한 명명 규칙에 맞는지 확인한다.

    Args:
        name: 대상 이름.

    Returns:
        bool: 처리 결과를 반환한다."""
    if name.startswith(('.', '_')) or name.endswith(('~', '.inf', '.DAT')):
        return False
    parts = name.split('_')
    return len(parts) == 2 and len(parts[0]) == 4


def is_recipe(entry: FTPEntry) -> bool:
    """FTP 항목이 Recipe 이름 규칙에 맞는 디렉터리인지 확인한다.

    Args:
        entry: FTP 파일/폴더 항목.

    Returns:
        bool: 처리 결과를 반환한다."""
    return entry.is_dir and recipe_filter(entry.name)


def is_recipe_kla2365(entry: FTPEntry, device: str, layer: str) -> bool:
    """KLA2365/PUMA Device·Layer에 맞는 Recipe 폴더만 선택한다.

    Args:
        entry: FTP 파일/폴더 항목.
        device: Device 이름.
        layer: Layer 이름.

    Returns:
        bool: 처리 결과를 반환한다."""
    if not is_recipe(entry):
        return False
    a, b = entry.name.split('_')
    return a == device and b.endswith(layer)


def is_device(entry: FTPEntry) -> bool:
    """디렉터리가 4글자 Device 이름 규칙에 부합하는지 확인한다.

    Args:
        entry: FTP 파일/폴더 항목.

    Returns:
        bool: 처리 결과를 반환한다."""
    return entry.is_dir and len(entry.name) == 4 and not entry.name.startswith(('.', '_'))


def is_layer(entry: FTPEntry) -> bool:
    """디렉터리가 Layer 이름 규칙에 부합하는지 확인한다.

    Args:
        entry: FTP 파일/폴더 항목.

    Returns:
        bool: 처리 결과를 반환한다."""
    return is_device(entry)


def build_equipment_lookup(equip_db: pd.DataFrame) -> dict[str, dict]:
    """기존 Recipe DataFrame을 키 조회가 빠른 딕셔너리로 변환한다.

    Args:
        equip_db: 처리에 필요한 입력값.

    Returns:
        dict[str, dict]: 처리 결과를 반환한다."""
    if equip_db.empty:
        return {}
    return equip_db.set_index('recipe_key').to_dict(orient='index')


def is_file_update(equip_lookup: dict[str, dict], rcp_key: str,
                   edit_time: str, backup_file_path: Path) -> tuple[bool, str | None]:
    """FTP 수정 시각과 기존 백업 상태를 비교해 신규·수정 여부를 판정한다.

    Args:
        equip_lookup: 기존 Recipe 정보를 키로 조회하는 딕셔너리.
        rcp_key: Recipe 기본키.
        edit_time: FTP Recipe 최종 수정시각 문자열.
        backup_file_path: 로컬 필수 파일 백업 경로.

    Returns:
        tuple[bool, str | None]: 처리 결과를 반환한다."""
    info = equip_lookup.get(rcp_key)
    if info is None:
        return True, 'new'
    if not backup_file_path.is_file():
        return True, 'update'
    return (True, 'update') if edit_time > info['dt_edit_time'] else (False, None)


def join_mes_info(upserts: list[dict[str, Any]]) -> pd.DataFrame:
    """Oracle MES 제품 정보를 Recipe 수집 데이터에 바인드 쿼리로 결합한다.

    Args:
        upserts: UPSERT 대상 Recipe 기록.

    Returns:
        pd.DataFrame: 처리 결과를 반환한다."""
    if not upserts:
        return pd.DataFrame(columns=COLS)
    frame = pd.DataFrame.from_records(upserts)
    devices = list(dict.fromkeys(frame['device'].tolist()))
    matches: dict[str, set[tuple]] = {device: set() for device in devices}
    for offset in range(0, len(devices), 900):
        chunk = devices[offset:offset + 900]
        binds = {f'd{i}': device for i, device in enumerate(chunk)}
        holders = ','.join(f':d{i}' for i in range(len(chunk)))
        query = f'''SELECT DISTINCT MAT_ID product, MAT_CMF_21 device,
                    MAT_CMF_5 device_name, MAT_CMF_6 tech_prod,
                    MAT_CMF_7 tech, MAT_CMF_23 prod_group
                    FROM IDBMGR.MWIPMATDEF WHERE FACTORY='AFB1'
                      AND MAT_CMF_21 IN ({holders})'''
        mes = OracleCRUD.select_query(query, binds)
        for row in mes.itertuples(index=False):
            product = getattr(row, 'product', None)
            device = str(getattr(row, 'device', ''))
            device_name = getattr(row, 'device_name', None)
            if device not in matches:
                continue
            if device_name not in (None, '', ' ') and (not product or device not in str(product)):
                continue
            matches[device].add((getattr(row, 'tech_prod', None),
                                 getattr(row, 'tech', None), getattr(row, 'prod_group', None)))
    # Do not arbitrary-drop conflicting master metadata. Keep null & log conflict.
    for name, index in (('tech_prod', 0), ('tech', 1), ('prod_group', 2)):
        frame[name] = frame['device'].map(lambda dev: next(iter(matches[dev]))[index] if len(matches[dev]) == 1 else None)
    for device, variants in matches.items():
        if len(variants) > 1:
            log.warning('MES metadata is ambiguous for device=%s (%d values)', device, len(variants))
    return frame[COLS]


@dataclass
class CollectionState:
    equip: Equipment
    batch_size: int = UPSERT_BATCH_SIZE
    upserts: list[dict[str, Any]] = field(default_factory=list)
    seen_keys: set[str] = field(default_factory=set)
    unchanged_keys: set[str] = field(default_factory=set)
    new_cnt: int = 0
    update_cnt: int = 0
    download_failures: int = 0
    consecutive_download_failures: int = 0
    skipped_missing_file: int = 0
    skipped_missing_path: int = 0

    def __post_init__(self) -> None:
        """수집 UPSERT 배치 크기가 1~999 범위인지 검증한다.

        Args:
            self: 현재 클래스 인스턴스.

        Returns:
            None: 처리 결과를 반환한다."""
        if not 1 <= self.batch_size <= 999:
            raise ValueError('batch_size must be within [1, 999]')

    def append(self, recipe: dict[str, Any]) -> None:
        """수집된 신규·수정 Recipe를 버퍼에 넣고 임계치 도달 시 저장한다.

        Args:
            self: 현재 클래스 인스턴스.
            recipe: Recipe 관련 컬럼을 담은 DB 저장용 딕셔너리.

        Returns:
            None: 처리 결과를 반환한다."""
        self.upserts.append(recipe)
        if len(self.upserts) >= self.batch_size:
            self.flush()

    def flush(self) -> None:
        """수집 버퍼를 MES와 결합해 PostgreSQL에 저장하고 성공 시만 초기화한다.

        Args:
            self: 현재 클래스 인스턴스.

        Returns:
            None: 처리 결과를 반환한다."""
        if not self.upserts:
            return
        enriched = join_mes_info(self.upserts)
        update_database(self.equip, enriched, [], [], finalize=False)
        self.new_cnt += sum(x['status'] == 'new' for x in self.upserts)
        self.update_cnt += sum(x['status'] == 'update' for x in self.upserts)
        log.info('[%s] flushed %s rows', self.equip.name, len(self.upserts))
        self.upserts.clear()



def _log_recipe_skip(equip: Equipment, recipe_name: str, reason: str,
                     count: int, exc: Exception) -> None:
    """수집 제외 로그를 처음 10건과 이후 500건마다 기록한다.

    Args:
        equip: 수집 장비 정보.
        recipe_name: 제외된 Recipe 폴더 이름.
        reason: 제외 사유(필수 파일 없음 또는 경로 없음).
        count: 해당 사유로 제외된 누적 Recipe 건수.
        exc: FTP 파일·경로 확인 과정에서 발생한 원인 예외.

    Notes:
        같은 유형의 제외가 수천 건 발생해도 로그 파일 과다 생성을 막는다.
        전체 건수는 장비 처리 종료 시 별도로 출력한다.
    """
    if count <= 10 or count % 500 == 0:
        log.warning('[%s] Recipe 제외(%s) %d건째: %s - %s',
                    equip.name, reason, count, recipe_name, exc)


def _recipe_info(equip: Equipment, entry: FTPEntry, device: str, layer: str,
                 path_parts: list[str], required: str, file_status: str) -> dict:
    """FTP Recipe 정보와 로컬 백업 경로를 DB 저장용 딕셔너리로 구성한다.

    Args:
        equip: 수집·파싱 대상 장비 정보.
        entry: FTP 파일/폴더 항목.
        device: Device 이름.
        layer: Layer 이름.
        path_parts: 처리에 필요한 입력값.
        required: 필수 Recipe 파일 이름.
        file_status: 처리에 필요한 입력값.

    Returns:
        dict: 처리 결과를 반환한다."""
    recipe = entry.name
    remote = '/'.join([equip.ftp_info.remote_directory.rstrip('/'), *path_parts, recipe])
    return {
        'recipe_key': f'{equip.name}-{recipe}', 'model': equip.model,
        'equip': equip.name, 'device': device, 'layer': layer, 'level': layer[:4],
        'recipe': recipe, 'folder_path': remote, 'file_path': f'{remote}/{required}',
        'dt_edit_time': parse_edit_time(entry.raw),
        'backup_folder_path': f'/{equip.name}/{recipe}',
        'backup_file_path': f'/{equip.name}/{recipe}/{required}',
        'dt_backup': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'status': file_status, 'is_remove': False,
        'parse_status': 'pending', 'parse_error': None,
    }


def _scan_recipe(ftp: FTP, entry: FTPEntry, equip: Equipment, equip_dir: Path,
                 lookup: dict, state: CollectionState, required: str,
                 device: str, layer: str, path_parts: list[str],
                 expected_parent: str, *, is_retry: bool = False) -> None:
    """Recipe의 갱신 필요성을 판단하고 다운로드·제외·실패를 분류한다.

    Args:
        ftp: 연결된 FTP 클라이언트.
        entry: FTP 파일/폴더 항목.
        equip: 수집·파싱 대상 장비 정보.
        equip_dir: 장비별 로컬 백업 폴더.
        lookup: 기존 Recipe를 recipe_key로 조회하는 딕셔너리.
        state: 장비 수집 상태 및 저장 버퍼.
        required: 필수 Recipe 파일 이름.
        device: Device 이름.
        layer: Layer 이름.
        path_parts: 처리에 필요한 입력값.
        expected_parent: 예상되는 FTP 부모 디렉터리.
        is_retry: FTP 재연결 후 재시도 여부.

    Returns:
        None: 처리 결과를 반환한다."""
    key = f'{equip.name}-{entry.name}'
    if key in state.seen_keys and not is_retry:
        raise RuntimeError(f'Duplicate Recipe key in FTP traversal: {key}')
    state.seen_keys.add(key)
    dest = equip_dir / entry.name
    edit_time = parse_edit_time(entry.raw)
    needs_update, status = is_file_update(lookup, key, edit_time, dest / required)
    if not needs_update:
        state.unchanged_keys.add(key)
        return
    try:
        safe_download_recipe(ftp, entry.name, dest, required,
                             expected_parent=expected_parent)
    except FTPRequiredFileMissing as exc:
        # 실제 파일이 없는 폴더는 별도 '수집 제외'로 기록한다.
        # 기존 DB/백업은 유지하며 다운로드 실패 건수에는 포함하지 않는다.
        state.skipped_missing_file += 1
        state.consecutive_download_failures = 0
        _log_recipe_skip(equip, entry.name, '필수 파일 없음',
                         state.skipped_missing_file, exc)
        return
    except (FTPRecipeUnavailable, FTPDirectoryError):
        # 해당 장비의 FTP 연결을 재수립해 한 번 더 시도하도록 상위에 전파.
        raise
    except Exception:
        state.download_failures += 1
        state.consecutive_download_failures += 1
        log.exception('[%s] Recipe download failed: %s (%d consecutive failures)',
                      equip.name, entry.name, state.consecutive_download_failures)
        if state.consecutive_download_failures >= 5:
            raise RuntimeError(
                f'[{equip.name}] 5 consecutive Recipe downloads failed; '
                'aborting collection to protect integrity. Inspect the first failure.'
            )
        return
    state.consecutive_download_failures = 0
    state.append(_recipe_info(equip, entry, device, layer, path_parts, required, status))


def _leave_ftp_folder(ftp: FTP, expected_parent: str, folder_name: str) -> None:
    """상대경로로 부모 폴더에 복귀하고 실제 PWD가 일치하는지 확인한다.

    Args:
        ftp: 현재 하위 폴더에 있는 FTP 연결.
        expected_parent: 이동 전 저장한 부모 폴더의 PWD.
        folder_name: 로그에 사용할 이동한 하위 폴더명.

    Raises:
        FTPDirectoryError: CWD ..에 실패했거나 실제 복귀 위치가 다른 경우.
    """
    try:
        ftp.cwd('..')
        restored = ftp.pwd()
    except Exception as exc:
        raise FTPDirectoryError(f'FTP 폴더 복귀 실패: {folder_name!r}') from exc
    if restored.rstrip('/').casefold() != expected_parent.rstrip('/').casefold():
        raise FTPDirectoryError(
            f'FTP 폴더 복귀 위치 불일치: {folder_name!r}, '
            f'expected={expected_parent!r}, actual={restored!r}'
        )


def _scan_nested_device(ftp: FTP, equip: Equipment, equip_dir: Path,
                        lookup: dict, state: CollectionState, device: str) -> None:
    """KLA2365/PUMA의 Device → Layer → Recipe 폴더를 순회한다.

    Args:
        ftp: 해당 장비의 로그인 FTP 연결.
        equip: 수집 장비 설정.
        equip_dir: 로컬 Recipe 저장 위치.
        lookup: 기존 Recipe 정보를 조회할 딕셔너리.
        state: 수집 상태 및 UPSERT 버퍼.
        device: 탐색 대상 Device 폴더명.

    Notes:
        Device/Layer에서 빠져나올 때 절대경로 CWD 대신 CWD ..를 사용하며
        복귀 위치를 확인한다. Recipe 경로 없음은 제외, 복귀 실패는 중단한다.
    """
    base = ftp.pwd()
    ftp.cwd(device)
    try:
        device_pwd = ftp.pwd()
        for layer_entry in list_entries(ftp):
            if not is_layer(layer_entry):
                continue
            layer = layer_entry.name
            ftp.cwd(layer)
            try:
                layer_pwd = ftp.pwd()
                for entry in list_entries(ftp):
                    if is_recipe_kla2365(entry, device, layer):
                        try:
                            _scan_recipe(ftp, entry, equip, equip_dir, lookup,
                                         state, 'Sensitivity1.xml', device,
                                         entry.name.split('_', 1)[1], [device, layer],
                                         layer_pwd)
                        except FTPRecipeUnavailable as exc:
                            # 목록에는 있으나 원격 경로가 실제로 없는 경우 제외.
                            state.skipped_missing_path += 1
                            state.consecutive_download_failures = 0
                            _log_recipe_skip(equip, entry.name, '경로 없음',
                                             state.skipped_missing_path, exc)
            finally:
                _leave_ftp_folder(ftp, device_pwd, layer)
    finally:
        _leave_ftp_folder(ftp, base, device)


def _connect_kla2139(equip: Equipment) -> FTP:
    """KLA2139 장비에 새 FTP 세션을 연결하고 Recipe 루트로 이동한다.

    Args:
        equip: 접속할 장비의 FTP 설정.

    Returns:
        FTP: Recipe 루트 위치까지 이동이 완료된 새 연결.

    Raises:
        Exception: 연결, 인증 또는 루트 폴더 이동에 실패하면 전파.

    Notes:
        구형 FTP 서버의 내부 CWD 상태가 꼬인 경우에만 재연결에 사용한다.
    """
    ftp = FTP(timeout=equip.ftp_info.timeout_seconds, encoding=equip.ftp_info.encoding)
    try:
        ftp.connect(equip.ftp_info.host, equip.ftp_info.port)
        ftp.login(equip.ftp_info.username, equip.ftp_info.password)
        ftp.cwd(equip.ftp_info.remote_directory)
        return ftp
    except Exception:
        ftp.close()
        raise


def collect_kla2139(equip: Equipment, equip_dir: Path, lookup: dict,
                    state: CollectionState) -> None:
    """KLA2139 Recipe를 순회하며 FTP 경로 오류에 한해 새 연결로 1회 재시도한다.

    Args:
        equip: 수집할 KLA2139 장비.
        equip_dir: 로컬 백업 최상위 폴더.
        lookup: 기존 Recipe 정보를 recipe_key로 조회하는 딕셔너리.
        state: 수집 결과 및 UPSERT 버퍼를 관리하는 공유 상태.

    Notes:
        LIST에서 확인한 Recipe 이름은 재접속 후에도 그대로 사용한다.
        경로 없음(550)이 반복되어도 다운로드 실패 건수에는 포함하지 않으며
        실제 FTP 연결 실패/복귀 불능은 장비 전체 안전 중단 대상으로 남긴다.
    """
    ftp = _connect_kla2139(equip)
    try:
        recipe_root = ftp.pwd()
        # Recipe 목록은 최초 루트에서 1회 조회; 다운로드는 순서대로 처리한다.
        recipes = [entry for entry in list_entries(ftp) if is_recipe(entry)]
        for entry in recipes:
            device, layer = entry.name.split('_', 1)
            for attempt in (1, 2):
                try:
                    _scan_recipe(
                        ftp, entry, equip, equip_dir, lookup, state,
                        'ins.dat', device, layer, [], recipe_root,
                        is_retry=(attempt == 2),
                    )
                    break
                except (FTPRecipeUnavailable, FTPDirectoryError) as exc:
                    if attempt == 1:
                        log.warning(
                            '[%s] Recipe FTP 경로 이상, 새 연결로 1회 재시도: %s - %s',
                            equip.name, entry.name, exc,
                        )
                        ftp.close()
                        ftp = _connect_kla2139(equip)
                        recipe_root = ftp.pwd()
                        continue
                    if isinstance(exc, FTPRecipeUnavailable):
                        # 재접속 후에도 존재하지 않는 레시피 경로는 제외 처리.
                        state.skipped_missing_path += 1
                        state.consecutive_download_failures = 0
                        _log_recipe_skip(equip, entry.name, '경로 없음(재시도 완료)',
                                         state.skipped_missing_path, exc)
                        break
                    # 재연결 직후에도 현재 폴더 복귀를 실패한다면 목록 신뢰 불가.
                    raise
    finally:
        ftp.close()


def collect_kla2365(equip: Equipment, equip_dir: Path, lookup: dict,
                    state: CollectionState) -> None:
    """KLA2365 장비의 Device/Layer 폴더를 순차적으로 수집한다.

    Args:
        equip: 수집·파싱 대상 장비 정보.
        equip_dir: 장비별 로컬 백업 폴더.
        lookup: 기존 Recipe를 recipe_key로 조회하는 딕셔너리.
        state: 장비 수집 상태 및 저장 버퍼.

    Returns:
        None: 처리 결과를 반환한다."""
    with FTP(timeout=equip.ftp_info.timeout_seconds, encoding=equip.ftp_info.encoding) as ftp:
        ftp.connect(equip.ftp_info.host, equip.ftp_info.port)
        ftp.login(equip.ftp_info.username, equip.ftp_info.password)
        # KLA2365/PUMA: original code lists Device dirs directly at FTP login cwd.
        for entry in list_entries(ftp):
            if is_device(entry):
                _scan_nested_device(ftp, equip, equip_dir, lookup, state, entry.name)


def collect_puma(equip: Equipment, equip_dir: Path, lookup: dict,
                 state: CollectionState) -> None:
    """PUMA 장비의 Device/Layer 폴더를 수집한다.

    Args:
        equip: 수집·파싱 대상 장비 정보.
        equip_dir: 장비별 로컬 백업 폴더.
        lookup: 기존 Recipe를 recipe_key로 조회하는 딕셔너리.
        state: 장비 수집 상태 및 저장 버퍼.

    Returns:
        None: 처리 결과를 반환한다."""
    collect_kla2365(equip, equip_dir, lookup, state)


def update_database(equip: Equipment, upserts: pd.DataFrame, remove_keys: list[str],
                    unchange_keys: list[str], *, finalize: bool = True,
                    new_cnt: int | None = None, update_cnt: int | None = None) -> None:
    """수집 배치를 UPSERT하고 장비 최종 변경 이력을 확정한다.

    Args:
        equip: 수집·파싱 대상 장비 정보.
        upserts: UPSERT 대상 Recipe 기록.
        remove_keys: 삭제 판정 대상 Recipe 키 목록.
        unchange_keys: 변경되지 않은 Recipe 키 목록.
        finalize: 장비 단위 삭제·유지·이력 정산 여부.
        new_cnt: 신규 Recipe 건수.
        update_cnt: 수정 Recipe 건수.

    Returns:
        None: 처리 결과를 반환한다."""
    if not upserts.empty:
        PostgresCRUD.upsert('dm_recipe_info', 'dm_recipe_info_pkey', upserts)
    if not finalize:
        return
    if new_cnt is None:
        new_cnt = int(upserts['status'].eq('new').sum()) if 'status' in upserts else 0
    if update_cnt is None:
        update_cnt = int(upserts['status'].eq('update').sum()) if 'status' in upserts else 0
    history = pd.DataFrame([{
        'model': equip.model, 'equip': equip.name, 'new_rcp': new_cnt,
        'update_rcp': update_cnt, 'remove_rcp': len(remove_keys),
        'aggregation_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    }])
    PostgresCRUD.finalize_equipment_scan(equip.name, remove_keys, unchange_keys, history,
                                         chunk_size=UPSERT_BATCH_SIZE)
    log.info('[%s] new=%d update=%d removed=%d unchanged=%d',
             equip.name, new_cnt, update_cnt, len(remove_keys), len(unchange_keys))


def collect_equip_data(equip: Equipment, equip_dir: Path) -> None:
    """장비 한 대의 Recipe를 수집한 뒤 삭제·유지 상태를 검증하고 정산한다.

    Args:
        equip: 수집·파싱 대상 장비 정보.
        equip_dir: 장비별 로컬 백업 폴더.

    Returns:
        None: 처리 결과를 반환한다."""
    equip_db = PostgresCRUD.select_query('''SELECT recipe_key, dt_edit_time, device,
        layer, recipe, backup_file_path FROM dm_recipe_info
        WHERE equip=%s AND is_remove=false''', (equip.name,))
    lookup = build_equipment_lookup(equip_db)
    del equip_db  # free the source DataFrame; retain only indexed Recipe values
    state = CollectionState(equip=equip)
    match equip.model:
        case 'KLA2139':
            collect_kla2139(equip, equip_dir, lookup, state)
        case 'KLA2365':
            collect_kla2365(equip, equip_dir, lookup, state)
        case 'PUMA':
            collect_puma(equip, equip_dir, lookup, state)
        case _:
            raise ValueError(f'Unsupported equipment model: {equip.model}')
    state.flush()
    log.info('[%s] 수집 제외: 필수 파일 없음 %d건, 경로 없음 %d건',
             equip.name, state.skipped_missing_file, state.skipped_missing_path)
    old_keys = set(lookup)
    if old_keys and not state.seen_keys:
        raise RuntimeError(f'[{equip.name}] FTP returned no Recipe; deletion blocked')
    remove_keys = list(old_keys - state.seen_keys)
    # Large removal is never applied without explicit operator-controlled review.
    allowed_fraction = float(os.getenv('MAX_AUTO_REMOVAL_RATIO', '0.25'))
    if old_keys and (len(remove_keys) / len(old_keys)) > allowed_fraction:
        raise RuntimeError(f'[{equip.name}] Removal ratio {len(remove_keys)}/{len(old_keys)} '
                           f'exceeds {allowed_fraction:.0%}; deletion blocked')
    if state.download_failures:
        # Keep already committed upserts; postpone destructive finalization.
        raise RuntimeError(f'[{equip.name}] {state.download_failures} downloads failed; '
                           'delete/update-history skipped; pending parses remain available')
    update_database(equip, pd.DataFrame(columns=['status']), remove_keys,
                    list(state.unchanged_keys), new_cnt=state.new_cnt,
                    update_cnt=state.update_cnt)


class Collector:
    def __init__(self, equipments: list[dict], dm_dir: Path) -> None:
        """Collector의 장비 목록과 백업 기본 경로를 초기화한다.

        Args:
            self: 현재 클래스 인스턴스.
            equipments: 수집할 장비 설정 목록.
            dm_dir: Recipe 저장 기본 경로.

        Returns:
            None: 처리 결과를 반환한다."""
        self.equipments = equipments
        self.dm_dir = dm_dir

    def run(self) -> None:
        """활성화된 모든 장비를 순회하고 장비별 실패를 격리한다.

        Args:
            self: 현재 클래스 인스턴스.

        Returns:
            None: 처리 결과를 반환한다."""
        failures = []
        for eq_info in self.equipments:
            equip = create_equipment(eq_info)
            if not equip.enabled:
                continue
            equip_dir = self.dm_dir / equip.name
            equip_dir.mkdir(parents=True, exist_ok=True)
            try:
                log.info('[%s] FTP collection started', equip.name)
                collect_equip_data(equip, equip_dir)
            except Exception:
                failures.append(equip.name)
                log.exception('[%s] FTP collection failed; other equipment continues', equip.name)
        if failures:
            log.error('FTP collection failed for: %s', ', '.join(failures))
