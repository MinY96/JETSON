-- [선택 사항] GitHub 최초 DDL의 Master 삭제 CASCADE 정책을 안전하게 변경.
-- 이미 테이블 생성 시 ON DELETE SET NULL로 반영했다면 실행하지 않아도 됩니다.
-- 운영 DB에서 사용하기 전에 백업과 해당 제약조건의 현재 정의를 확인하세요.
BEGIN;
ALTER TABLE f1.dm_recipe_info DROP CONSTRAINT IF EXISTS fk_master_recipe_key;
ALTER TABLE f1.dm_recipe_info
    ADD CONSTRAINT fk_master_recipe_key FOREIGN KEY (master_key)
    REFERENCES f1.dm_master_recipe_info(master_key)
    ON DELETE SET NULL;
COMMIT;
