-- V3.2: 장비 단위 수집 시작·성공·부분 완료·실패 이력 (FAB1)
-- create_db_f1.sql의 테이블 생성 이후 한 번 실행한다.
-- 기존 dm_update_history 구조와 Recipe 외래키에는 영향을 주지 않는다.
CREATE TABLE IF NOT EXISTS f1.dm_collection_run_history (
    run_id uuid PRIMARY KEY,
    model varchar(15) NOT NULL,
    equip varchar(10) NOT NULL,
    started_at timestamptz NOT NULL DEFAULT NOW(),
    finished_at timestamptz NULL,
    scan_status varchar(10) NOT NULL DEFAULT 'running',
    new_rcp int4 NOT NULL DEFAULT 0,
    update_rcp int4 NOT NULL DEFAULT 0,
    remove_rcp int4 NOT NULL DEFAULT 0,
    unchanged_rcp int4 NOT NULL DEFAULT 0,
    download_failures int4 NOT NULL DEFAULT 0,
    skipped_missing_file int4 NOT NULL DEFAULT 0,
    skipped_missing_path int4 NOT NULL DEFAULT 0,
    skipped_recursive_listing int4 NOT NULL DEFAULT 0,
    skipped_optional_files int4 NOT NULL DEFAULT 0,
    reconnect_count int4 NOT NULL DEFAULT 0,
    error_message text NULL,
    CONSTRAINT ck_dm_collection_run_history_status
      CHECK (scan_status IN ('running', 'success', 'partial', 'failed'))
);
CREATE INDEX IF NOT EXISTS ix_dm_collection_run_history_equip_started
    ON f1.dm_collection_run_history (equip, started_at DESC);
CREATE INDEX IF NOT EXISTS ix_dm_collection_run_history_status_started
    ON f1.dm_collection_run_history (scan_status, started_at DESC);
