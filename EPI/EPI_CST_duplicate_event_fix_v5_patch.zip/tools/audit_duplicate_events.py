"""Read-only audit of previously saved integrated_results.csv duplicate clips.

Writes a duplicate-group report and a deduplicated *preview*. Never modifies
old event directories or overwrites the input CSV.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import pandas as pd


def num(v):
    try:
        n = float(v)
        return n if pd.notna(n) else None
    except (ValueError, TypeError):
        return None


def probably_same(a, b, end_tol, peak_tol):
    # Only coalesce rows from the same analysis session.
    if a.get('_session_key') != b.get('_session_key'):
        return False
    e1, e2 = num(a.get('clip_end_sec')), num(b.get('clip_end_sec'))
    s1, s2 = num(a.get('clip_start_sec')), num(b.get('clip_start_sec'))
    if None in (e1, e2, s1, s2) or abs(e1-e2) > end_tol:
        return False
    d1, d2 = e1-s1, e2-s2
    if min(d1, d2) <= 0:
        return False
    overlap = max(0., min(e1,e2)-max(s1,s2))
    if overlap / min(d1, d2) < 0.85:
        return False
    p1, p2 = num(a.get('cst_peak_sec')), num(b.get('cst_peak_sec'))
    if p1 is not None and p2 is not None and abs(p1-p2) > peak_tol:
        return False
    for col in ('blade_out_start_sec', 'blade_out_end_sec'):
        x, y = num(a.get(col)), num(b.get(col))
        if x is not None and y is not None and abs(x-y) > end_tol:
            return False
    return True


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--results', type=Path, required=True,
                   help='Path to existing integrated_results.csv')
    p.add_argument('--end-tolerance-sec', type=float, default=.15)
    p.add_argument('--peak-tolerance-sec', type=float, default=3.)
    p.add_argument('--audit-output', type=Path, default=None)
    p.add_argument('--preview-output', type=Path, default=None)
    args = p.parse_args(argv)
    df = pd.read_csv(args.results, encoding='utf-8-sig')
    required = {'clip_start_sec','clip_end_sec'}
    if not required.issubset(df.columns):
        p.error(f'Missing columns: {sorted(required - set(df.columns))}')
    records = df.where(pd.notna(df), None).to_dict('records')
    for i, r in enumerate(records):
        r['_input_row'] = i + 1
        r['_session_key'] = str(r.get('session_id') or '')
    parent = list(range(len(records)))
    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for i, left in enumerate(records):
        for j in range(i+1, len(records)):
            if probably_same(left, records[j], args.end_tolerance_sec, args.peak_tolerance_sec):
                parent[root(j)] = root(i)
    groups = {}
    for i in range(len(records)):
        groups.setdefault(root(i), []).append(i)
    output = []
    selected = []
    dup_group = 0
    for members in groups.values():
        # Prefer an event with measured geometry; otherwise use the longer clip.
        def priority(i):
            rec = records[i]
            measured = rec.get('status') in {'ok','partial','no_wafer_detected'}
            both_gaps = num(rec.get('top_gap_px')) is not None and num(rec.get('bottom_gap_px')) is not None
            start = num(rec.get('clip_start_sec'))
            return (both_gaps, measured, -(start or 0.))
        keep = max(members, key=priority)
        selected.append(keep)
        if len(members) > 1:
            dup_group += 1
            for i in members:
                r = records[i]
                output.append({
                    'group_id': dup_group,
                    'action': 'KEEP' if i == keep else 'REVIEW_DUPLICATE',
                    'input_row': r['_input_row'],
                    'event_id': r.get('event_id'),
                    'session_id': r.get('session_id'),
                    'status': r.get('status'),
                    'clip_start_sec': r.get('clip_start_sec'),
                    'clip_end_sec': r.get('clip_end_sec'),
                    'cst_peak_sec': r.get('cst_peak_sec'),
                    'event_folder': r.get('event_folder'),
                })
    audit = args.audit_output or args.results.with_name('duplicate_audit.csv')
    preview = args.preview_output or args.results.with_name('deduplicated_preview.csv')
    if args.results.resolve() in (audit.resolve(), preview.resolve()):
        p.error('Outputs must not overwrite input CSV')
    pd.DataFrame(output, columns=['group_id','action','input_row','event_id','session_id',
                                  'status','clip_start_sec','clip_end_sec','cst_peak_sec',
                                  'event_folder']).to_csv(audit, index=False, encoding='utf-8-sig')
    df.iloc[sorted(selected)].to_csv(preview, index=False, encoding='utf-8-sig')
    print(f'Input rows: {len(df)}')
    print(f'Duplicate groups: {dup_group}')
    print(f'Duplicate rows: {len(df)-len(selected)}')
    print(f'Unique preview rows: {len(selected)}')
    print(f'Audit: {audit}')
    print(f'Preview: {preview}')
    print('Existing event directories and source CSV were NOT modified.')


if __name__ == '__main__':
    main()
