# 동일 Type2 이벤트 중복 생성 방지 패치 (v5)

## 원인

기존 온라인 검출기는 CST 후보 그룹의 `cst_peak_frame`으로만 처리 여부를 관리했습니다.
하나의 Type2 동작이 CST 움직임 그룹 두 개로 나뉘면 서로 다른 `peak_frame`을 갖고,
두 후보가 동일한 Blade OUT과 `clip_end_sec`를 참조해도 별개의 이벤트 작업으로 제출됐습니다.

사용자가 보고한 7쌍은 `clip_end_sec`가 각각 동일하며 시작 시각만 약 1초 다릅니다.
따라서 CST threshold 조정 대신 **같은 Blade OUT / 겹치는 클립의 중복 후보 병합**을 적용했습니다.
이 패턴만으로 모든 중복의 원인을 확정할 수는 없으며, 실제 CSV에는 `cst_peak_sec`와
`blade_out_start_sec`, `blade_out_end_sec`도 함께 확인하는 것이 좋습니다.

## 수정 파일

- `src/events/online.py`: 중복 후보 병합/늦게 도착한 후보 차단/EOF flush
- `src/streaming/engine.py`: 최종 후보 전달, 통계와 중복 로그 저장
- `main.py`: 중복 병합 임계값 CLI 추가
- `tools/audit_duplicate_events.py`: 기존 결과 CSV의 중복 후보 보고서(읽기 전용)
- `tests/test_event_dedup.py`: 7쌍 및 독립 이벤트 회귀 테스트

**`src/streaming/event_worker.py`는 수정하지 않았습니다.** 이미 사용자가 추가했을 수 있는
`measurement_selection_failed` 이벤트 폴더 삭제 기능을 덮어쓰지 않기 위해서입니다.

## 중복 후보 판정 조건

다음을 모두 충족하면 같은 이벤트로 보고 병합합니다.

1. `clip_end_sec` 차이가 **0.15초 이하**.
2. `cst_peak_sec` 차이가 **3초 이하**.
3. 두 클립의 겹치는 길이가 **짧은 클립 길이의 85% 이상**.
4. 두 후보에 `blade_out_start_sec`/`blade_out_end_sec`가 모두 있으면 각각 차이가 **0.15초 이하**.

병합 시 더 이른 `clip_start_sec`를 보존합니다. 기본 **2초 대기** 후 측정 작업에 제출하므로
중복 후보가 도착할 시간은 확보하면서 프레임 수집은 계속됩니다.

## 사용법

변경 파일만 기존 프로젝트에 덮어쓰기하세요. 기존 `scripts`, `roi.txt`,
`src/streaming/event_worker.py`는 그대로 유지해도 됩니다.

```bat
python analyze.py ^
  --video data\videos\test.mp4 ^
  --output output\analysis_dedup_v5 ^
  --save-intermediates all
```

**기존 출력 폴더를 재사용하지 마세요.** `StreamAnalyzer`는 기존 `integrated_results.csv`의
행을 보존하고 신규 행을 추가하도록 되어 있습니다. 즉 기존 32개가 있는 폴더에
같은 영상을 재실행하면 예전 중복 이벤트가 그대로 남습니다. 새 출력 디렉터리를 사용하세요.

옵션(모두 `main.py`, `analyze.py`, `operate.py`에서 사용 가능):

```text
--duplicate-merge-sec 2
--duplicate-end-tolerance-sec 0.15
--duplicate-peak-tolerance-sec 3
```

`--save-intermediates all` 실행 시:

- `detected_events.csv`: **중복 병합 이후** 이벤트 한 행씩
- `duplicate_events.csv`: 병합/차단된 후보 기록
- `summary.json`: `type2_candidates`, `duplicate_candidates_merged`,
  `duplicate_candidates_late_suppressed`, `type2_events` (최종 중복 제거 개수)
- `runtime_metrics.json`: 동일 중복 제거 통계 포함

## 기존 32건 점검하기

```bat
python tools\audit_duplicate_events.py ^
  --results output\analysis\integrated_results.csv
```

원본 CSV와 이벤트 폴더를 변경하지 않고 다음 미리보기를 생성합니다.

- `duplicate_audit.csv`: 병합 제안 그룹, KEEP / REVIEW_DUPLICATE
- `deduplicated_preview.csv`: 중복 제외한 결과 미리보기

실제 기존 32건의 상태, 클립과 Gap을 살펴본 다음에만 별도 수동으로 폴더 정리를 진행하세요.

## 테스트

```bat
python -m pytest -q tests/test_event_dedup.py tests/test_streaming.py
```

모의/샘플 테스트는 실제 영상에서 25/25 Type2 검출을 보장하지 않습니다.
실제 결과에서는 `detected_events.csv`, `duplicate_events.csv` 및
`measurement_selection_failed` 건수, 전체 25개 시점, Gap 값을 비교해야 합니다.
