"""Sequential frame inspection with asynchronous per-event jobs.

Threads:
  capture -> bounded motion queue -> single motion/event worker (caller thread)
          -> bounded JPEG spool queue -> archive thread (live sources only)
  E3 finalizes a Type2 event -> job executor -> A2/A3 + B + event artifacts

In live mode frame queue overflow is explicitly measured and reported. Increasing
thread count does not make a slower-than-camera detector lossless by itself.
"""
from __future__ import annotations

import csv
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime
import json
import queue
import threading
import time
import traceback
from pathlib import Path

import cv2
import numpy as np
import pandas as pd

from src.core_install import install_algorithms
from src.roi_config import resolve_rois
from src.motion.realtime import SingleBladeMotion
from src.events.online import OnlineType2Events
from .archive import RollingArchive


@dataclass
class StreamOptions:
    project_root: Path
    video: Path | None
    output: Path
    bright_reference: Path
    dark_reference: Path
    roi_file: Path | None = None
    live_source: str | None = None
    roi_overrides: dict | None = None
    save_intermediates: str = 'none'
    sync_algorithms: bool = False
    analysis_width: int = 480
    detail_scale: float = 2.0
    measurement_source: str = 'original'
    jpeg_quality: int = 98
    normal_x_ratio: float = 0.7
    dark_x_ratio: float = 0.7
    cst_motion_threshold: float = -2.0
    type2_peak_min: float = -8.0
    type2_peak_max: float = -2.0
    duplicate_merge_sec: float = 2.0
    duplicate_end_tolerance_sec: float = 0.15
    duplicate_peak_tolerance_sec: float = 3.0
    valley_threshold: float = 0.06
    rise_threshold: float = 0.075
    rise_delta: float = 0.055
    lead_frames: int = 1
    capture_queue: int = 12
    archive_queue: int = 24
    event_workers: int = 1
    pending_events: int = 4
    archive_seconds: float = 45.
    archive_mb: float = 512.
    archive_jpeg_quality: int = 90
    archive_wait_sec: float = 20.
    fallback_fps: float = 15.
    opencv_threads: int = 2
    max_frames: int = 0
    max_seconds: float = 0.
    reconnect_delay: float = 2.
    reconnect_attempts: int = 10
    dry_run: bool = False
    session_id: str | None = None

    @property
    def is_live(self):
        return self.live_source is not None


@dataclass
class CapturedFrame:
    index: int
    second: float
    frame: np.ndarray


class StreamAnalyzer:
    def __init__(self, options: StreamOptions):
        self.o = options
        self.rois = resolve_rois(options.roi_file, options.roi_overrides)
        self.metrics = {
            'captured_frames': 0,
            'processed_frames': 0,
            'motion_input_gaps': 0,
            'dropped_motion_frames': 0,
            'dropped_archive_frames': 0,
            'events_detected': 0,
            'events_completed': 0,
            'events_rejected_overload': 0,
            'max_motion_queue': 0,
            'max_archive_queue': 0,
            'motion_compute_sec': 0.,
            'uptime_sec': 0.,
        }
        self.completed = []
        self.previous_records = []
        self.session_id = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        self.events = []
        self._result_lock = threading.Lock()
        self._error = None

    def validate(self):
        o = self.o
        for name, path in [('bright reference', o.bright_reference), ('dark reference', o.dark_reference)]:
            if not Path(path).is_file():
                raise FileNotFoundError(f'{name}: {path}')
        if o.is_live and o.video is not None:
            raise ValueError('Choose --source (live) or --video (file), not both')
        if not o.is_live and (o.video is None or not o.video.is_file()):
            raise FileNotFoundError(f'Video file not found: {o.video}')
        if o.measurement_source not in ('original', 'selected'):
            raise ValueError('measurement_source must be original or selected')
        if o.save_intermediates not in ('none', 'all'):
            raise ValueError('save_intermediates must be none or all')
        if o.capture_queue <= 0 or o.archive_queue <= 0 or o.event_workers < 1:
            raise ValueError('Invalid queue/worker size')
        if o.analysis_width < 32 or o.archive_seconds < 10 or o.archive_mb < 10:
            raise ValueError('Invalid motion/recording settings')
        if o.type2_peak_min >= o.type2_peak_max:
            raise ValueError('Invalid Type2 dy band')
        if (o.duplicate_merge_sec < 0 or o.duplicate_end_tolerance_sec < 0
                or o.duplicate_peak_tolerance_sec < 0):
            raise ValueError('Invalid event deduplication parameters')
        if o.pending_events < o.event_workers:
            raise ValueError('--pending-events must be >= --event-workers')
        # Image ROI must be inside image; actual validation occurs on first frame.

    def _source_cap(self):
        source = self.o.live_source if self.o.is_live else str(self.o.video)
        if source is not None and isinstance(source, str) and source.isdecimal():
            source = int(source)
        if isinstance(source, str) and '!' in source and 'appsink' in source:
            cap = cv2.VideoCapture(source, cv2.CAP_GSTREAMER)
        else:
            cap = cv2.VideoCapture(source)
        # Best-effort latency control. Many FFmpeg/RTSP backends ignore this;
        # for strict low latency supply a GStreamer appsink pipeline instead.
        if self.o.is_live and cap.isOpened():
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        return cap

    def _save_status(self, started, final=False):
        self.metrics['uptime_sec'] = round(time.perf_counter() - started, 3)
        uptime = max(self.metrics['uptime_sec'], 1e-6)
        self.metrics['capture_fps_average'] = round(self.metrics['captured_frames'] / uptime, 2)
        self.metrics['analysis_fps_average'] = round(self.metrics['processed_frames'] / uptime, 2)
        elapsed = self.metrics['motion_compute_sec']
        self.metrics['motion_capacity_fps'] = round(self.metrics['processed_frames'] / elapsed, 2) if elapsed else None
        self.metrics['mode'] = 'operation' if self.o.is_live else 'analysis'
        self.metrics['input_loss_present'] = bool(
            self.metrics['dropped_motion_frames'] or self.metrics['dropped_archive_frames']
            or self.metrics['motion_input_gaps']
        )
        if getattr(self, '_source_fps', None):
            self.metrics['source_fps'] = round(self._source_fps, 3)
            self.metrics['motion_capacity_above_source_fps'] = (
                self.metrics['motion_capacity_fps'] is not None
                and self.metrics['motion_capacity_fps'] >= self._source_fps
            )
        if final:
            self.metrics['finished_at'] = datetime.now().isoformat(timespec='seconds')
        path = self.o.output / 'runtime_metrics.json'
        path.write_text(json.dumps(self.metrics, ensure_ascii=False, indent=2), encoding='utf-8')

    def _save_records(self):
        with self._result_lock:
            records = list(self.completed)
        frame = pd.DataFrame([*self.previous_records, *records])
        dest = self.o.output / 'integrated_results.csv'
        frame.to_csv(dest.with_suffix('.csv.tmp'), index=False, encoding='utf-8-sig')
        dest.with_suffix('.csv.tmp').replace(dest)

    def _on_done(self, future):
        try:
            rec = future.result()
        except Exception as exc:
            rec = {'status': 'unhandled_worker_exception', 'error': repr(exc)}
            traceback.print_exc()
        with self._result_lock:
            self.completed.append(rec)
            self.metrics['events_completed'] += 1
        self._save_records()

    def run(self):
        self.validate()
        o = self.o
        if o.dry_run:
            return {'mode': 'operation' if o.is_live else 'analysis', 'rois': self.rois,
                    'signal_rois': {'cst': self.rois['cst_motion_roi'],
                                    'blade2': self.rois['blade_motion_primary_roi']},
                    'optical_flow_computed': False,
                    'output': str(o.output)}
        # OpenCV internal worker pools can otherwise contend with our own threads.
        cv2.setNumThreads(max(1, o.opencv_threads))
        print('[BOOTSTRAP] Installing/validating verified algorithm modules', flush=True)
        install_algorithms(o.project_root, sync=o.sync_algorithms)
        # Lazily import code installed from scripts/ on first run.
        from src.motion.realtime import SingleBladeMotion as Signal
        from src.events.online import OnlineType2Events as Detector
        from .event_worker import EventProcessor as Processor

        o.output.mkdir(parents=True, exist_ok=True)
        (o.output / 'events').mkdir(exist_ok=True)
        o.session_id = self.session_id
        existing_results = o.output / 'integrated_results.csv'
        if existing_results.exists() and existing_results.stat().st_size > 0:
            old = pd.read_csv(existing_results)
            self.previous_records = old.where(pd.notna(old), None).to_dict('records')
            print(f'[RESUME] Keeping {len(self.previous_records)} prior event result rows', flush=True)
        cap = self._source_cap()
        if not cap.isOpened():
            raise RuntimeError(f'Cannot open video/camera source: {o.live_source or o.video}')
        fps = float(cap.get(cv2.CAP_PROP_FPS))
        if fps < 1 or fps > 120:
            fps = o.fallback_fps
        self._source_fps = fps
        print(f'[INPUT] fps={fps:.2f}, mode={"LIVE" if o.is_live else "FILE"}', flush=True)
        sig = Signal(self.rois['cst_motion_roi'], self.rois['blade_motion_primary_roi'], o.analysis_width)
        detector = Detector(cst_motion_threshold=o.cst_motion_threshold,
                            type2_peak_min=o.type2_peak_min, type2_peak_max=o.type2_peak_max,
                            duplicate_merge_sec=o.duplicate_merge_sec,
                            duplicate_end_tolerance_sec=o.duplicate_end_tolerance_sec,
                            duplicate_peak_tolerance_sec=o.duplicate_peak_tolerance_sec)
        archive = RollingArchive(o.archive_seconds, o.archive_mb) if o.is_live else None
        processor = Processor(o, self.rois, fps, archive)
        source_is_local_file = bool(o.is_live and Path(str(o.live_source)).is_file())
        signal_queue = queue.Queue(maxsize=o.capture_queue)
        archive_queue = queue.Queue(maxsize=o.archive_queue) if o.is_live else None
        stop = threading.Event()
        capture_finished = threading.Event()
        started = time.perf_counter()
        sentinel = object()
        workers = ThreadPoolExecutor(max_workers=o.event_workers, thread_name_prefix='event')
        slots = threading.BoundedSemaphore(o.pending_events)
        completed_futures = []
        log_writer = None
        log_file = None
        if o.save_intermediates == 'all':
            log_file = (o.output / 'motion_signals.csv').open('w', newline='', encoding='utf-8-sig')
            log_writer = csv.DictWriter(log_file, fieldnames=[
                'frame_idx', 'time_sec', 'video_time', 'cst_dx', 'cst_dy',
                'cst_phase_response', 'blade2_motion_ratio', 'blade2_mean_diff',
            ])
            log_writer.writeheader()

        def put_live(q, item, metric):
            try:
                q.put_nowait(item)
            except queue.Full:
                # Latest-frame policy: avoid ever blocking the RTSP reader.
                try:
                    q.get_nowait()
                    self.metrics[metric] += 1
                except queue.Empty:
                    pass
                try:
                    q.put_nowait(item)
                except queue.Full:
                    self.metrics[metric] += 1

        def capture_loop():
            idx = 0
            retries = 0
            capture_start = time.monotonic()
            try:
                while not stop.is_set():
                    if o.max_frames and idx >= o.max_frames:
                        break
                    if o.max_seconds and (time.monotonic() - capture_start) >= o.max_seconds:
                        break
                    # Local video passed to operation is replayed at camera rate.
                    if source_is_local_file:
                        delay = idx / fps - (time.monotonic() - capture_start)
                        if delay > 0 and stop.wait(delay):
                            break
                    ok, img = active[0].read()
                    if not ok or img is None:
                        if not o.is_live or source_is_local_file:
                            break
                        retries += 1
                        print(f'[CAPTURE] read failure, reconnect {retries}', flush=True)
                        active[0].release()
                        if o.reconnect_attempts > 0 and retries > o.reconnect_attempts:
                            self._error = 'Camera reconnect limit exceeded'
                            break
                        if stop.wait(o.reconnect_delay):
                            break
                        reconnected = self._source_cap()
                        if reconnected.isOpened():
                            active[0] = reconnected
                        else:
                            reconnected.release()
                        continue
                    retries = 0
                    second = time.monotonic() - capture_start if o.is_live and not source_is_local_file else idx / fps
                    captured = CapturedFrame(idx, second, img)
                    self.metrics['captured_frames'] += 1
                    if o.is_live:
                        put_live(signal_queue, captured, 'dropped_motion_frames')
                        put_live(archive_queue, captured, 'dropped_archive_frames')
                        self.metrics['max_archive_queue'] = max(
                            self.metrics['max_archive_queue'], archive_queue.qsize())
                    else:
                        signal_queue.put(captured)  # lossless file analysis, backpressure
                    self.metrics['max_motion_queue'] = max(
                        self.metrics['max_motion_queue'], signal_queue.qsize())
                    idx += 1
            except Exception as exc:
                self._error = f'Capture error: {type(exc).__name__}: {exc}'
                traceback.print_exc()
            finally:
                capture_finished.set()
                if o.is_live:
                    archive_queue.put(sentinel)
                signal_queue.put(sentinel)
                active[0].release()

        # mutable cap holder is required during RTSP reconnects
        active = [cap]

        def record_loop():
            while True:
                item = archive_queue.get()
                if item is sentinel:
                    break
                try:
                    archive.put(item.index, item.second, item.frame, o.archive_jpeg_quality)
                except Exception as exc:
                    self._error = f'Archive error: {exc}'
            archive.close()

        writer_thread = None
        if o.is_live:
            writer_thread = threading.Thread(target=record_loop, name='jpeg-archive', daemon=True)
            writer_thread.start()
        reader = threading.Thread(target=capture_loop, name='capture', daemon=True)
        reader.start()

        recent_gaps = []

        def submit_event(event):
            # A missing input frame can break temporal-motion calibration.
            # Never silently claim an uninterrupted event window.
            event['motion_frame_loss_near_event'] = any(
                event['clip_start_sec'] - 2 <= t <= event['detected_at_sec']
                for t in recent_gaps
            )
            self.metrics['events_detected'] += 1
            self.events.append(event)
            print(f'[DETECTED] Type2 #{event["event_id"]:04d} '
                  f'at t={event["cst_peak_sec"]:.3f}s', flush=True)
            if not slots.acquire(blocking=False):
                self.metrics['events_rejected_overload'] += 1
                print('[OVERLOAD] Event worker queue full; record alert', flush=True)
                rejected = processor.save_rejected(event, 'event_queue_overflow')
                with self._result_lock:
                    self.completed.append(rejected)
                self._save_records()
                return
            fut = workers.submit(processor.process, event)
            completed_futures.append(fut)
            def callback(done):
                try:
                    self._on_done(done)
                finally:
                    slots.release()
            fut.add_done_callback(callback)

        try:
            prev_idx = None
            last_report = time.monotonic()
            while True:
                sample = signal_queue.get()
                if sample is sentinel:
                    break
                if prev_idx is not None and sample.index != prev_idx + 1:
                    self.metrics['motion_input_gaps'] += (sample.index - prev_idx - 1)
                    recent_gaps.append(sample.second)
                recent_gaps[:] = [t for t in recent_gaps if sample.second - t < 60.]
                prev_idx = sample.index
                t0 = time.perf_counter()
                row = sig.process(sample.frame, sample.index, sample.second)
                self.metrics['motion_compute_sec'] += time.perf_counter() - t0
                self.metrics['processed_frames'] += 1
                if row is not None:
                    if log_writer is not None:
                        log_writer.writerow(row)
                    for event in detector.add(row):
                        submit_event(event)
                if time.monotonic() - last_report > 5:
                    self._save_status(started)
                    if (o.is_live and self.metrics['motion_capacity_fps'] is not None
                        and self.metrics['motion_capacity_fps'] < fps):
                        print(f'[WARN] Motion capacity {self.metrics["motion_capacity_fps"]} '
                              f'FPS below reported source {fps:.1f} FPS; '
                              'frame loss is possible', flush=True)
                    print(f'[FPS] capture={self.metrics["capture_fps_average"]} '
                          f'motion={self.metrics["analysis_fps_average"]} '
                          f'capacity={self.metrics["motion_capacity_fps"]} '
                          f'drop_motion={self.metrics["dropped_motion_frames"]} '
                          f'drop_record={self.metrics["dropped_archive_frames"]} '
                          f'jobs={self.metrics["events_detected"]}', flush=True)
                    if log_file:
                        log_file.flush()
                    last_report = time.monotonic()
        except KeyboardInterrupt:
            print('[STOP] Interrupted, draining workers', flush=True)
        finally:
            # Emit pending, already-settled Type2 candidates before shutting
            # down workers. Otherwise a clip near MP4 EOF would be lost only
            # because the short duplicate-coalescing window had not expired.
            for event in detector.flush():
                submit_event(event)
            self.metrics.update(detector.statistics())
            stop.set()
            reader.join(timeout=15)
            if writer_thread is not None:
                writer_thread.join(timeout=30)
            workers.shutdown(wait=True, cancel_futures=False)
            if log_file:
                log_file.close()
            if o.save_intermediates == 'all':
                pd.DataFrame(self.events).to_csv(
                    o.output / 'detected_events.csv', index=False, encoding='utf-8-sig')
                pd.DataFrame(detector.dedup_log, columns=[
                    'reason', 'kept_cst_peak_sec', 'duplicate_cst_peak_sec',
                    'kept_clip_start_sec', 'duplicate_clip_start_sec',
                    'clip_end_sec', 'kept_event_id',
                ]).to_csv(o.output / 'duplicate_events.csv', index=False, encoding='utf-8-sig')
            self._save_records()
            self._save_status(started, final=True)
            summary = {
                'session_id': self.session_id,
                'type2_events': self.metrics['events_detected'],
                'type2_candidates': self.metrics['type2_candidates'],
                'duplicate_candidates_merged': self.metrics['duplicate_candidates_merged'],
                'duplicate_candidates_late_suppressed': self.metrics['duplicate_candidates_late_suppressed'],
                'completed_jobs': self.metrics['events_completed'],
                'statuses': pd.Series([r.get('status') for r in self.completed]).value_counts().to_dict(),
                'capture_fps_average': self.metrics['capture_fps_average'],
                'analysis_fps_average': self.metrics['analysis_fps_average'],
                'motion_capacity_fps': self.metrics['motion_capacity_fps'],
                'source_fps': self.metrics.get('source_fps'),
                'motion_capacity_above_source_fps': self.metrics.get('motion_capacity_above_source_fps'),
                'dropped_motion_frames': self.metrics['dropped_motion_frames'],
                'dropped_archive_frames': self.metrics['dropped_archive_frames'],
                'motion_input_gaps': self.metrics['motion_input_gaps'],
                'error': self._error,
            }
            (o.output / 'summary.json').write_text(
                json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
            print('[FINAL]', summary, flush=True)
        return summary
