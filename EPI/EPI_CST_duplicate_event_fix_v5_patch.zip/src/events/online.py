"""Incremental Type2 event detection with duplicate Blade-OUT coalescing.

The original E3 CST grouping and IN/OUT searches are unchanged. A single real
Type2 movement can be split into multiple CST candidate groups, which may both
select the *same* Blade OUT and produce overlapping clips with the same end.

This module holds ready candidates briefly, merges those sharing a close clip
end / Blade OUT boundary, then emits exactly one job per group. Late repeats
are suppressed against a small recent-emission cache. `flush()` must be called
at source EOF, so completed candidates are not stranded in the merge window.
"""
from __future__ import annotations

from collections import deque
import math
import pandas as pd


class OnlineType2Events:
    def __init__(
        self,
        *,
        cst_motion_threshold=-2.,
        type2_peak_min=-8.,
        type2_peak_max=-2.,
        history_sec=40.,
        check_interval_sec=0.5,
        duplicate_merge_sec=2.0,
        duplicate_end_tolerance_sec=0.15,
        duplicate_peak_tolerance_sec=3.0,
        duplicate_min_overlap=0.85,
    ):
        from . import _event_core as core
        self.core = core
        self.cfg = core.Config(
            blade_name='blade2',
            cst_motion_threshold=cst_motion_threshold,
            cst_type2_peak_min=type2_peak_min,
            cst_type2_peak_max=type2_peak_max,
        )
        self.history = deque()
        self.history_sec = float(history_sec)
        self.check_interval = float(check_interval_sec)
        self.last_check = -1e12
        self.processed_peaks = set()
        self.next_id = 1

        self.duplicate_merge_sec = float(duplicate_merge_sec)
        self.duplicate_end_tolerance_sec = float(duplicate_end_tolerance_sec)
        self.duplicate_peak_tolerance_sec = float(duplicate_peak_tolerance_sec)
        self.duplicate_min_overlap = float(duplicate_min_overlap)
        if self.duplicate_merge_sec < 0 or self.duplicate_end_tolerance_sec < 0:
            raise ValueError('Invalid duplicate merge window or end tolerance')
        if self.duplicate_peak_tolerance_sec < 0 or not 0 < self.duplicate_min_overlap <= 1:
            raise ValueError('Invalid duplicate peak tolerance or overlap ratio')

        self.pending = []  # {'event', 'ready_at_sec'}
        self.recent_emitted = deque()  # {'event', 'emit_time_sec'}
        self.dedup_log = []
        self.candidates_total = 0
        self.duplicates_merged = 0
        self.duplicates_late_suppressed = 0
        self.events_emitted = 0

    @staticmethod
    def _number(event, key):
        try:
            value = float(event.get(key))
            return value if math.isfinite(value) else None
        except (ValueError, TypeError):
            return None

    def _same_physical_event(self, first, second):
        """Reject unrelated events despite occasional overlapping time ranges.

        Matching the output Blade OUT interval (when available) and the *same*
        end of a largely overlapping clip is stronger than matching the CST
        peak alone. Require the candidates to be temporally close as well.
        """
        a_end = self._number(first, 'clip_end_sec')
        b_end = self._number(second, 'clip_end_sec')
        if a_end is None or b_end is None:
            return False
        if abs(a_end - b_end) > self.duplicate_end_tolerance_sec:
            return False

        a_peak = self._number(first, 'cst_peak_sec')
        b_peak = self._number(second, 'cst_peak_sec')
        if (a_peak is None or b_peak is None
                or abs(a_peak - b_peak) > self.duplicate_peak_tolerance_sec):
            return False

        a_start = self._number(first, 'clip_start_sec')
        b_start = self._number(second, 'clip_start_sec')
        if a_start is None or b_start is None:
            return False
        a_len, b_len = a_end - a_start, b_end - b_start
        if a_len <= 0 or b_len <= 0:
            return False
        overlap = max(0., min(a_end, b_end) - max(a_start, b_start))
        if overlap / min(a_len, b_len) < self.duplicate_min_overlap:
            return False

        # When both candidates have explicit Blade OUT boundaries, they must
        # also refer to the same Blade OUT, not merely overlapping clips.
        for key in ('blade_out_start_sec', 'blade_out_end_sec'):
            a_out = self._number(first, key)
            b_out = self._number(second, key)
            if (a_out is not None and b_out is not None
                    and abs(a_out - b_out) > self.duplicate_end_tolerance_sec):
                return False
        return True

    def _record_duplicate(self, kept, suppressed, *, reason):
        self.dedup_log.append({
            'reason': reason,
            'kept_cst_peak_sec': self._number(kept, 'cst_peak_sec'),
            'duplicate_cst_peak_sec': self._number(suppressed, 'cst_peak_sec'),
            'kept_clip_start_sec': self._number(kept, 'clip_start_sec'),
            'duplicate_clip_start_sec': self._number(suppressed, 'clip_start_sec'),
            'clip_end_sec': self._number(kept, 'clip_end_sec'),
            'kept_event_id': kept.get('event_id'),
        })

    def _queue_candidate(self, event, current_time_sec):
        self.candidates_total += 1
        event = dict(event)
        # E3 uses event_id=1 when invoked on a single group. The online
        # detector assigns a final ordinal only upon unique-event emission.
        event.pop('event_id', None)
        event['detected_at_sec'] = float(current_time_sec)
        event['duplicate_candidate_count'] = 1

        for item in self.pending:
            kept = item['event']
            if not self._same_physical_event(kept, event):
                continue
            # Preserve the earliest clip start so A2/A3 have all Blade-IN
            # context; keep whichever event supplied that earliest boundary.
            use_incoming = event['clip_start_sec'] < kept['clip_start_sec']
            new_kept = dict(event if use_incoming else kept)
            new_kept['clip_start_sec'] = min(
                float(kept['clip_start_sec']), float(event['clip_start_sec']))
            new_kept['clip_end_sec'] = max(
                float(kept['clip_end_sec']), float(event['clip_end_sec']))
            new_kept['detected_at_sec'] = max(
                float(kept['detected_at_sec']), float(current_time_sec))
            new_kept['duplicate_candidate_count'] = int(
                kept.get('duplicate_candidate_count', 1)) + 1
            item['event'] = new_kept
            # Give a later-arriving CST sub-group a little time to stabilize.
            item['ready_at_sec'] = max(
                item['ready_at_sec'], current_time_sec + self.duplicate_merge_sec)
            self.duplicates_merged += 1
            self._record_duplicate(new_kept, kept if use_incoming else event,
                                   reason='same_blade_out_pending')
            return

        # Normally no event matches recent_emitted because the pending
        # window absorbs close duplicates. This guard catches delayed ones.
        for item in self.recent_emitted:
            if self._same_physical_event(item['event'], event):
                self.duplicates_late_suppressed += 1
                self._record_duplicate(item['event'], event, reason='same_blade_out_late')
                return

        self.pending.append({
            'event': event,
            'ready_at_sec': current_time_sec + self.duplicate_merge_sec,
        })

    def _emit_due(self, current_time_sec, *, force=False):
        emitted = []
        still_pending = []
        for item in self.pending:
            if not force and current_time_sec < item['ready_at_sec']:
                still_pending.append(item)
                continue
            event = item['event']
            # If two pending groups became duplicates after a time-boundary
            # change, the recent cache is a final safety net.
            previous = next((p for p in self.recent_emitted
                             if self._same_physical_event(p['event'], event)), None)
            if previous is not None:
                self.duplicates_late_suppressed += 1
                self._record_duplicate(previous['event'], event,
                                       reason='same_blade_out_at_emit')
                continue
            event['event_id'] = self.next_id
            self.next_id += 1
            self.events_emitted += 1
            emitted.append(event)
            self.recent_emitted.append({
                'event': dict(event),
                'emit_time_sec': current_time_sec,
            })
        self.pending = still_pending
        # Bound the recent-emission cache in long-running CCTV sessions.
        while (self.recent_emitted
               and current_time_sec - self.recent_emitted[0]['emit_time_sec'] > self.history_sec):
            self.recent_emitted.popleft()
        return emitted

    def add(self, row):
        t = float(row['time_sec'])
        self.history.append(row)
        while self.history and t - float(self.history[0]['time_sec']) > self.history_sec:
            old = self.history.popleft()
            self.processed_peaks.discard(int(old['frame_idx']))

        if t - self.last_check < self.check_interval or len(self.history) < 4:
            return self._emit_due(t)
        self.last_check = t

        signals = pd.DataFrame(list(self.history))
        signals = signals.sort_values('time_sec').reset_index(drop=True)
        mask = signals['cst_dy'].to_numpy() <= self.cfg.cst_motion_threshold
        groups = self.core.find_boolean_groups(
            signals, mask, max_gap_sec=self.cfg.cst_group_gap_sec,
            min_duration_sec=self.cfg.cst_min_event_sec,
        )
        # Retain E3's future Blade OUT search so a candidate has a usable clip
        # end before entering the dedup queue.
        settle = self.cfg.blade_out_search_sec + self.cfg.cst_group_gap_sec + 0.15
        for group in groups:
            if t < float(group['end_time']) + settle:
                continue
            local = signals.iloc[group['start_idx']:group['end_idx'] + 1]
            peak_row = local.loc[local['cst_dy'].idxmin()]
            peak = float(peak_row['cst_dy'])
            peak_frame = int(peak_row['frame_idx'])
            if peak_frame in self.processed_peaks:
                continue
            self.processed_peaks.add(peak_frame)
            if not (self.cfg.cst_type2_peak_min < peak <= self.cfg.cst_type2_peak_max):
                continue
            cst = {
                'raw_event_id': peak_frame,
                'cst_start_time': float(group['start_time']),
                'cst_end_time': float(group['end_time']),
                'cst_peak_time': float(peak_row['time_sec']),
                'cst_peak_dy': peak,
                'cst_peak_frame': peak_frame,
                'cst_duration_sec': float(group['duration']),
            }
            built = self.core.build_type2_events(signals, [cst], self.cfg)
            if built:
                self._queue_candidate(built[0], t)
        return self._emit_due(t)

    def flush(self):
        """Emit finalized-but-pending candidates when an MP4/camera run ends."""
        t = float(self.history[-1]['time_sec']) if self.history else 0.
        return self._emit_due(t, force=True)

    def statistics(self):
        return {
            'type2_candidates': self.candidates_total,
            'duplicate_candidates_merged': self.duplicates_merged,
            'duplicate_candidates_late_suppressed': self.duplicates_late_suppressed,
            'unique_type2_events': self.events_emitted,
            'pending_candidate_groups': len(self.pending),
        }
