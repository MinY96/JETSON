"""Regression tests for repeated Type2 candidates sharing a Blade OUT."""
from __future__ import annotations

import sys
import types
from dataclasses import dataclass
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# Minimal E3 functions, avoiding a dependency on the user's legacy scripts
# for detector-specific tests. The production implementation imports E3 core.
fake = types.ModuleType('src.events._event_core')


@dataclass
class Config:
    blade_name: str = 'blade2'
    cst_motion_threshold: float = -2.
    cst_type2_peak_min: float = -8.
    cst_type2_peak_max: float = -2.
    cst_group_gap_sec: float = .40
    cst_min_event_sec: float = .03
    blade_out_search_sec: float = 3.0


def find_boolean_groups(df, mask, max_gap_sec, min_duration_sec):
    indices = np.flatnonzero(mask)
    if not len(indices):
        return []
    groups, current = [], [int(indices[0])]
    for idx in indices[1:]:
        idx = int(idx)
        if float(df.iloc[idx]['time_sec']) - float(df.iloc[current[-1]]['time_sec']) <= max_gap_sec:
            current.append(idx)
        else:
            groups.append(current)
            current = [idx]
    groups.append(current)
    return [dict(start_idx=g[0], end_idx=g[-1],
                 start_time=float(df.iloc[g[0]]['time_sec']),
                 end_time=float(df.iloc[g[-1]]['time_sec']),
                 duration=float(df.iloc[g[-1]]['time_sec'] - df.iloc[g[0]]['time_sec']))
            for g in groups if len(g) >= 2]


def build_type2_events(df, cst_events, cfg):
    return [dict(cst_peak_sec=x['cst_peak_time'], cst_peak_dy=x['cst_peak_dy'],
                 clip_start_sec=max(0, x['cst_start_time'] - .5),
                 clip_end_sec=6.0, blade_out_start_sec=5.0, blade_out_end_sec=5.5,
                 blade_out_source='blade', sequence_score=1.0)
            for x in cst_events]


fake.Config = Config
fake.find_boolean_groups = find_boolean_groups
fake.build_type2_events = build_type2_events
sys.modules['src.events._event_core'] = fake

from src.events.online import OnlineType2Events


PAIRS = [
    (653.7, 656.83, 652.53, 656.83),
    (2286.76, 2289.96, 2285.6, 2289.96),
    (2620.56, 2623.83, 2619.46, 2623.83),
    (3595.1, 3598.3, 3593.86, 3598.3),
    (3745.43, 3748.63, 3744.26, 3748.63),
    (4238.23, 4241.7, 4237.06, 4241.7),
    (4344.76, 4348.3, 4343.73, 4348.3),
]


def make_event(start, end, peak):
    return dict(cst_peak_sec=peak, clip_start_sec=start, clip_end_sec=end,
                blade_out_start_sec=end - .9, blade_out_end_sec=end - .5,
                blade_out_source='blade', sequence_score=1.)


def test_reported_seven_duplicate_pairs():
    det = OnlineType2Events()
    t = 0.
    for i, (sa, ea, sb, eb) in enumerate(PAIRS):
        # Both candidate detections arrive after their respective CST settle.
        # The candidate with earlier clip start arrives second in this test.
        first_peak = sa + .6
        second_peak = sb + .6
        t = ea + 3.65
        det._queue_candidate(make_event(sa, ea, first_peak), t)
        det._queue_candidate(make_event(sb, eb, second_peak), t + 1.)
        emitted = det._emit_due(t + 4.)
        assert len(emitted) == 1, (i, emitted)
        assert emitted[0]['clip_start_sec'] == sb
        assert emitted[0]['clip_end_sec'] == ea
        assert emitted[0]['duplicate_candidate_count'] == 2
        assert emitted[0]['event_id'] == i + 1
    assert det.candidates_total == 14
    assert det.duplicates_merged == 7
    assert det.events_emitted == 7


def test_distinct_events_with_different_out_kept():
    d = OnlineType2Events()
    d._queue_candidate(make_event(10., 14., 12.), 18.)
    d._queue_candidate(make_event(12., 16., 14.), 18.5)
    emitted = d._emit_due(23.)
    assert len(emitted) == 2
    assert d.duplicates_merged == 0


def test_late_duplicate_is_blocked_after_emission():
    d = OnlineType2Events()
    d._queue_candidate(make_event(11., 15., 12.), 18.)
    assert len(d._emit_due(21.)) == 1
    d._queue_candidate(make_event(10., 15., 11.5), 22.)
    assert d.flush() == []
    assert d.duplicates_late_suppressed == 1


def test_stream_add_and_flush_at_eof():
    d = OnlineType2Events(check_interval_sec=.1, duplicate_merge_sec=2.)
    emitted = []
    for frame in range(101):
        sec = frame / 15.
        dy = -5. if frame in (15, 16, 30, 31) else 0.
        emitted += d.add(dict(frame_idx=frame, time_sec=sec,
                              cst_dy=dy, blade2_motion_ratio=.1))
    emitted += d.flush()
    assert len(emitted) == 1, emitted
    assert d.candidates_total == 2, d.statistics()
    assert d.duplicates_merged == 1
    assert emitted[0]['duplicate_candidate_count'] == 2


def test_flush_keeps_completed_candidate_at_eof():
    d = OnlineType2Events()
    d._queue_candidate(make_event(10., 13., 11.), 14.)
    assert len(d.flush()) == 1
    assert len(d.flush()) == 0


if __name__ == '__main__':
    for name, f in sorted(globals().items()):
        if name.startswith('test_') and callable(f):
            f()
            print('[OK]', name)
    print('EVENT DEDUP TESTS PASSED')
