"""Entry point: python main.py --video data/videos/example.mp4 [options]."""
from __future__ import annotations

import argparse
from pathlib import Path

from src.pipeline import PhaseCPipeline, PipelineOptions

PROJECT_ROOT = Path(__file__).resolve().parent


def resolve(path):
    if path is None:
        return None
    p = Path(path)
    return p if p.is_absolute() else (PROJECT_ROOT / p)


def build_parser():
    p = argparse.ArgumentParser(description="EPI CST Type2 / Blade-Wafer gap modular pipeline")
    p.add_argument("--video", required=True, help="Original MP4, relative to project root")
    p.add_argument("--output", default="output/phase_c")
    p.add_argument("--reference-bright", default="reference/blade_left_bright.png")
    p.add_argument("--reference-dark", default="reference/blade_left_dark.png")
    p.add_argument("--gt", default=None, help="Optional Excel for validation, not required for detection")
    p.add_argument("--roi-file", default="roi.txt")
    p.add_argument("--save-stages", choices=["all", "final"], default="final",
                   help="all: keep intermediate clips/debug CSV; final: temporary intermediates deleted")
    p.add_argument("--frame-source", choices=["a3", "original"], default="a3",
                   help="a3: keep previous JPEG-based measurement parity; original: read source MP4 frame")
    p.add_argument("--temp-root", default=None, help="Temp drive with enough room for Type2 clips")
    p.add_argument("--sync-scripts", action="store_true", help="Overwrite copied src cores from scripts on demand")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--analysis-width", type=int, default=480)
    p.add_argument("--frame-step", type=int, default=1)
    for flag in ("cst-roi", "blade2-roi", "a2-blade-roi", "search-roi", "measure-roi"):
        p.add_argument("--" + flag, nargs=4, type=int, default=None)
    p.add_argument("--normal-x-ratio", type=float, default=0.7)
    p.add_argument("--dark-x-ratio", type=float, default=0.7)
    for flag in ("normal-top-offset", "normal-bottom-offset", "dark-top-offset", "dark-bottom-offset"):
        p.add_argument("--" + flag, type=float, default=0.0)
    p.add_argument("--cst-motion-threshold", type=float, default=-2.0)
    p.add_argument("--type2-peak-min", type=float, default=-8.0)
    p.add_argument("--type2-peak-max", type=float, default=-2.0)
    p.add_argument("--valley-threshold", type=float, default=0.06)
    p.add_argument("--rise-threshold", type=float, default=0.075)
    p.add_argument("--rise-delta", type=float, default=0.055)
    p.add_argument("--lead-frames", type=int, default=1)
    p.add_argument("--detail-scale", type=float, default=2.0)
    p.add_argument("--jpeg-quality", type=int, default=98)
    return p


def main():
    args = build_parser().parse_args()
    opt = PipelineOptions(
        project_root=PROJECT_ROOT, video=resolve(args.video), output=resolve(args.output),
        normal_reference=resolve(args.reference_bright), dark_reference=resolve(args.reference_dark),
        gt=resolve(args.gt), roi_file=resolve(args.roi_file),
        save_stages=args.save_stages, frame_source=args.frame_source,
        sync_scripts=args.sync_scripts, dry_run=args.dry_run,
        analysis_width=args.analysis_width, frame_step=args.frame_step,
        cst_roi=args.cst_roi, blade2_roi=args.blade2_roi, a2_blade_roi=args.a2_blade_roi,
        search_roi=args.search_roi, measure_roi=args.measure_roi,
        normal_x_ratio=args.normal_x_ratio, dark_x_ratio=args.dark_x_ratio,
        normal_top_offset=args.normal_top_offset, normal_bottom_offset=args.normal_bottom_offset,
        dark_top_offset=args.dark_top_offset, dark_bottom_offset=args.dark_bottom_offset,
        cst_motion_threshold=args.cst_motion_threshold,
        type2_peak_min=args.type2_peak_min, type2_peak_max=args.type2_peak_max,
        valley_threshold=args.valley_threshold, rise_threshold=args.rise_threshold,
        rise_delta=args.rise_delta, lead_frames=args.lead_frames,
        detail_scale=args.detail_scale, jpeg_quality=args.jpeg_quality,
        temp_root=resolve(args.temp_root),
    )
    summary = PhaseCPipeline(opt).run()
    print("\nDONE:", summary)


if __name__ == "__main__":
    main()
