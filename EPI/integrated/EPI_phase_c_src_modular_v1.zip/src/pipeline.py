"""Phase C orchestrator. Imports stage modules and invokes functions, not subprocesses."""
from __future__ import annotations

import hashlib
import json
import tempfile
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np
import pandas as pd

from .bootstrap import SOURCE_MAP, ensure_core_modules
from .settings import get_roi, load_roi_txt


@dataclass
class PipelineOptions:
    project_root: Path
    video: Path
    output: Path
    normal_reference: Path
    dark_reference: Path
    gt: Path | None = None
    roi_file: Path | None = None
    save_stages: str = "final"
    frame_source: str = "a3"
    sync_scripts: bool = False
    dry_run: bool = False
    analysis_width: int = 480
    frame_step: int = 1
    cst_roi: tuple | None = None
    blade2_roi: tuple | None = None
    a2_blade_roi: tuple | None = None
    search_roi: tuple | None = None
    measure_roi: tuple | None = None
    normal_x_ratio: float = 0.7
    dark_x_ratio: float = 0.7
    normal_top_offset: float = 0.0
    normal_bottom_offset: float = 0.0
    dark_top_offset: float = 0.0
    dark_bottom_offset: float = 0.0
    cst_motion_threshold: float = -2.0
    type2_peak_min: float = -8.0
    type2_peak_max: float = -2.0
    valley_threshold: float = 0.06
    rise_threshold: float = 0.075
    rise_delta: float = 0.055
    lead_frames: int = 1
    detail_scale: float = 2.0
    jpeg_quality: int = 98
    temp_root: Path | None = None


class PhaseCPipeline:
    def __init__(self, opt: PipelineOptions):
        self.opt = opt
        self.roi = load_roi_txt(opt.roi_file)
        self.rois = {
            "cst": get_roi(opt.cst_roi, self.roi, "cst_roi", (2039, 110, 149, 654)),
            "blade2": get_roi(opt.blade2_roi, self.roi, "blade2_roi", (309, 379, 1593, 236), "blade_roi"),
            "a2_blade": get_roi(opt.a2_blade_roi, self.roi, "a2_blade_roi", (309, 359, 1593, 216), "blade_roi"),
            "search": get_roi(opt.search_roi, self.roi, "search_roi", (41, 358, 2027, 186)),
            "measure": get_roi(opt.measure_roi, self.roi, "measure_roi", (49, 296, 600, 273)),
            "blade1": self.roi.get("blade1_roi", (16, 267, 621, 360)),
            "blade3": self.roi.get("blade3_roi", (74, 300, 1109, 302)),
        }
        if opt.save_stages not in {"all", "final"}:
            raise ValueError("save_stages must be 'all' or 'final'")
        if opt.frame_source not in {"a3", "original"}:
            raise ValueError("frame_source must be 'a3' or 'original'")
        if opt.frame_step != 1:
            print("[WARNING] E1 frame_step != 1 is not covered by original validated calibration")

    def validate(self):
        o = self.opt
        for p, name in [(o.video, "Video"), (o.normal_reference, "Bright reference"),
                        (o.dark_reference, "Dark reference")]:
            if not Path(p).is_file():
                raise FileNotFoundError(f"{name} not found: {p}")
        if o.gt is not None and not Path(o.gt).is_file():
            raise FileNotFoundError(f"GT not found: {o.gt}")
        for name, roi in self.rois.items():
            if len(roi) != 4 or any(not isinstance(v, int) for v in roi) or roi[2] <= 0 or roi[3] <= 0:
                raise ValueError(f"Invalid {name}: {roi}")
        if o.analysis_width < 16 or o.frame_step < 1 or o.lead_frames < 0:
            raise ValueError("Invalid analysis_width/frame_step/lead_frames")
        if not (0 <= o.normal_x_ratio <= 1 and 0 <= o.dark_x_ratio <= 1):
            raise ValueError("X ratios must be within [0, 1]")
        if o.detail_scale <= 0 or not (1 <= o.jpeg_quality <= 100):
            raise ValueError("Invalid visualization parameters")

    def _fps(self):
        cap = cv2.VideoCapture(str(self.opt.video))
        if not cap.isOpened():
            raise RuntimeError(f"Cannot open video: {self.opt.video}")
        fps = cap.get(cv2.CAP_PROP_FPS)
        count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        cap.release()
        if fps <= 0:
            raise ValueError("Video FPS is unavailable")
        return float(fps), count

    @staticmethod
    def _join(events, selected, measured, fps):
        selection_lookup = {int(r["event_id"]): r for _, r in selected.iterrows()} if not selected.empty else {}
        measurement_lookup = {int(r["event_id"]): r for _, r in measured.iterrows()} if not measured.empty else {}
        combined = []
        for _, event in events.iterrows():
            eid = int(event["event_id"])
            a = selection_lookup.get(eid)
            b = measurement_lookup.get(eid)
            row = {"event_id": eid, "type2_key": f"type2_{eid:03d}"}
            row.update({f"e3_{key}": value for key, value in event.items()})
            if a is not None:
                row["phase_a_status"] = a.get("status")
                row["measurement_clip_frame_idx"] = a.get("measurement_frame_idx")
                row["measurement_clip_sec"] = a.get("measurement_sec")
                row["a2_status"] = a.get("a2_status")
                row["a2_frame_idx"] = a.get("a2_frame_idx")
                row["a3_valley_frame"] = a.get("a3_valley_frame")
                row["a3_rise_frame"] = a.get("a3_rise_frame")
            else:
                row["phase_a_status"] = "missing"
            if b is not None:
                row.update({key: value for key, value in b.items() if key != "event_id"})
            else:
                row["status"] = "phase_b_missing"
            frame_idx = row.get("measurement_clip_frame_idx")
            if frame_idx is not None and pd.notna(frame_idx):
                # E3 export_clips uses floor(start_sec*fps) as the first clip frame.
                absolute_frame = int(np.floor(float(event["clip_start_sec"]) * fps)) + int(frame_idx)
                row["source_frame_idx"] = absolute_frame
                row["source_video_sec"] = absolute_frame / fps
            else:
                row["source_frame_idx"] = None
                row["source_video_sec"] = None
            row["overlay_path"] = f"overlay/type2_{eid:03d}.jpg" if b is not None and b.get("status") not in {"error", "a3_not_available"} else ""
            row["detail_path"] = f"detail/type2_{eid:03d}.jpg" if row["overlay_path"] else ""
            combined.append(row)
        return pd.DataFrame(combined)

    @staticmethod
    def _summary(result_df, gt_result, elapsed):
        statuses = (result_df["status"].fillna("missing").value_counts().to_dict()
                    if not result_df.empty and "status" in result_df else {})
        data = {"type2_events": len(result_df),
                "statuses": {str(k): int(v) for k, v in statuses.items()},
                "measurement_frames": int(result_df["measurement_clip_frame_idx"].notna().sum())
                    if "measurement_clip_frame_idx" in result_df else 0,
                "runtime_sec": round(elapsed, 3),
                "gt_validation": gt_result}
        for k in ("top_gap_px", "bottom_gap_px"):
            series = pd.to_numeric(result_df[k], errors="coerce") if k in result_df else pd.Series(dtype=float)
            data[k] = {"count": int(series.notna().sum()),
                       "mean": float(series.mean()) if series.notna().any() else None}
        return data

    def run(self) -> dict:
        self.validate()
        o = self.opt
        print("=== Phase C modular runner ===")
        print(f"Video       : {o.video}")
        print(f"Save stages : {o.save_stages}")
        print(f"Frame source: {o.frame_source}")
        print(f"ROIs        : {self.rois}")
        print(f"Output      : {o.output}")
        if o.dry_run:
            return {"dry_run": True, "resolved_rois": self.rois}

        copied = ensure_core_modules(o.project_root, sync=o.sync_scripts)
        for item in copied:
            print("[MODULE INSTALL]", item)
        # Imports only after first-time source migration.
        from .phase_e import signals, events
        from .phase_a import selector
        from .phase_b import measure

        o.output.mkdir(parents=True, exist_ok=True)
        start = time.perf_counter()
        manifest_path = o.output / "run_manifest.json"
        manifest = {"started_at": datetime.now().isoformat(),
                    "video": str(o.video.resolve()), "save_stages": o.save_stages,
                    "frame_source": o.frame_source, "rois": self.rois,
                    "copied_modules": copied, "status": "running"}
        fps, frame_count = self._fps()
        manifest["fps"] = fps
        manifest["frame_count"] = frame_count
        manifest["core_sha256"] = {
            name: hashlib.sha256((o.project_root / dst).read_bytes()).hexdigest()
            for name, dst in SOURCE_MAP.items()
        }
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

        def execute(stage_root):
            e1_dir = stage_root / "01_motion_signals"
            e3_dir = stage_root / "03_type2_events"
            a2_dir = stage_root / "04_phase_a_v2"
            a3_dir = stage_root / "05_phase_a_v3"
            print("\n[STEP E1] motion signals")
            signal_df = signals.run(o.video, e1_dir, o.analysis_width, o.frame_step,
                                    self.rois["cst"], {"blade1": self.rois["blade1"],
                                                       "blade2": self.rois["blade2"],
                                                       "blade3": self.rois["blade3"]})
            print("\n[STEP E3] event-level Type2 + clips")
            event_df, gt_result = events.run(
                o.video, signal_df, e3_dir, gt_path=o.gt,
                cst_motion_threshold=o.cst_motion_threshold,
                type2_peak_min=o.type2_peak_min,
                type2_peak_max=o.type2_peak_max)
            if event_df.empty:
                print("[INFO] No Type2 events found")
                selected_df = pd.DataFrame(columns=["event_id", "status", "measurement_frame_idx"])
                measured_df = pd.DataFrame(columns=["event_id", "status"])
            else:
                print("\n[STEP A] A2 debug + A3 valley/rise selection")
                selected_df = selector.run(
                    e3_dir / "clips", a2_dir, a3_dir, event_df,
                    self.rois["cst"], self.rois["a2_blade"],
                    valley_threshold=o.valley_threshold, rise_threshold=o.rise_threshold,
                    rise_delta=o.rise_delta, lead_frames=o.lead_frames,
                    save_comparisons=o.save_stages == "all")
                print("\n[STEP B] full ROI horizontal wafer gap measurement")
                measured_df = measure.run(
                    o.video, event_df, selected_df, o.output,
                    o.normal_reference, o.dark_reference,
                    self.rois["search"], self.rois["measure"],
                    o.normal_x_ratio, o.dark_x_ratio,
                    frame_source=o.frame_source, detail_scale=o.detail_scale,
                    jpeg_quality=o.jpeg_quality,
                    top_offsets=(o.normal_top_offset, o.dark_top_offset),
                    bottom_offsets=(o.normal_bottom_offset, o.dark_bottom_offset),
                    save_debug=o.save_stages == "all")
            final_df = self._join(event_df, selected_df, measured_df, fps)
            final_df.to_csv(o.output / "integrated_results.csv", index=False, encoding="utf-8-sig")
            summary = self._summary(final_df, gt_result, time.perf_counter() - start)
            summary["fps"] = fps
            summary["frame_count"] = frame_count
            (o.output / "summary.json").write_text(
                json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
            return summary

        try:
            if o.save_stages == "all":
                summary = execute(o.output / "stages")
            else:
                if o.temp_root is not None:
                    o.temp_root.mkdir(parents=True, exist_ok=True)
                with tempfile.TemporaryDirectory(prefix="epi_phase_c_", dir=o.temp_root) as temp_dir:
                    summary = execute(Path(temp_dir))
            manifest["status"] = "completed"
            manifest["summary"] = summary
        except Exception as exc:
            manifest["status"] = "failed"
            manifest["error"] = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            manifest["completed_at"] = datetime.now().isoformat()
            manifest_path.write_text(
                json.dumps(manifest, ensure_ascii=False, indent=2, default=str),
                encoding="utf-8")
        return summary
