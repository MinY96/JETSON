"""One-time migration of verified algorithms from scripts/ into src/.

These source files are copied, not executed. The pipeline subsequently imports
Python functions/classes from src modules and never invokes subprocess.
"""
from __future__ import annotations

import ast
from pathlib import Path

SOURCE_MAP = {
    "phase_e1_01_extract_motion_signals_v2.py": "src/phase_e/_motion_core.py",
    "phase_e3_03_extract_clips.py": "src/phase_e/_event_core.py",
    "phase_a1_select_measurement_frame_v2.py": "src/phase_a/_a2_core.py",
    "phase_a1_select_measurement_frame_v3.py": "src/phase_a/_a3_core.py",
    "phase_b_template_matching_v5_1.py": "src/phase_b/_measure_core.py",
}


def ensure_core_modules(project_root: Path, sync: bool = False) -> list[str]:
    """Copy missing (or explicitly resynced) source files from scripts to src.

    Do not overwrite modified src code unless --sync-scripts is provided.
    """
    project_root = Path(project_root)
    copied = []
    missing = []
    for src_name, dst_relative in SOURCE_MAP.items():
        source = project_root / "scripts" / src_name
        destination = project_root / dst_relative
        if destination.exists() and not sync:
            continue
        if not source.is_file():
            missing.append(str(source))
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        temp_path = destination.with_suffix(destination.suffix + ".tmp")
        # Preserve the validated algorithm code but remove its CLI entry point.
        content = source.read_text(encoding="utf-8-sig")
        tree = ast.parse(content, filename=str(source))
        lines = content.splitlines(keepends=True)
        remove = set()
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == "main":
                remove.update(range(node.lineno - 1, node.end_lineno))
            elif isinstance(node, ast.If) and isinstance(node.test, ast.Compare):
                # Original scripts use: if __name__ == "__main__": main()
                left = node.test.left
                if isinstance(left, ast.Name) and left.id == "__name__":
                    remove.update(range(node.lineno - 1, node.end_lineno))
        exported = "".join(line for i, line in enumerate(lines) if i not in remove)
        # Ensure we did not accidentally turn the script into invalid source.
        ast.parse(exported, filename=str(destination))
        temp_path.write_text(exported, encoding="utf-8")
        temp_path.replace(destination)
        copied.append(f"{src_name} -> {dst_relative}")

    absent = [str(project_root / rel) for rel in SOURCE_MAP.values()
              if not (project_root / rel).is_file()]
    if absent:
        raise FileNotFoundError(
            "Original scripts are required for first-time module installation.\n"
            "Missing src modules:\n  " + "\n  ".join(absent) +
            "\nMissing scripts:\n  " + "\n  ".join(missing)
        )
    return copied
