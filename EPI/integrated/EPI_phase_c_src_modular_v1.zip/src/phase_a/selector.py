"""Validated A2 motion CSV producer + A3 temporal valley/rise selector."""
from __future__ import annotations
from pathlib import Path
import pandas as pd
from . import _a2_core as a2
from . import _a3_core as a3


def run(clips_dir: Path, output_a2: Path, output_a3: Path,
        event_df: pd.DataFrame, cst_roi: tuple, a2_blade_roi: tuple,
        valley_threshold: float = 0.06, rise_threshold: float = 0.075,
        rise_delta: float = 0.055, lead_frames: int = 1,
        save_comparisons: bool = False) -> pd.DataFrame:
    """Calls underlying pure entry points, never a CLI subprocess."""
    clips_dir = Path(clips_dir)
    output_a2 = Path(output_a2)
    output_a3 = Path(output_a3)
    for directory in [output_a2, output_a2 / "debug", output_a3,
                      output_a3 / "debug", output_a3 / "measurement_frames",
                      output_a3 / "comparison", output_a3 / "candidates"]:
        directory.mkdir(parents=True, exist_ok=True)
    cfg2 = a2.Config(cst_roi=tuple(cst_roi), blade_roi=tuple(a2_blade_roi),
                     save_debug_csv=True, save_comparison=save_comparisons,
                     save_debug_video=False)
    cfg3 = a3.Config(valley_threshold=valley_threshold, rise_threshold=rise_threshold,
                     rise_delta=rise_delta, measurement_lead_frames=lead_frames)
    rows = []
    for _, event in event_df.iterrows():
        eid = int(event["event_id"])
        stem = f"type2_{eid:03d}"
        clip_path = clips_dir / f"{stem}.mp4"
        result = {"event_id": eid, "clip": clip_path.name}
        try:
            if not clip_path.is_file():
                raise FileNotFoundError(clip_path)
            v2 = a2.analyze_clip(clip_path, output_a2, cfg2)
            result["a2_status"] = v2.get("status")
            result["a2_frame_idx"] = v2.get("measurement_frame_idx")
            debug_csv = output_a2 / "debug" / f"{stem}_debug.csv"
            if not debug_csv.is_file():
                result["status"] = "a2_debug_missing"
            else:
                v3 = a3.analyze_one_clip(csv_path=debug_csv,
                                         clips_dir=clips_dir,
                                         output_dir=output_a3,
                                         cfg=cfg3,
                                         old_result=v2)
                result.update({f"a3_{key}": value for key, value in v3.items()})
                result["status"] = v3.get("status", "unknown")
                result["measurement_frame_idx"] = v3.get("measurement_frame_idx")
                result["measurement_sec"] = v3.get("measurement_sec")
                result["measurement_image"] = v3.get("measurement_image")
        except Exception as exc:
            result["status"] = "error"
            result["error"] = f"{type(exc).__name__}: {exc}"
        rows.append(result)
        print(f"[A] {stem}: {result['status']} | measurement={result.get('measurement_frame_idx')}")
    df = pd.DataFrame(rows)
    df.to_csv(output_a3 / "measurement_frames.csv", index=False, encoding="utf-8-sig")
    return df
