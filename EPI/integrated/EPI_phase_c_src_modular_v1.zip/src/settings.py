"""CLI and project ROI configuration, without altering tested defaults."""
from __future__ import annotations

import ast
import re
from dataclasses import dataclass
from pathlib import Path

ROI_NAMES = {"cst_roi", "blade_roi", "blade1_roi", "blade2_roi", "blade3_roi", "a2_blade_roi",
             "search_roi", "measure_roi"}


def load_roi_txt(path: Path | None) -> dict[str, tuple[int, int, int, int]]:
    if path is None or not Path(path).is_file():
        return {}
    values = {}
    for lineno, line in enumerate(Path(path).read_text(encoding="utf-8-sig").splitlines(), 1):
        line = line.split("#", 1)[0].strip()
        if not line or line.startswith(("//", ";")):
            continue
        match = re.match(r"^([a-zA-Z][a-zA-Z_0-9]*)\s*(?:=|:)\s*(.+)$", line)
        if match is None:
            continue
        name, value = match.groups()
        name = name.lower()
        if name not in ROI_NAMES:
            continue
        try:
            item = ast.literal_eval(value)
            if isinstance(item, str):
                item = ast.literal_eval(item)
            if not isinstance(item, (tuple, list)) or len(item) != 4:
                raise ValueError("expected four integers (x,y,w,h)")
            roi = tuple(int(v) for v in item)
            if roi[2] <= 0 or roi[3] <= 0:
                raise ValueError("width/height must be positive")
            values[name] = roi
        except (SyntaxError, ValueError, TypeError) as exc:
            raise ValueError(f"ROI parse error in {path}:{lineno}: {line} ({exc})") from exc
    return values


def get_roi(cli, file_values, key, default, fallback=None):
    if cli is not None:
        return tuple(cli)
    if key in file_values:
        return file_values[key]
    if fallback is not None and fallback in file_values:
        return file_values[fallback]
    return tuple(default)
