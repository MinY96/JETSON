"""E1 service, calling the unchanged tested function in src.phase_e._motion_core."""
from __future__ import annotations
from pathlib import Path
import pandas as pd
from . import _motion_core as core


def run(video: Path, output_dir: Path, analysis_width: int, frame_step: int,
        cst_roi: tuple, blade_rois: dict[str, tuple]) -> pd.DataFrame:
    core.CST_ROI = tuple(cst_roi)
    core.BLADE_ROIS.update({k: tuple(v) for k, v in blade_rois.items()})
    cfg = core.Config(blade_analysis_width=analysis_width, frame_step=frame_step)
    core.extract(Path(video), Path(output_dir), cfg)
    csv_path = Path(output_dir) / "motion_signals.csv"
    if not csv_path.is_file():
        raise FileNotFoundError(csv_path)
    df = pd.read_csv(csv_path)
    if df.empty:
        raise RuntimeError("E1 generated an empty motion_signals.csv")
    return df
