from __future__ import annotations

import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.bootstrap import ensure_core_modules, SOURCE_MAP
from src.settings import load_roi_txt
from src.pipeline import PhaseCPipeline


def test_bootstrap_copies_sources_and_does_not_overwrite(tmp_path):
    (tmp_path / 'scripts').mkdir()
    for filename in SOURCE_MAP:
        (tmp_path / 'scripts' / filename).write_text('VALUE = 1\n', encoding='utf-8')
    copied = ensure_core_modules(tmp_path)
    assert len(copied) == 5
    path = tmp_path / next(iter(SOURCE_MAP.values()))
    path.write_text('VALUE = 2\n', encoding='utf-8')
    assert ensure_core_modules(tmp_path) == []
    assert path.read_text() == 'VALUE = 2\n'
    ensure_core_modules(tmp_path, sync=True)
    assert path.read_text() == 'VALUE = 1\n'


def test_roi_loader(tmp_path):
    path = tmp_path / 'roi.txt'
    path.write_text('cst_roi: (2039,110,149,654)\nblade_roi = [309,359,1593,216]\n')
    assert load_roi_txt(path)['cst_roi'] == (2039,110,149,654)
    assert load_roi_txt(path)['blade_roi'] == (309,359,1593,216)
    assert load_roi_txt(tmp_path / 'missing.txt') == {}


def test_join_uses_e3_event_id_and_floor_start_frame():
    events = pd.DataFrame([{'event_id':1,'clip_start_sec':10.04,'cst_peak_sec':11.2}])
    selection = pd.DataFrame([{'event_id':1,'status':'ok','measurement_frame_idx':5,
                               'measurement_sec':5/15,'a2_status':'ok'}])
    measured = pd.DataFrame([{'event_id':1,'status':'partial','top_gap_px':19.,
                              'bottom_gap_px':None,'top_bottom_ratio_10':'SKIP'}])
    result = PhaseCPipeline._join(events,selection,measured,15)
    row = result.iloc[0]
    assert row['type2_key'] == 'type2_001'
    assert row['source_frame_idx'] == int(np.floor(10.04*15))+5
    assert row['top_gap_px'] == 19.
    assert pd.isna(row['bottom_gap_px'])
    assert row['phase_a_status'] == 'ok'


def test_empty_event_join_and_summary():
    empty = PhaseCPipeline._join(pd.DataFrame(columns=['event_id']),pd.DataFrame(),pd.DataFrame(),15)
    summary = PhaseCPipeline._summary(empty,{'type2_count':0},1.5)
    assert summary['type2_events'] == 0
    assert summary['top_gap_px']['count'] == 0
