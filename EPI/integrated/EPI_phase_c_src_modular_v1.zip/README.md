# EPI Phase C – src 기반 통합 모듈

**기반 코드:** [MinY96/JETSON – EPI/integrated](https://github.com/MinY96/JETSON/tree/main/EPI/integrated)

이 패키지는 사용자 프로젝트의 `main.py` / `src` 디렉터리에 **덮어 씌우는 패치**입니다. 레거시 원본 스크립트 5개는 사용자 프로젝트의 `scripts` 안에 존재해야 합니다. GitHub 원본의 검증된 E1/E3/A2/A3/B 알고리즘을 함수 단위로 호출하고, subprocess는 사용하지 않습니다.

## 적용

압축을 풀어 프로젝트 최상위에 `main.py`, `src/`를 넣습니다. 이미 프로젝트에 `main.py`, `src/`가 있다면 반드시 먼저 백업하세요.

```
project/
├── main.py                     # 실행 진입점
├── src/
│   ├── bootstrap.py            # 최초 한 번 scripts -> src 모듈 복사
│   ├── settings.py             # ROI TXT/CLI 설정
│   ├── pipeline.py             # E1 -> E3 -> A2 -> A3 -> B orchestration
│   ├── phase_e/
│   │   ├── signals.py          # E1 서비스 함수
│   │   ├── events.py           # E3 서비스 함수, GT optional
│   │   ├── _motion_core.py     # 최초 실행에 scripts 원본에서 자동 설치
│   │   └── _event_core.py      # 최초 실행에 scripts 원본에서 자동 설치
│   ├── phase_a/
│   │   ├── selector.py         # A2/A3 함수 호출
│   │   ├── _a2_core.py         # 최초 실행에 scripts 원본에서 자동 설치
│   │   └── _a3_core.py         # 최초 실행에 scripts 원본에서 자동 설치
│   └── phase_b/
│       ├── measure.py          # B v5.1 서비스 함수
│       └── _measure_core.py    # 최초 실행에 scripts 원본에서 자동 설치
├── scripts/                    # 기존 검증 스크립트 5개 보관
│   ├── phase_e1_01_extract_motion_signals_v2.py
│   ├── phase_e3_03_extract_clips.py
│   ├── phase_a1_select_measurement_frame_v2.py
│   ├── phase_a1_select_measurement_frame_v3.py
│   └── phase_b_template_matching_v5_1.py
├── reference/
│   ├── blade_left_bright.png
│   └── blade_left_dark.png
├── data/videos/
├── roi.txt                    # 선택 사항
└── output/
```

처음 `python main.py`를 실행하면 **누락된** 5개 `_core.py`를 `scripts`에서 `src`로 이관합니다. 이때 원본 알고리즘 함수와 설정은 보존하고, `main()` 및 `if __name__ == "__main__"` CLI 진입점만 제외합니다. 이후 `main.py`는 `src`를 직접 import하고 subprocess로 스크립트를 실행하지 않습니다. 원본 `scripts`는 삭제/수정하지 않습니다. 업데이트 이후 알고리즘을 다시 동기화하려면 `--sync-scripts`를 명시적으로 지정하세요. (이 인자는 수정한 `_core.py`를 덮어씁니다.)

## 실행

작업 전 ROI/입력 확인 (코어 파일은 복사하지 않음):

```bat
python main.py --video data\videos\test.mp4 --dry-run
```

최종 산출물만 저장 (기본값):

```bat
python main.py ^
  --video data\videos\test.mp4 ^
  --save-stages final ^
  --frame-source a3
```

단계별 CSV, Clip, Debug까지 보관:

```bat
python main.py ^
  --video data\videos\test.mp4 ^
  --save-stages all ^
  --frame-source a3
```

원본 MP4 프레임으로 최종 측정 (기존 v5.1 JPEG 테스트 결과와 측정값이 달라질 수 있음):

```bat
python main.py ^
  --video data\videos\test.mp4 ^
  --save-stages final ^
  --frame-source original
```

GT Excel은 검출 필수 인자가 아니며, `--gt path/to/file.xlsx`로 **선택적 검증**만 수행합니다.

## 출력

기본 경로 `output/phase_c/`:

```
output/phase_c/
├── integrated_results.csv   # E3/A3/B event_id 기반 병합 결과
├── geometry_results.csv     # Phase B 측정 결과
├── summary.json
├── run_manifest.json         # 설정, 해시, 실행 상태
├── overlay/type2_001.jpg
└── detail/type2_001.jpg
```

`--save-stages all`일 경우 위에 더해 `stages/01_motion_signals`, `03_type2_events/clips`, `04_phase_a_v2/debug`, `05_phase_a_v3/measurement_frames`와 `debug/`가 유지됩니다.

`--save-stages final`에서는 E1 신호 CSV와 E3 MP4 클립, A2/A3 중간 이미지·CSV를 임시 디렉터리에 생성하며, 실행을 마치면 디렉터리를 삭제합니다. **일시적으로 디스크 공간이 필요**합니다. 공간이 부족하면 `--temp-root D:\epi_tmp`를 지정하세요. 원본 영상 자체는 수정되지 않습니다.

동일한 `--output` 경로로 다른 영상을 반복 실행할 경우 이전 이미지가 남을 수 있으므로 각 실행에 서로 다른 경로를 권장합니다. 예: `--output output\phase_c_run_01`.

## ROI 파일

`roi.txt`를 아래처럼 작성할 수 있습니다. 원래 파일의 수치를 바꾸지 않고 해당 형식만 읽습니다. CLI 설정이 우선합니다.

```
cst_roi = (2039, 110, 149, 654)
# E1 Blade2, A2 blade_roi 를 원래는 개별 ROI로 사용함
blade2_roi = (309, 379, 1593, 236)
a2_blade_roi = (309, 359, 1593, 216)
search_roi = (41, 358, 2027, 186)
measure_roi = (49, 296, 600, 273)
```

기존 ROI 파일에 `blade_roi=(...)` 한 값만 있다면 E1 Blade2와 A2 모두에 적용합니다. **단, 두 단계가 원래 서로 다른 ROI를 사용했다**는 점을 주의하세요. 가능하면 `blade2_roi`와 `a2_blade_roi`를 각각 명시하세요. E1 Blade1/3도 `blade1_roi`, `blade3_roi`로 설정할 수 있습니다.

## 검증/주의

- 원본 코드 함수/기본 임계값을 그대로 재사용합니다. ROI나 임계값을 변경하면 기존 25/25 결과 보존을 보장하지 않습니다.
- **Phase B에 사용할 디폴트 프레임은 A3 저장 JPEG** (`--frame-source a3`)로 유지해 기존 단독 측정과 수치 비교가 가능합니다.
- `--frame-source original`은 E3의 `floor(clip_start_sec × FPS)`와 A3 클립 내 프레임 인덱스로 원본 프레임을 찾아 사용합니다. 원본 대비 클립 인코딩 차이로 측정 결과가 약간 달라질 수 있습니다.
- Wafer 미검출은 `None`/NaN으로 기록하고 slot 번호만으로 채우지 않습니다.
- 실제 원본 MP4, Reference 이미지가 제공되지 않았으므로 25개 전 구간의 E2E 성능은 여기서 확인하지 못했습니다. 구조/유틸리티 테스트는 포함되어 있습니다.
- 필요한 파이썬 라이브러리: `opencv-python`, `numpy`, `pandas`, GT Excel 이용 시 `openpyxl`. Jetson에서는 기존 시스템 OpenCV 패키지를 재사용해도 됩니다.
