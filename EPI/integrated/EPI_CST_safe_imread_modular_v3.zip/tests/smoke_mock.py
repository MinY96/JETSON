"""Self-contained synthetic smoke test, not a real CV accuracy test."""
import subprocess
import sys
import tempfile
from pathlib import Path
import shutil
import cv2
import numpy as np
import pandas as pd

PROJECT=Path(__file__).resolve().parents[1]

stubs = {
'phase_e1_01_extract_motion_signals_v2.py': '''
from dataclasses import dataclass
from pathlib import Path
import pandas as pd
CST_ROI=(0,0,10,10)
BLADE_ROIS={'blade1':(0,0,10,10),'blade2':(0,0,10,10),'blade3':(0,0,10,10)}
@dataclass
class Config:
 blade_analysis_width:int=480
 frame_step:int=1
def extract(video_path,output_dir,cfg):
 output_dir.mkdir(parents=True,exist_ok=True)
 pd.DataFrame([{'frame_idx':i,'time_sec':i/15,'cst_dy':-5,'blade2_motion_ratio':.2} for i in range(10)]).to_csv(output_dir/'motion_signals.csv',index=False)
''',
'phase_e3_03_extract_clips.py': '''
from dataclasses import dataclass
from pathlib import Path
import cv2
import pandas as pd
@dataclass
class Config:
 cst_motion_threshold:float=-2
 cst_type2_peak_min:float=-8
 cst_type2_peak_max:float=-2
 blade_name:str='blade2'
def detect_cst_up_events(signals,cfg):
 return [dict(raw_event_id=1,cst_start_time=.1,cst_end_time=.4,cst_peak_time=.2,cst_peak_dy=-5,cst_peak_frame=3,cst_duration_sec=.3)]
def build_type2_events(signals,events,cfg):
 return [dict(event_id=1,clip_start_sec=0.,clip_end_sec=0.5,cst_peak_sec=.2)]
def export_clips(video_path,detected_df,clip_dir):
 clip_dir.mkdir(parents=True,exist_ok=True)
 cap=cv2.VideoCapture(str(video_path));w=int(cap.get(3));h=int(cap.get(4));f=cap.get(5)
 writer=cv2.VideoWriter(str(clip_dir/'type2_001.mp4'),cv2.VideoWriter_fourcc(*'mp4v'),f,(w,h))
 for i in range(8):
  ok,frame=cap.read()
  if not ok:break
  writer.write(frame)
 writer.release();cap.release()
''',
'phase_a1_select_measurement_frame_v2.py': '''
from dataclasses import dataclass
from pathlib import Path
import pandas as pd
@dataclass
class Config:
 cst_roi:tuple=(0,0,1,1)
 blade_roi:tuple=(0,0,1,1)
 save_debug_csv:bool=True
 save_comparison:bool=False
 save_debug_video:bool=False
def analyze_clip(clip_path,output_dir,cfg):
 d=output_dir/'debug'; d.mkdir(parents=True,exist_ok=True)
 pd.DataFrame([{'frame_idx':i,'clip_sec':i/15,'cst_dy':-2,'temporal_ratio':.1} for i in range(8)]).to_csv(d/(clip_path.stem+'_debug.csv'),index=False)
 return dict(clip=clip_path.name,status='ok',measurement_frame_idx=3)
''',
'phase_a1_select_measurement_frame_v3.py': '''
from dataclasses import dataclass
from pathlib import Path
import cv2
import pandas as pd
@dataclass
class Config:
 valley_threshold:float=.06
 rise_threshold:float=.075
 rise_delta:float=.055
 measurement_lead_frames:int=1
def analyze_one_clip(csv_path,clips_dir,output_dir,cfg,old_result=None):
 d=output_dir/'measurement_frames'; d.mkdir(parents=True,exist_ok=True)
 cap=cv2.VideoCapture(str(clips_dir/(csv_path.stem.removesuffix('_debug')+'.mp4')))
 cap.set(cv2.CAP_PROP_POS_FRAMES,4)
 _,frame=cap.read();cap.release()
 path=d/(csv_path.stem.removesuffix('_debug')+'_measurement.jpg')
 cv2.imwrite(str(path),frame)
 return dict(status='ok',measurement_frame_idx=4,measurement_sec=4/15,measurement_image=str(path),valley_frame=3,rise_frame=5)
''',
'phase_b_template_matching_v5_1.py': '''
from dataclasses import dataclass
import numpy as np
@dataclass
class Config:
 search_roi:tuple=(0,0,200,100)
 measure_roi:tuple=(0,0,200,100)
 normal_x_ratio:float=.7
 dark_x_ratio:float=.7
 normal_top_offset:float=0
 dark_top_offset:float=0
 normal_bottom_offset:float=0
 dark_bottom_offset:float=0
 detail_scale:float=2
 jpeg_quality:int=98
def load_references(normal,dark,cfg):return {}
def analyze_image(img,refs,cfg):
 return dict(status='ok',top_gap_px=19,bottom_gap_px=28),{'attempts':[]}
def flatten_result(filename,result):return {'image':filename,**result,'top_bottom_ratio_10':'4:6'}
def draw_overlay(img,result,debug,cfg):return img.copy()
def create_detail(img,result,debug,cfg):return img.copy()
def save_debug(debug_dir,stem,debug,result):pass
'''
}


def run():
 with tempfile.TemporaryDirectory(prefix='epi_functional_mock_') as tmp:
  root=Path(tmp)
  shutil.copy(PROJECT/'main.py',root/'main.py')
  shutil.copytree(PROJECT/'src',root/'src',ignore=shutil.ignore_patterns('__pycache__','_signal_core.py','_event_core.py','_departure_core.py','_timing_core.py','_gap_core.py'))
  for n,s in stubs.items():
   (root/'scripts').mkdir(exist_ok=True)
   (root/'scripts'/n).write_text(s,encoding='utf-8')
  (root/'reference').mkdir()
  cv2.imwrite(str(root/'reference/blade_left_bright.png'),np.ones((20,20,3),np.uint8)*128)
  cv2.imwrite(str(root/'reference/blade_left_dark.png'),np.ones((20,20,3),np.uint8)*30)
  (root/'data/videos').mkdir(parents=True)
  vp=root/'data/videos/test.mp4'; writer=cv2.VideoWriter(str(vp),cv2.VideoWriter_fourcc(*'mp4v'),15,(320,240))
  for i in range(15):writer.write(np.full((240,320,3),40+i,np.uint8))
  writer.release()
  for save in ('none','all'):
   cmd=[sys.executable,'main.py','--video','data/videos/test.mp4','--output',f'output/{save}',
        '--save-intermediates',save,'--cst-motion-roi','0','0','100','100','--blade-motion-primary-roi','0','0','100','100',
        '--blade-departure-roi','0','0','100','100','--blade-template-search-roi','0','0','200','100',
        '--wafer-measurement-roi','0','0','200','100']
   p=subprocess.run(cmd,cwd=root,text=True,capture_output=True)
   if p.returncode:
    print(p.stdout);print(p.stderr)
    raise AssertionError(f'Mock smoke {save} failed: {p.returncode}')
   df=pd.read_csv(root/f'output/{save}/integrated_results.csv')
   assert len(df)==1 and df.loc[0,'top_gap_px']==19
   assert (root/f'output/{save}/detail/type2_001.jpg').is_file()
   assert (root/f'output/{save}/run_manifest.json').is_file()
   assert (root/f'output/{save}/intermediate').is_dir() == (save=='all')
   print(f'[{save}] OK: event_id=1, gap=19/28, overlay/detail present')

if __name__=='__main__':run()
