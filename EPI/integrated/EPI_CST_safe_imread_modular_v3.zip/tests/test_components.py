from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.core_install import ALGORITHM_SOURCES, install_algorithms
from src.roi_config import DEFAULT_ROIS, load_roi_txt, resolve_rois
from src.analysis import VideoAnalyzer


def test_source_install_and_sync(tmp_path):
    (tmp_path / "scripts").mkdir()
    for name in ALGORITHM_SOURCES:
        (tmp_path / "scripts" / name).write_text(
            'VALUE = 1\n\ndef main():\n    raise RuntimeError("CLI should not remain")\n\nif __name__ == "__main__":\n    main()\n',
            encoding="utf-8",
        )
    installed = install_algorithms(tmp_path)
    assert len(installed) == len(ALGORITHM_SOURCES)
    target = tmp_path / next(iter(ALGORITHM_SOURCES.values()))
    assert "def main" not in target.read_text()
    target.write_text("VALUE = 2\n", encoding="utf-8")
    assert install_algorithms(tmp_path) == []
    install_algorithms(tmp_path, sync=True)
    assert "VALUE = 1" in target.read_text()


def test_functional_roi_file(tmp_path):
    path = tmp_path / "roi.txt"
    path.write_text(
        "cst_motion_roi=(2039,110,149,654)\n"
        "blade_template_search_roi=(50,300,620,250)\n"
        "wafer_measurement_roi=(50,315,620,235)\n",
        encoding="utf-8",
    )
    parsed = load_roi_txt(path)
    assert parsed["cst_motion_roi"] == (2039, 110, 149, 654)
    assert parsed["blade_template_search_roi"] == (50, 300, 620, 250)
    assert parsed["wafer_measurement_roi"] == (50, 315, 620, 235)
    resolved = resolve_rois(path, {"wafer_measurement_roi": (1, 2, 50, 40)})
    assert resolved["wafer_measurement_roi"] == (1, 2, 50, 40)
    assert resolved["blade_motion_primary_roi"] == DEFAULT_ROIS["blade_motion_primary_roi"]


def test_legacy_roi_file_compatible(tmp_path):
    path = tmp_path / "roi.txt"
    path.write_text(
        "cst_roi=(2039,110,149,654)\nblade2_roi=(309,379,1593,236)\n"
        "search_roi=(50,300,620,250)\nmeasure_roi=(50,315,620,235)\n"
        "wafer_measurement_roi=(2,3,4,5)\n"
    )
    rois = load_roi_txt(path)
    assert rois["cst_motion_roi"] == (2039, 110, 149, 654)
    assert rois["blade_motion_primary_roi"] == (309, 379, 1593, 236)
    assert rois["wafer_measurement_roi"] == (2, 3, 4, 5)  # preferred key wins


def test_bad_roi_raises(tmp_path):
    path = tmp_path / "roi.txt"
    path.write_text("wafer_measurement_roi=(0,0,-1,20)\n")
    with pytest.raises(ValueError):
        load_roi_txt(path)


def test_join_explicit_event_id_with_video_time():
    events = pd.DataFrame([{"event_id": 1, "clip_start_sec": 10.04, "cst_peak_sec": 11.2}])
    selection = pd.DataFrame([{"event_id": 1, "status": "ok", "measurement_frame_idx": 5,
                               "measurement_sec": 5/15, "departure_status": "ok",
                               "selection_valley_frame": 3, "selection_rise_frame": 5}])
    gaps = pd.DataFrame([{"event_id": 1, "status": "partial", "top_gap_px": 19., "bottom_gap_px": None}])
    joined = VideoAnalyzer.combine(events, selection, gaps, 15)
    row = joined.iloc[0]
    assert row["event_key"] == "type2_001"
    assert row["source_frame_idx"] == int(np.floor(10.04*15)) + 5
    assert row["top_gap_px"] == 19.
    assert pd.isna(row["bottom_gap_px"])
    assert row["selection_status"] == "ok"
    assert row["valley_frame"] == 3
    assert row["status"] == "partial"


def test_no_events_summary():
    empty = VideoAnalyzer.combine(
        pd.DataFrame(columns=["event_id"]), pd.DataFrame(), pd.DataFrame(), 15
    )
    summary = VideoAnalyzer.summarize(empty, {"type2_count": 0}, 1.1)
    assert summary["type2_events"] == 0
    assert summary["top_gap_px"]["count"] == 0


def test_safe_imread_unicode_path_and_flags(tmp_path):
    import cv2
    from src.common.image_io import safe_imread

    rgb = np.zeros((18, 24, 3), dtype=np.uint8)
    rgb[:, :, 0] = 25
    rgb[:, :, 1] = 90
    rgb[:, :, 2] = 220
    path = tmp_path / "한글 폴더"
    path.mkdir()
    image = path / "테스트 이미지(1).png"
    assert cv2.imwrite(str(tmp_path / "ascii.png"), rgb)
    (image).write_bytes((tmp_path / "ascii.png").read_bytes())

    decoded = safe_imread(image)
    assert decoded is not None
    np.testing.assert_array_equal(decoded, rgb)
    gray = safe_imread(image, cv2.IMREAD_GRAYSCALE)
    assert gray.shape == (18, 24)
    unchanged = safe_imread(image, cv2.IMREAD_UNCHANGED)
    np.testing.assert_array_equal(unchanged, rgb)


def test_safe_imread_missing_and_invalid(tmp_path):
    from src.common.image_io import safe_imread

    assert safe_imread(tmp_path / "없는이미지.png") is None
    invalid = tmp_path / "깨진파일.png"
    invalid.write_bytes(b"not a real png")
    assert safe_imread(invalid) is None
    empty = tmp_path / "empty.jpg"
    empty.write_bytes(b"")
    assert safe_imread(empty) is None


def test_core_install_rewrites_direct_imread_calls(tmp_path):
    import ast
    from src.core_install import rewrite_direct_image_reads

    original = '''\
"""한글 문서와 cv2.imread 설명 (코드 아님)."""
from __future__ import annotations
import cv2
import cv as cv
# cv2.imread("untouched comment")
def get(a, b):
    return cv2.imread(a), cv.imread(b, cv2.IMREAD_UNCHANGED)
'''
    output = rewrite_direct_image_reads(original)
    assert 'from src.common.image_io import safe_imread' in output
    assert 'return safe_imread(a), safe_imread(b, cv2.IMREAD_UNCHANGED)' in output
    assert 'cv2.imread("untouched comment")' in output
    assert 'cv2.imread 설명' in output
    assert rewrite_direct_image_reads(output) == output
    ast.parse(output)

    (tmp_path / "scripts").mkdir()
    for name in ALGORITHM_SOURCES:
        (tmp_path / "scripts" / name).write_text(original, encoding="utf-8")
    install_algorithms(tmp_path)
    core_target = tmp_path / ALGORITHM_SOURCES["phase_b_template_matching_v5_1.py"]
    content = core_target.read_text(encoding="utf-8")
    assert 'return safe_imread(a)' in content
    core_target.write_text(content.replace('return safe_imread(a)', 'return cv2.imread(a)'), encoding='utf8')
    changed = install_algorithms(tmp_path)
    assert any('migrated image reads' in x for x in changed)
    assert 'return safe_imread(a)' in core_target.read_text()


def test_migrate_scripts_preserves_standalone_compatibility(tmp_path):
    import ast
    from src.core_install import rewrite_direct_image_reads

    original = '''\
from __future__ import annotations
import cv2

def main():
    return cv2.imread("한글.png")
if __name__ == "__main__":
    main()
'''
    converted = rewrite_direct_image_reads(original, standalone_script=True)
    assert 'try:\n    from src.common.image_io import safe_imread' in converted
    assert 'return safe_imread("한글.png")' in converted
    assert rewrite_direct_image_reads(converted, standalone_script=True) == converted
    ast.parse(converted)


def test_project_migration_updates_scripts_with_backup(tmp_path):
    from importlib.util import module_from_spec, spec_from_file_location

    script = tmp_path / "scripts" / "legacy.py"
    script.parent.mkdir()
    script.write_text(
        'import cv2\n\n'
        'def load(path):\n'
        '    return cv2.imread(path)\n',
        encoding="utf-8",
    )

    migration_path = ROOT / "tools" / "migrate_image_io.py"
    spec = spec_from_file_location("epi_migration_test", migration_path)
    mod = module_from_spec(spec)
    spec.loader.exec_module(mod)

    prospective, errors = mod.migrate(tmp_path, check=True)
    assert prospective == [script]
    assert not errors
    assert "cv2.imread" in script.read_text(encoding="utf8")

    changed, errors = mod.migrate(tmp_path)
    assert changed == [script]
    assert not errors
    assert "return safe_imread(path)" in script.read_text(encoding="utf8")
    assert (script.parent / "legacy.py.before_safe_imread.bak").is_file()

    changed_again, errors = mod.migrate(tmp_path)
    assert changed_again == []
    assert not errors
