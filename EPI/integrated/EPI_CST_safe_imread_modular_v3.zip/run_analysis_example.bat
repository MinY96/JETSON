@echo off
REM Execute from project root; change the video filename as needed.
python main.py ^
  --video data\videos\test.mp4 ^
  --save-intermediates all ^
  --frame-source selected
