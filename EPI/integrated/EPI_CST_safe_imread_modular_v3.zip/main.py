"""Run CST Type2 detection and Blade-to-Wafer gap measurement in one process."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from src.analysis import AnalysisOptions, VideoAnalyzer
from src.roi_config import DEFAULT_ROIS

PROJECT_ROOT = Path(__file__).resolve().parent


def project_path(value):
    if value is None:
        return None
    path = Path(value)
    return path if path.is_absolute() else PROJECT_ROOT / path


def build_parser():
    parser = argparse.ArgumentParser(
        description="CST Type2 event detection and Blade-to-Wafer gap measurement"
    )
    parser.add_argument("--video", required=True, help="Source CCTV MP4")
    parser.add_argument("--output", default="output/cst_wafer_analysis")
    parser.add_argument("--reference-bright", default="reference/blade_left_bright.png")
    parser.add_argument("--reference-dark", default="reference/blade_left_dark.png")
    parser.add_argument("--roi-file", default="roi.txt")
    parser.add_argument("--gt", default=None, help="Optional GT Excel for evaluation only")
    parser.add_argument(
        "--save-intermediates", choices=("none", "all"), default="none",
        help="none: final CSV/images only; all: retain motion signals, clips and debug",
    )
    parser.add_argument(
        "--frame-source", choices=("selected", "original"), default="selected",
        help="selected: selected-frame JPEG (parity); original: frame from original MP4",
    )
    parser.add_argument("--temp-root", default=None, help="Temporary clip workspace drive")
    parser.add_argument("--sync-algorithms", action="store_true", help="Refresh core modules from scripts/")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--analysis-width", type=int, default=480)
    parser.add_argument("--frame-step", type=int, default=1)

    # Every override has the same role-oriented name as roi.txt (minus _ -> -).
    for name in DEFAULT_ROIS:
        parser.add_argument("--" + name.replace("_", "-"), nargs=4, type=int, default=None)

    parser.add_argument("--normal-x-ratio", type=float, default=0.7)
    parser.add_argument("--dark-x-ratio", type=float, default=0.7)
    for name in ("normal_top_offset", "normal_bottom_offset", "dark_top_offset", "dark_bottom_offset"):
        parser.add_argument("--" + name.replace("_", "-"), type=float, default=0.0)
    parser.add_argument("--cst-motion-threshold", type=float, default=-2.0)
    parser.add_argument("--type2-peak-min", type=float, default=-8.0)
    parser.add_argument("--type2-peak-max", type=float, default=-2.0)
    parser.add_argument("--valley-threshold", type=float, default=0.06)
    parser.add_argument("--rise-threshold", type=float, default=0.075)
    parser.add_argument("--rise-delta", type=float, default=0.055)
    parser.add_argument("--lead-frames", type=int, default=1)
    parser.add_argument("--detail-scale", type=float, default=2.0)
    parser.add_argument("--jpeg-quality", type=int, default=98)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    options = AnalysisOptions(
        project_root=PROJECT_ROOT,
        video=project_path(args.video),
        output=project_path(args.output),
        bright_reference=project_path(args.reference_bright),
        dark_reference=project_path(args.reference_dark),
        roi_file=project_path(args.roi_file),
        roi_overrides={name: getattr(args, name) for name in DEFAULT_ROIS},
        ground_truth=project_path(args.gt),
        save_intermediates=args.save_intermediates,
        frame_source=args.frame_source,
        temp_root=project_path(args.temp_root),
        sync_algorithms=args.sync_algorithms,
        dry_run=args.dry_run,
        analysis_width=args.analysis_width,
        frame_step=args.frame_step,
        normal_x_ratio=args.normal_x_ratio,
        dark_x_ratio=args.dark_x_ratio,
        normal_top_offset=args.normal_top_offset,
        normal_bottom_offset=args.normal_bottom_offset,
        dark_top_offset=args.dark_top_offset,
        dark_bottom_offset=args.dark_bottom_offset,
        cst_motion_threshold=args.cst_motion_threshold,
        type2_peak_min=args.type2_peak_min,
        type2_peak_max=args.type2_peak_max,
        valley_threshold=args.valley_threshold,
        rise_threshold=args.rise_threshold,
        rise_delta=args.rise_delta,
        lead_frames=args.lead_frames,
        detail_scale=args.detail_scale,
        jpeg_quality=args.jpeg_quality,
    )
    summary = VideoAnalyzer(options).run()
    print("\nAnalysis finished:")
    print(json.dumps(summary, ensure_ascii=False, indent=2, default=str))
    return summary


if __name__ == "__main__":
    main()
