# EPI CST Type2 / Blade-to-Wafer Gap Analyzer

검증된 알고리즘을 **기능/역할별 Python 모듈**로 통합한 버전입니다.

기반: [MinY96/JETSON · EPI/integrated](https://github.com/MinY96/JETSON/tree/main/EPI/integrated)

## 1. 폴더 구조

```text
project/
├── main.py                              # 단일 실행 진입점
├── roi.txt                              # 기능 중심 ROI 설정
├── src/
│   ├── analysis.py                      # 분석 오케스트레이션, 결과 병합
│   ├── roi_config.py                    # ROI 파싱/기본값/기존 키 호환
│   ├── common/
│   │   └── image_io.py                  # 한글 경로 safe_imread
│   ├── core_install.py                  # 최초 1회 원본 알고리즘 모듈 이관
│   ├── motion/
│   │   ├── signals.py                   # CST/Blade 움직임 신호
│   │   └── _signal_core.py              # scripts 원본에서 이관
│   ├── events/
│   │   ├── detector.py                  # Type2 이벤트, GT 선택적 비교, Clip
│   │   └── _event_core.py               # scripts 원본에서 이관
│   ├── frames/
│   │   ├── selector.py                  # Blade 이탈 시점 + Valley/Rise 측정 프레임
│   │   ├── _departure_core.py           # scripts 원본에서 이관
│   │   └── _timing_core.py              # scripts 원본에서 이관
│   └── measurement/
│       ├── wafer_gaps.py                # Blade 기준선과 Wafer 간격 계산
│       └── _gap_core.py                 # scripts 원본에서 이관
├── tools/
│   └── migrate_image_io.py             # 기존 scripts까지 안전한 이미지 로딩으로 변경
├── scripts/                             # 기존 스크립트는 마이그레이션 시 백업 후 수정
│   ├── phase_e1_01_extract_motion_signals_v2.py
│   ├── phase_e3_03_extract_clips.py
│   ├── phase_a1_select_measurement_frame_v2.py
│   ├── phase_a1_select_measurement_frame_v3.py
│   └── phase_b_template_matching_v5_1.py
├── data/videos/
├── reference/
│   ├── blade_left_bright.png
│   └── blade_left_dark.png
├── output/
└── requirements.txt                    # 프로젝트 기존 파일 유지
```

`_core.py` 파일은 **처음 실행할 때 scripts 폴더에서 자동 이관**됩니다. 이관 시 원본의 `main()`과 단독 실행 블록만 제거하며 계산 함수와 임계값을 변경하지 않습니다. 그다음부터는 `src`의 함수들을 **프로세스 내에서 import/call**합니다. `subprocess`는 사용하지 않습니다.

기존 `src/phase_*` 폴더는 더 이상 import하지 않습니다. **새 버전 테스트에 성공한 후** 별도 백업하거나 제거하세요. 원본 `scripts`는 재설치/비교를 위해 보관하는 것을 권장합니다.

## 2. roi.txt

다음처럼 **원본 영상 좌표 `(x, y, width, height)`**를 사용합니다.

```ini
cst_motion_roi = (2039, 110, 149, 654)

blade_motion_candidate_1_roi = (16, 267, 621, 360)
blade_motion_primary_roi = (309, 379, 1593, 236)
blade_motion_candidate_3_roi = (74, 300, 1109, 302)

blade_departure_roi = (309, 359, 1593, 216)

blade_template_search_roi = (50, 300, 620, 250)
wafer_measurement_roi = (50, 315, 620, 235)
```

- `blade_motion_primary_roi`는 E-1에서 `blade2` 특성을 만들며, Type2 이벤트 검출이 해당 신호를 사용합니다.
- `blade_departure_roi`는 측정 프레임 선정용 ROI로, 위와 별개입니다.
- `blade_template_search_roi`와 `wafer_measurement_roi`는 최종 매칭 및 Wafer Y 검출용입니다.
- GitHub 원본의 Blade2 Y는 **379**이고, Blade 이탈 탐색용 Y는 **359**입니다. 사용자 기억에 있는 Y=370은 원본에서 확인된 최종 기본값은 아닙니다.

CLI 인자 > `roi.txt` > 모듈 기본값 순서로 적용합니다. 이전 `roi.txt`의 `cst_roi`, `blade1_roi`, `blade2_roi`, `blade3_roi`, `a2_blade_roi`, `search_roi`, `measure_roi`도 읽을 수 있습니다. 한 파일에 구형·신형 이름이 함께 있다면 신형 이름을 우선합니다.

## 3. 실행

모든 명령은 **프로젝트 루트**에서 실행합니다.

### 설정 확인

```bat
python main.py ^
  --video data\videos\test.mp4 ^
  --dry-run
```

### 최종 파일만 저장 (기본값)

```bat
python main.py ^
  --video data\videos\test.mp4 ^
  --save-intermediates none ^
  --frame-source selected
```

### 중간 분석 결과까지 전부 보관

```bat
python main.py ^
  --video data\videos\test.mp4 ^
  --save-intermediates all ^
  --frame-source selected
```

### 원본 MP4 프레임으로 Wafer 측정

```bat
python main.py ^
  --video data\videos\test.mp4 ^
  --save-intermediates none ^
  --frame-source original
```

### GT와 비교 (선택 사항)

```bat
python main.py ^
  --video data\videos\test.mp4 ^
  --gt data\blade_in_out_timestamp.xlsx ^
  --save-intermediates all
```

### 명령행 ROI 덮어쓰기

```bat
python main.py ^
  --video data\videos\test.mp4 ^
  --blade-template-search-roi 50 300 620 250 ^
  --wafer-measurement-roi 50 315 620 235
```

### 임시 MP4를 다른 드라이브에 두기

```bat
python main.py ^
  --video data\videos\test.mp4 ^
  --temp-root D:\epi_temp ^
  --save-intermediates none
```

`--frame-source selected`는 기존 측정 프레임 JPEG를 사용해 이전 검증 결과와 비교하기 쉽습니다. `original`은 원본 MP4 프레임을 직접 다시 읽으므로 영상 재인코딩 차이로 수치가 달라질 수 있습니다.

## 4. 출력

기본 경로: `output/cst_wafer_analysis/`

```text
output/cst_wafer_analysis/
├── integrated_results.csv               # 이벤트 + 프레임 선택 + Wafer 측정
├── geometry_results.csv                 # Gap 측정 전체 결과
├── summary.json                         # 수량, 성공 상태, 평균 간격
├── run_manifest.json                    # 설정, ROI, 알고리즘 해시, 실행 상태
├── overlay/type2_001.jpg                # 전체 이미지, 정보창 없음
└── detail/type2_001.jpg                 # 확대한 ROI, 우측 정보창 포함
```

`--save-intermediates all`에서 추가되는 디렉터리:

```text
output/cst_wafer_analysis/intermediate/
├── motion_signals/motion_signals.csv
├── type2_events/detected_events.csv
├── type2_events/gt_comparison.csv        # GT를 입력한 경우
├── type2_events/clips/type2_001.mp4
├── blade_departure/debug/*.csv
└── measurement_selection/
    ├── measurement_frames.csv
    ├── measurement_frames/*.jpg
    ├── debug/*.csv
    └── candidates/*.jpg
```

이 모드에서는 `output/cst_wafer_analysis/debug/`의 Gap 분석 디버그도 남습니다.

`--save-intermediates none`은 중간 파일을 **생성하지 않는다는 뜻이 아니라**, 분석에 필요한 CSV·MP4를 임시 디렉터리에 생성하고 완료 후 자동 삭제한다는 뜻입니다. 긴 영상에서 임시 디스크 공간은 필요합니다.

## 5. 이관·업데이트 주의 사항

1. **기존 `main.py`, `src`, `roi.txt`를 먼저 백업**한 뒤 이 패키지를 적용하세요.
2. 알고리즘 소스인 `scripts/`와 Reference 이미지는 기존 파일을 그대로 사용합니다.
3. 첫 실행 시 `src/motion/_signal_core.py` 등의 파일이 자동으로 설치됩니다. 이미 존재하면 재설치하지 않습니다.
4. 원본 스크립트의 수정을 반영하려면 `--sync-algorithms`를 사용하세요. **수정한 `_core.py`를 덮어쓰므로** 커스텀 코드가 있다면 백업이 필요합니다.
5. 동일 출력 디렉터리를 재사용하면 과거 이미지가 남을 수 있습니다. 영상마다 `--output output/cst_wafer_analysis_run01`처럼 다른 폴더를 지정하세요.
6. 실제 CCTV 원본 영상으로는 아직 정확도 검증을 진행하지 않았습니다. 이전에 성공한 25장의 Gap 값과 새 결과를 비교하세요.

## 6. 테스트

```bat
python -m pytest -q tests/test_components.py
python tests/smoke_mock.py
```

모의 테스트는 전체 연결과 파일 저장을 확인하는 용도이며, 실제 영상의 검출 정확도를 보증하지 않습니다.

## 7. 설치

최소 필요 패키지: `numpy`, `pandas`, `opencv-python`, `pytest`(테스트용), `openpyxl`(GT Excel 사용 시).

Jetson에서는 기존 설치된 시스템 OpenCV를 활용할 수도 있으므로 운영 환경의 OpenCV 버전과 CUDA/GStreamer 의존성을 먼저 확인하세요. 이 패키지는 프로젝트의 기존 `requirements.txt`를 덮어쓰지 않습니다.

## Unicode 이미지 경로 지원 (`safe_imread`)

이미지 **파일** 읽기는 `src/common/image_io.py`의 공통 함수로 통일했습니다.

```python
from src.common.image_io import safe_imread

image = safe_imread("reference/블레이드 밝음.png")
image_gray = safe_imread("한글 폴더/웨이퍼.png", cv2.IMREAD_GRAYSCALE)
if image is None:
    raise FileNotFoundError("이미지를 열 수 없습니다")
```

이 함수는 `np.fromfile(path, dtype=np.uint8)` → `cv2.imdecode(buffer, flags)` 순서로 처리하며,
파일을 읽지 못하거나 이미지 디코딩에 실패하면 `cv2.imread`와 동일하게 `None`을 반환합니다.

- `src/measurement/wafer_gaps.py`: 측정 프레임 읽기에 `safe_imread` 사용.
- `src/measurement/_gap_core.py`: Reference 이미지 읽기 함수를 자동 변환하여 이관.
- 이미 생성된 `_core.py`에 직접 `cv2.imread(...)` 코드가 남아 있더라도
  `main.py` 실행 시 `install_algorithms()`가 해당 호출부만 안전하게 변환합니다.
- 기존 `scripts` 원본은 자동으로 변경되지 않으므로, 원본 단독 실행 코드까지
  일괄 수정하려면 아래 명령어를 **프로젝트 루트**에서 최초 1회 실행합니다.

```bat
python tools\migrate_image_io.py --check
python tools\migrate_image_io.py
```

마이그레이션 도구는 `main.py`, `src/**/*.py`, `scripts/**/*.py`의 실제
`cv2.imread()` / `cv.imread()` **함수 호출**만 바꿉니다. 주석과 문자열은 건드리지 않고,
스크립트 원본을 수정할 때는 `*.py.before_safe_imread.bak`을 자동으로 생성합니다.
`python scripts\...py`처럼 단독 실행해도 정상 import할 수 있도록 경로 fallback을 포함합니다.

**주의:** `cv2.VideoCapture` 및 `cv2.imwrite`는 이미지 파일을 읽는 함수가 아니므로
이번 변경 범위에서 제외했습니다. 이미지 파일 저장의 한글 경로 지원까지 통일하려면
별도의 `safe_imwrite()`가 필요합니다.

변경 후 확인:

```bat
python -m pytest -q tests/test_components.py
python tests/smoke_mock.py
```
