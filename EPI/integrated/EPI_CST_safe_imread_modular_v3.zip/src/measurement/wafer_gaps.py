"""Measure Blade-to-Wafer gaps by reference matching and ROI-wide edges."""
from __future__ import annotations
from pathlib import Path
import cv2
import numpy as np
import pandas as pd
from . import _gap_core as core
from ..common.image_io import safe_imread


def open_video(video: Path):
    cap = cv2.VideoCapture(str(video))
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {video}")
    fps = float(cap.get(cv2.CAP_PROP_FPS))
    if fps <= 0:
        cap.release()
        raise ValueError(f"Invalid FPS: {video}")
    return cap, fps


def run(video: Path, events: pd.DataFrame, selections: pd.DataFrame,
        output_dir: Path, normal_reference: Path, dark_reference: Path,
        search_roi: tuple, measure_roi: tuple, normal_x_ratio: float,
        dark_x_ratio: float, frame_source: str = "selected",
        detail_scale: float = 2.0, jpeg_quality: int = 98,
        top_offsets: tuple = (0.0, 0.0), bottom_offsets: tuple = (0.0, 0.0),
        save_debug: bool = False) -> pd.DataFrame:
    """Measure only A3 successful frames. Always save final overlay/detail.

    `frame_source=original` reads the exact frame corresponding to
    floor(E3.clip_start_sec * fps) + A3.measurement_frame_idx.
    """
    output_dir = Path(output_dir)
    overlay_dir, detail_dir, debug_dir = (output_dir / p for p in ("overlay", "detail", "debug"))
    for p in (output_dir, overlay_dir, detail_dir):
        p.mkdir(parents=True, exist_ok=True)
    if save_debug:
        debug_dir.mkdir(parents=True, exist_ok=True)
    cfg = core.Config(search_roi=tuple(search_roi), measure_roi=tuple(measure_roi),
                      normal_x_ratio=normal_x_ratio, dark_x_ratio=dark_x_ratio,
                      normal_top_offset=top_offsets[0], dark_top_offset=top_offsets[1],
                      normal_bottom_offset=bottom_offsets[0], dark_bottom_offset=bottom_offsets[1],
                      detail_scale=detail_scale, jpeg_quality=jpeg_quality)
    refs = core.load_references(normal_reference, dark_reference, cfg)
    sel_by_id = {int(row["event_id"]): row for _, row in selections.iterrows()}
    cap = None
    fps = None
    if frame_source == "original":
        cap, fps = open_video(video)
    rows = []
    try:
        for _, ev in events.iterrows():
            eid = int(ev["event_id"])
            stem = f"type2_{eid:03d}"
            sel = sel_by_id.get(eid)
            row = {"event_id": eid, "image": stem + "_measurement.jpg"}
            if sel is None or sel.get("status") != "ok":
                row.update({"status": "selection_not_available", "top_gap_px": None,
                            "bottom_gap_px": None})
                rows.append(row)
                continue
            try:
                measurement_idx = int(sel["measurement_frame_idx"])
                start_frame = None
                source_frame_idx = None
                if frame_source == "original":
                    start_frame = int(np.floor(float(ev["clip_start_sec"]) * fps))
                    source_frame_idx = start_frame + measurement_idx
                    cap.set(cv2.CAP_PROP_POS_FRAMES, source_frame_idx)
                    ok, image = cap.read()
                    if not ok or image is None:
                        raise IOError(f"Cannot read original frame {source_frame_idx}")
                else:
                    image_path = sel.get("measurement_image")
                    if not image_path or pd.isna(image_path):
                        raise FileNotFoundError(f"Selected measurement image missing for {stem}")
                    image = safe_imread(image_path)
                    if image is None:
                        raise FileNotFoundError(str(image_path))
                result, debug = core.analyze_image(image, refs, cfg)
                row.update(core.flatten_result(stem + "_measurement.jpg", result))
                if result["status"] in {"matched", "ok", "partial", "no_wafer_detected", "review", "match_failed"}:
                    params = [cv2.IMWRITE_JPEG_QUALITY, cfg.jpeg_quality]
                    overlay = core.draw_overlay(image, result, debug, cfg)
                    detail = core.create_detail(image, result, debug, cfg)
                    if not cv2.imwrite(str(overlay_dir / f"{stem}.jpg"), overlay, params):
                        raise IOError("Overlay save failed")
                    if not cv2.imwrite(str(detail_dir / f"{stem}.jpg"), detail, params):
                        raise IOError("Detail save failed")
                if save_debug:
                    core.save_debug(debug_dir, stem, debug, result)
                row["source_frame_idx"] = source_frame_idx
            except Exception as exc:
                row["status"] = "error"
                row["error"] = f"{type(exc).__name__}: {exc}"
            rows.append(row)
            print(f"[GAP] {stem}: {row['status']} | top={row.get('top_gap_px')} bottom={row.get('bottom_gap_px')}")
    finally:
        if cap is not None:
            cap.release()
    df = pd.DataFrame(rows)
    df.to_csv(output_dir / "geometry_results.csv", index=False, encoding="utf-8-sig")
    return df
