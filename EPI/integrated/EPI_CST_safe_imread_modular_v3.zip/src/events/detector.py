"""E3 event-level Type2 detection and original clip extraction; GT optional."""
from __future__ import annotations
from pathlib import Path
import pandas as pd
from . import _event_core as core


def run(video: Path, signals: pd.DataFrame, output_dir: Path,
        gt_path: Path | None = None, cst_motion_threshold: float = -2.0,
        type2_peak_min: float = -8.0, type2_peak_max: float = -2.0) -> tuple[pd.DataFrame, dict]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    cfg = core.Config(cst_motion_threshold=cst_motion_threshold,
                      cst_type2_peak_min=type2_peak_min,
                      cst_type2_peak_max=type2_peak_max)
    required = {"frame_idx", "time_sec", "cst_dy", f"{cfg.blade_name}_motion_ratio"}
    if not required.issubset(signals.columns):
        raise ValueError(f"Motion signal columns missing: {sorted(required - set(signals.columns))}")
    signals = signals.sort_values("time_sec").reset_index(drop=True)
    cst_events = core.detect_cst_up_events(signals, cfg)
    detected = core.build_type2_events(signals, cst_events, cfg)
    df = pd.DataFrame(detected)
    df.to_csv(output_dir / "detected_events.csv", index=False, encoding="utf-8-sig")
    summary = {"type2_count": len(df), "gt_available": gt_path is not None}
    if gt_path is not None:
        gt = core.load_gt(Path(gt_path))
        comparison, matched_indices = core.compare_with_gt(df, gt, cfg)
        comparison.to_csv(output_dir / "gt_comparison.csv", index=False, encoding="utf-8-sig")
        summary.update({"gt_type2_count": int((gt["type"] == "type_2").sum()),
                        "gt_matches": int(comparison["matched"].sum()) if "matched" in comparison else 0,
                        "matched_candidate_count": len(matched_indices)})
    if not df.empty:
        core.export_clips(Path(video), df, output_dir / "clips")
    return df, summary
