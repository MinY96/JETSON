"""Application orchestration: motion -> Type2 events -> frame selection -> gap measurement."""
from __future__ import annotations

import hashlib
import json
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np
import pandas as pd

from .core_install import ALGORITHM_SOURCES, install_algorithms
from .roi_config import resolve_rois


@dataclass
class AnalysisOptions:
    project_root: Path
    video: Path
    output: Path
    bright_reference: Path
    dark_reference: Path
    roi_file: Path | None = None
    roi_overrides: dict[str, tuple | None] = field(default_factory=dict)
    ground_truth: Path | None = None
    save_intermediates: str = "none"  # none or all
    frame_source: str = "selected"  # selected (encoded clip JPEG) or original
    sync_algorithms: bool = False
    dry_run: bool = False
    temp_root: Path | None = None
    analysis_width: int = 480
    frame_step: int = 1
    normal_x_ratio: float = 0.7
    dark_x_ratio: float = 0.7
    normal_top_offset: float = 0.0
    normal_bottom_offset: float = 0.0
    dark_top_offset: float = 0.0
    dark_bottom_offset: float = 0.0
    cst_motion_threshold: float = -2.0
    type2_peak_min: float = -8.0
    type2_peak_max: float = -2.0
    valley_threshold: float = 0.06
    rise_threshold: float = 0.075
    rise_delta: float = 0.055
    lead_frames: int = 1
    detail_scale: float = 2.0
    jpeg_quality: int = 98


class VideoAnalyzer:
    """One entry point for all reusable algorithms. No subprocess."""

    def __init__(self, options: AnalysisOptions):
        self.options = options
        self.rois = resolve_rois(options.roi_file, options.roi_overrides)

    def validate(self) -> None:
        o = self.options
        for name, value in (
            ("input video", o.video),
            ("bright Blade reference", o.bright_reference),
            ("dark Blade reference", o.dark_reference),
        ):
            if not Path(value).is_file():
                raise FileNotFoundError(f"Cannot find {name}: {value}")
        if o.ground_truth is not None and not Path(o.ground_truth).is_file():
            raise FileNotFoundError(f"Cannot find ground truth: {o.ground_truth}")
        if o.save_intermediates not in {"none", "all"}:
            raise ValueError("--save-intermediates must be none or all")
        if o.frame_source not in {"selected", "original"}:
            raise ValueError("--frame-source must be selected or original")
        if o.analysis_width < 16 or o.frame_step < 1 or o.lead_frames < 0:
            raise ValueError("Invalid analysis width, sampling step, or measurement lead")
        if not (0 <= o.normal_x_ratio <= 1 and 0 <= o.dark_x_ratio <= 1):
            raise ValueError("X ratio must be between zero and one")
        if not (0 < o.detail_scale <= 10) or not (1 <= o.jpeg_quality <= 100):
            raise ValueError("Invalid detail scale or image quality")
        if o.type2_peak_min >= o.type2_peak_max:
            raise ValueError("Type2 lower bound must be below upper bound")
        if o.output.resolve() == o.project_root.resolve():
            raise ValueError("Output cannot be the project root directory")
        if o.frame_step != 1:
            print("[NOTICE] Sampling steps other than 1 were not calibrated on the validated recording")

    def _video_properties(self) -> tuple[float, int]:
        cap = cv2.VideoCapture(str(self.options.video))
        if not cap.isOpened():
            raise RuntimeError(f"Unable to open video: {self.options.video}")
        try:
            fps = float(cap.get(cv2.CAP_PROP_FPS))
            count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        finally:
            cap.release()
        if fps <= 0:
            raise ValueError("Video frame rate is unavailable")
        return fps, count

    @staticmethod
    def combine(events: pd.DataFrame, selections: pd.DataFrame,
                measurements: pd.DataFrame, fps: float) -> pd.DataFrame:
        """Join by the explicit event_id, never by row position or slot number."""
        selected_map = {int(r["event_id"]): r for _, r in selections.iterrows()} if not selections.empty else {}
        measured_map = {int(r["event_id"]): r for _, r in measurements.iterrows()} if not measurements.empty else {}
        rows = []
        for _, event in events.iterrows():
            event_id = int(event["event_id"])
            selection = selected_map.get(event_id)
            measurement = measured_map.get(event_id)
            row = {
                "event_id": event_id,
                "event_key": f"type2_{event_id:03d}",
            }
            row.update({f"event_{col}": value for col, value in event.items() if col != "event_id"})
            if selection is not None:
                row.update({
                    "selection_status": selection.get("status"),
                    "departure_status": selection.get("departure_status"),
                    "departure_provisional_frame": selection.get("departure_frame_idx"),
                    "selected_clip_frame": selection.get("measurement_frame_idx"),
                    "selected_clip_sec": selection.get("measurement_sec"),
                    "valley_frame": selection.get("selection_valley_frame"),
                    "rise_frame": selection.get("selection_rise_frame"),
                })
            else:
                row["selection_status"] = "missing"

            if measurement is not None:
                row.update({k: v for k, v in measurement.items() if k != "event_id"})
            else:
                row["status"] = "measurement_missing"

            selected_frame = row.get("selected_clip_frame")
            if selected_frame is not None and pd.notna(selected_frame):
                # The verified clip exporter begins at floor(clip_start_sec * FPS).
                absolute_frame = (
                    int(np.floor(float(event["clip_start_sec"]) * fps)) + int(selected_frame)
                )
                row["source_frame_idx"] = absolute_frame
                row["source_video_sec"] = absolute_frame / fps
            else:
                row["source_frame_idx"] = None
                row["source_video_sec"] = None

            row["overlay_path"] = (
                f"overlay/type2_{event_id:03d}.jpg" if measurement is not None
                and measurement.get("status") not in {"error", "selection_not_available"} else ""
            )
            row["detail_path"] = (
                f"detail/type2_{event_id:03d}.jpg" if row["overlay_path"] else ""
            )
            rows.append(row)
        return pd.DataFrame(rows)

    @staticmethod
    def summarize(results: pd.DataFrame, validation: dict, elapsed: float) -> dict:
        statuses = results["status"].fillna("missing").value_counts().to_dict() \
            if "status" in results else {}
        summary = {
            "type2_events": len(results),
            "measurement_frames": int(results["selected_clip_frame"].notna().sum())
                if "selected_clip_frame" in results else 0,
            "statuses": {str(k): int(v) for k, v in statuses.items()},
            "runtime_sec": round(float(elapsed), 3),
            "ground_truth": validation,
        }
        for key in ("top_gap_px", "bottom_gap_px"):
            s = pd.to_numeric(results[key], errors="coerce") if key in results else pd.Series(dtype=float)
            summary[key] = {
                "count": int(s.notna().sum()),
                "mean": float(s.mean()) if s.notna().any() else None,
            }
        return summary

    def run(self) -> dict:
        self.validate()
        o = self.options
        print("=== EPI CST / Wafer Gap Analyzer ===")
        print(f"Video              : {o.video}")
        print(f"Output             : {o.output}")
        print(f"Keep intermediates : {o.save_intermediates}")
        print(f"Frame source       : {o.frame_source}")
        print(f"ROIs               : {self.rois}")

        if o.dry_run:
            return {"dry_run": True, "resolved_rois": self.rois}

        installed = install_algorithms(o.project_root, sync=o.sync_algorithms)
        for module in installed:
            print(f"[ALGORITHM INSTALL] {module}")

        # Import only after installation, for first-time execution.
        from .motion import signals
        from .events import detector
        from .frames import selector
        from .measurement import wafer_gaps

        o.output.mkdir(parents=True, exist_ok=True)
        started = time.perf_counter()
        manifest_path = o.output / "run_manifest.json"
        fps, frame_count = self._video_properties()
        manifest = {
            "started_at": datetime.now().isoformat(),
            "video": str(o.video.resolve()),
            "output": str(o.output.resolve()),
            "save_intermediates": o.save_intermediates,
            "frame_source": o.frame_source,
            "fps": fps,
            "frame_count": frame_count,
            "rois": self.rois,
            "algorithm_sources": {
                name: hashlib.sha256((o.project_root / module).read_bytes()).hexdigest()
                for name, module in ALGORITHM_SOURCES.items()
            },
            "status": "running",
        }

        def write_manifest():
            manifest_path.write_text(
                json.dumps(manifest, ensure_ascii=False, indent=2, default=str),
                encoding="utf-8",
            )
        write_manifest()

        def execute(work_dir: Path) -> dict:
            motion_dir = work_dir / "motion_signals"
            event_dir = work_dir / "type2_events"
            departure_dir = work_dir / "blade_departure"
            selection_dir = work_dir / "measurement_selection"

            print("\n[1/4] Extracting motion signals")
            signal_df = signals.run(
                o.video, motion_dir, o.analysis_width, o.frame_step,
                self.rois["cst_motion_roi"], {
                    "blade1": self.rois["blade_motion_candidate_1_roi"],
                    "blade2": self.rois["blade_motion_primary_roi"],
                    "blade3": self.rois["blade_motion_candidate_3_roi"],
                },
            )

            print("\n[2/4] Detecting Type2 events")
            event_df, validation = detector.run(
                o.video, signal_df, event_dir,
                gt_path=o.ground_truth,
                cst_motion_threshold=o.cst_motion_threshold,
                type2_peak_min=o.type2_peak_min,
                type2_peak_max=o.type2_peak_max,
            )
            if event_df.empty:
                print("[INFO] No Type2 event detected")
                selection_df = pd.DataFrame(columns=["event_id", "status", "measurement_frame_idx"])
                measured_df = pd.DataFrame(columns=["event_id", "status", "top_gap_px", "bottom_gap_px"])
                (o.output / "overlay").mkdir(parents=True, exist_ok=True)
                (o.output / "detail").mkdir(parents=True, exist_ok=True)
                measured_df.to_csv(o.output / "geometry_results.csv", index=False, encoding="utf-8-sig")
            else:
                print("\n[3/4] Selecting measurement frames")
                selection_df = selector.run(
                    event_dir / "clips", departure_dir, selection_dir, event_df,
                    self.rois["cst_motion_roi"], self.rois["blade_departure_roi"],
                    valley_threshold=o.valley_threshold,
                    rise_threshold=o.rise_threshold,
                    rise_delta=o.rise_delta,
                    lead_frames=o.lead_frames,
                    save_comparisons=o.save_intermediates == "all",
                )
                print("\n[4/4] Measuring Blade-to-Wafer gaps")
                measured_df = wafer_gaps.run(
                    o.video, event_df, selection_df, o.output,
                    o.bright_reference, o.dark_reference,
                    self.rois["blade_template_search_roi"],
                    self.rois["wafer_measurement_roi"],
                    o.normal_x_ratio, o.dark_x_ratio,
                    frame_source=o.frame_source,
                    detail_scale=o.detail_scale, jpeg_quality=o.jpeg_quality,
                    top_offsets=(o.normal_top_offset, o.dark_top_offset),
                    bottom_offsets=(o.normal_bottom_offset, o.dark_bottom_offset),
                    save_debug=o.save_intermediates == "all",
                )

            integrated = self.combine(event_df, selection_df, measured_df, fps)
            integrated.to_csv(o.output / "integrated_results.csv", index=False, encoding="utf-8-sig")
            summary = self.summarize(integrated, validation, time.perf_counter() - started)
            summary.update({"fps": fps, "frame_count": frame_count})
            (o.output / "summary.json").write_text(
                json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            return summary

        try:
            if o.save_intermediates == "all":
                summary = execute(o.output / "intermediate")
            else:
                if o.temp_root is not None:
                    o.temp_root.mkdir(parents=True, exist_ok=True)
                with tempfile.TemporaryDirectory(prefix="epi_intermediate_", dir=o.temp_root) as tmp:
                    summary = execute(Path(tmp))
            manifest["status"] = "completed"
            manifest["summary"] = summary
        except Exception as exc:
            manifest["status"] = "failed"
            manifest["error"] = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            manifest["finished_at"] = datetime.now().isoformat()
            write_manifest()
        return summary
