"""Select each measurement frame using Blade motion and temporal valley/rise."""
from __future__ import annotations
from pathlib import Path
import pandas as pd
from . import _departure_core as departure
from . import _timing_core as timing


def run(clips_dir: Path, departure_output: Path, selection_output: Path,
        event_df: pd.DataFrame, cst_roi: tuple, blade_departure_roi: tuple,
        valley_threshold: float = 0.06, rise_threshold: float = 0.075,
        rise_delta: float = 0.055, lead_frames: int = 1,
        save_comparisons: bool = False) -> pd.DataFrame:
    """Calls underlying pure entry points, never a CLI subprocess."""
    clips_dir = Path(clips_dir)
    departure_output = Path(departure_output)
    selection_output = Path(selection_output)
    for directory in [departure_output, departure_output / "debug", selection_output,
                      selection_output / "debug", selection_output / "measurement_frames",
                      selection_output / "comparison", selection_output / "candidates"]:
        directory.mkdir(parents=True, exist_ok=True)
    cfg2 = departure.Config(cst_roi=tuple(cst_roi), blade_roi=tuple(blade_departure_roi),
                     save_debug_csv=True, save_comparison=save_comparisons,
                     save_debug_video=False)
    cfg3 = timing.Config(valley_threshold=valley_threshold, rise_threshold=rise_threshold,
                     rise_delta=rise_delta, measurement_lead_frames=lead_frames)
    rows = []
    for _, event in event_df.iterrows():
        eid = int(event["event_id"])
        stem = f"type2_{eid:03d}"
        clip_path = clips_dir / f"{stem}.mp4"
        result = {"event_id": eid, "clip": clip_path.name}
        try:
            if not clip_path.is_file():
                raise FileNotFoundError(clip_path)
            v2 = departure.analyze_clip(clip_path, departure_output, cfg2)
            result["departure_status"] = v2.get("status")
            result["departure_frame_idx"] = v2.get("measurement_frame_idx")
            debug_csv = departure_output / "debug" / f"{stem}_debug.csv"
            if not debug_csv.is_file():
                result["status"] = "departure_debug_missing"
            else:
                v3 = timing.analyze_one_clip(csv_path=debug_csv,
                                         clips_dir=clips_dir,
                                         output_dir=selection_output,
                                         cfg=cfg3,
                                         old_result=v2)
                result.update({f"selection_{key}": value for key, value in v3.items()})
                result["status"] = v3.get("status", "unknown")
                result["measurement_frame_idx"] = v3.get("measurement_frame_idx")
                result["measurement_sec"] = v3.get("measurement_sec")
                result["measurement_image"] = v3.get("measurement_image")
        except Exception as exc:
            result["status"] = "error"
            result["error"] = f"{type(exc).__name__}: {exc}"
        rows.append(result)
        print(f"[FRAME SELECT] {stem}: {result['status']} | measurement={result.get('measurement_frame_idx')}")
    df = pd.DataFrame(rows)
    df.to_csv(selection_output / "measurement_frames.csv", index=False, encoding="utf-8-sig")
    return df
