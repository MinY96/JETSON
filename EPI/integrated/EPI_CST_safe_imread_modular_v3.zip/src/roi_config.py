"""Functional ROI names and optional backward compatibility for old roi.txt."""
from __future__ import annotations

import ast
import re
from pathlib import Path

DEFAULT_ROIS = {
    "cst_motion_roi": (2039, 110, 149, 654),
    "blade_motion_candidate_1_roi": (16, 267, 621, 360),
    "blade_motion_primary_roi": (309, 379, 1593, 236),
    "blade_motion_candidate_3_roi": (74, 300, 1109, 302),
    "blade_departure_roi": (309, 359, 1593, 216),
    "blade_template_search_roi": (50, 300, 620, 250),
    "wafer_measurement_roi": (50, 315, 620, 235),
}

# Old keys are supported for existing installations, but never written in new files.
LEGACY_ALIASES = {
    "cst_roi": "cst_motion_roi",
    "blade1_roi": "blade_motion_candidate_1_roi",
    "blade2_roi": "blade_motion_primary_roi",
    "blade3_roi": "blade_motion_candidate_3_roi",
    "a2_blade_roi": "blade_departure_roi",
    "search_roi": "blade_template_search_roi",
    "measure_roi": "wafer_measurement_roi",
}


def normalize_roi(value, source="ROI") -> tuple[int, int, int, int]:
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        raise ValueError(f"{source}: expected (x, y, width, height)")
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or int(v) != v for v in value):
        raise ValueError(f"{source}: coordinates must be integers")
    x, y, w, h = (int(v) for v in value)
    if x < 0 or y < 0 or w <= 0 or h <= 0:
        raise ValueError(f"{source}: x, y must be nonnegative and width, height positive")
    return x, y, w, h


def load_roi_txt(path: Path | None) -> dict[str, tuple[int, int, int, int]]:
    if path is None or not Path(path).is_file():
        return {}
    parsed: dict[str, tuple[int, int, int, int]] = {}
    for lineno, line in enumerate(Path(path).read_text(encoding="utf-8-sig").splitlines(), 1):
        line = line.split("#", 1)[0].strip()
        if not line or line.startswith(("//", ";")):
            continue
        m = re.fullmatch(r"([A-Za-z][A-Za-z_0-9]*)\s*(?:=|:)\s*(.+)", line)
        if m is None:
            raise ValueError(f"{path}:{lineno}: expected key = (x,y,w,h)")
        key, value = m.groups()
        key = key.lower()
        if key not in DEFAULT_ROIS and key not in LEGACY_ALIASES:
            raise ValueError(f"{path}:{lineno}: unsupported ROI name '{key}'")
        try:
            item = ast.literal_eval(value)
            if isinstance(item, str):
                item = ast.literal_eval(item)
            parsed[key] = normalize_roi(item, f"{path}:{lineno}: {key}")
        except (SyntaxError, TypeError, ValueError) as exc:
            raise ValueError(f"{path}:{lineno}: invalid {key}: {exc}") from exc
    # Preferred names win even when legacy alias is also present.
    normalized = {LEGACY_ALIASES[k]: v for k, v in parsed.items() if k in LEGACY_ALIASES}
    normalized.update({k: v for k, v in parsed.items() if k in DEFAULT_ROIS})
    return normalized


def resolve_rois(roi_file: Path | None, overrides: dict | None = None) -> dict:
    values = {**DEFAULT_ROIS, **load_roi_txt(roi_file)}
    for name, roi in (overrides or {}).items():
        if name not in DEFAULT_ROIS:
            raise ValueError(f"Unknown ROI override: {name}")
        if roi is not None:
            values[name] = normalize_roi(roi, name)
    return values
