"""Offline MP4 analyzer using the same online decision engine."""
import sys
from main import main

if __name__ == '__main__':
    main(['--mode', 'analysis', *sys.argv[1:]])
