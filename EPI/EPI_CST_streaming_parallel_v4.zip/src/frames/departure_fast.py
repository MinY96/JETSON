"""Low-RAM Blade departure detection using A-v2's verified math.

A-v2 originally calls read_video_frames() and stores all full-resolution color
frames. This variant decodes a clip once into compact preprocessed CST/Blade
ROI images and fetches ONLY selected full-resolution frames afterwards.
Thresholding, temporal signal calculations and frame selection functions
remain delegated to _departure_core.
"""
from __future__ import annotations

from pathlib import Path
import cv2
import numpy as np
import pandas as pd

from . import _departure_core as core


def analyze_clip(clip_path: Path, output_dir: Path, cfg):
    cap = cv2.VideoCapture(str(clip_path))
    if not cap.isOpened():
        raise RuntimeError(f'Cannot open clip: {clip_path}')
    fps = float(cap.get(cv2.CAP_PROP_FPS))
    cst_images = []
    blade_images = []
    try:
        if fps <= 0:
            raise ValueError(f'Invalid clip FPS: {fps}')
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            cst_images.append(core.preprocess_cst(frame, cfg))
            blade_images.append(core.preprocess_blade(frame, cfg))
    finally:
        cap.release()
    n = len(cst_images)
    if n < 8:
        raise RuntimeError(f'Too few frames in clip: {n}')

    # Equivalent to original calculate_cst_signal(frames,fps,cfg).
    h, w = cst_images[0].shape
    hann = cv2.createHanningWindow((w, h), cv2.CV_32F)
    cst_rows = []
    for i, image in enumerate(cst_images):
        if i == 0:
            dx, dy, response = 0., 0., 1.
        else:
            (dx, dy), response = cv2.phaseCorrelate(cst_images[i - 1], image, hann)
        cst_rows.append({
            'frame_idx': i, 'clip_sec': i / fps,
            'cst_dx': float(dx), 'cst_dy': float(dy),
            'cst_response': float(response),
        })
    cst_df = pd.DataFrame(cst_rows)
    peak = core.detect_cst_peak(cst_df, cfg)
    result = {'clip': clip_path.name, 'fps': fps, 'frame_count': n, 'status': ''}
    if peak is None:
        result['status'] = 'cst_peak_not_found'
        return result
    result.update({
        'cst_peak_frame': peak['frame_idx'],
        'cst_peak_sec': peak['time_sec'],
        'cst_peak_dy': peak['dy'],
    })

    # Equivalent to original calculate_blade_signal(frames,fps,cst_peak_frame,cfg).
    ref_idx = max(0, peak['frame_idx'] - 1)
    ref_img = blade_images[ref_idx]
    blade_rows = []
    previous = None
    for i, image in enumerate(blade_images):
        features = core.masked_image_difference(
            ref_img, image, cfg.blade_diff_threshold, cfg.inner_margin_ratio
        )
        if previous is None:
            temporal_ratio, temporal_energy = 0., 0.
        else:
            temporal = core.masked_image_difference(
                previous, image, cfg.blade_diff_threshold, cfg.inner_margin_ratio
            )
            temporal_ratio = temporal['change_ratio']
            temporal_energy = temporal['change_energy']
        laplacian = cv2.Laplacian(image, cv2.CV_32F)
        sharpness = float(laplacian.var())
        blade_rows.append({
            'frame_idx': i, 'clip_sec': i / fps,
            **features, 'temporal_ratio': temporal_ratio,
            'temporal_energy': temporal_energy, 'sharpness': sharpness,
        })
        previous = image
    blade_df = pd.DataFrame(blade_rows)
    signal_df = cst_df.merge(
        blade_df.drop(columns=['clip_sec']), on='frame_idx', how='left'
    )
    result['blade_reference_frame'] = ref_idx
    out_start, threshold = core.detect_blade_out(blade_df, peak['frame_idx'], fps, cfg)
    result['out_threshold'] = threshold

    debug_dir = output_dir / 'debug'
    measure_dir = output_dir / 'measurement_frames'
    compare_dir = output_dir / 'comparison'
    for directory in (debug_dir, measure_dir, compare_dir):
        directory.mkdir(parents=True, exist_ok=True)
    if out_start is None:
        result['status'] = 'blade_out_not_found'
        measure_idx = None
        out_idx = None
    else:
        out_idx = int(out_start['frame_idx'])
        measure_idx = core.choose_measurement_frame(out_start, peak, cfg)
        result.update({
            'blade_out_start_frame': out_idx,
            'blade_out_start_sec': out_idx / fps,
            'blade_out_change_ratio': out_start['change_ratio'],
            'blade_out_temporal_ratio': out_start['temporal_ratio'],
            'blade_out_growth': out_start['growth'],
        })
        result['status'] = 'ok' if measure_idx is not None else 'invalid_sequence'
    signal_df['is_cst_peak'] = signal_df['frame_idx'] == peak['frame_idx']
    signal_df['is_blade_out_start'] = signal_df['frame_idx'] == out_idx if out_idx is not None else False
    signal_df['is_measurement'] = signal_df['frame_idx'] == measure_idx if measure_idx is not None else False
    signal_df['out_threshold'] = threshold
    if cfg.save_debug_csv:
        signal_df.to_csv(debug_dir / f'{clip_path.stem}_debug.csv',
                         index=False, encoding='utf-8-sig')
    if measure_idx is None:
        return result

    cap = cv2.VideoCapture(str(clip_path))
    try:
        full_frames = {}
        for i in {int(measure_idx), int(out_idx)}:
            cap.set(cv2.CAP_PROP_POS_FRAMES, i)
            ok, frame = cap.read()
            if not ok:
                raise IOError(f'Cannot read selected frame {i} from {clip_path}')
            full_frames[i] = frame
    finally:
        cap.release()
    measure_path = measure_dir / f'{clip_path.stem}_measurement.jpg'
    cv2.imwrite(str(measure_path), full_frames[measure_idx])
    compare_path = compare_dir / f'{clip_path.stem}_comparison.jpg'
    if cfg.save_comparison:
        core.save_comparison_image(
            full_frames[measure_idx], full_frames[out_idx],
            measure_idx, out_idx, fps, compare_path, cfg
        )
    result.update({
        'measurement_frame_idx': measure_idx,
        'measurement_sec': measure_idx / fps,
        'measurement_cst_dy': float(signal_df.iloc[measure_idx]['cst_dy']),
        'measurement_change_ratio': float(signal_df.iloc[measure_idx]['change_ratio']),
        'measurement_image': str(measure_path),
        'comparison_image': str(compare_path) if cfg.save_comparison else '',
    })
    return result
