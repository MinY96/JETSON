"""Per-event clip -> verified A2/A3 -> B5.1 -> deliverables."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
import json
import math
import shutil
import tempfile
import time

import cv2
import numpy as np
import pandas as pd

from src.common.image_io import safe_imread
from src.frames import selector
from src.measurement import _gap_core as gap


def _json_safe(v):
    if isinstance(v, dict):
        return {str(k): _json_safe(value) for k, value in v.items()}
    if isinstance(v, (list, tuple)):
        return [_json_safe(x) for x in v]
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return _json_safe(float(v))
    if isinstance(v, (np.ndarray,)):
        return _json_safe(v.tolist())
    if isinstance(v, float) and not math.isfinite(v):
        return None
    if v is pd.NA:
        return None
    return v


def safe_write_image(path: Path, image, quality=98):
    ext = path.suffix.lower()
    if ext not in {'.jpg', '.jpeg', '.png'}:
        raise ValueError(f'Unsupported image output: {path}')
    opts = [cv2.IMWRITE_JPEG_QUALITY, quality] if ext != '.png' else []
    ok, encoded = cv2.imencode(ext, image, opts)
    if not ok:
        raise IOError(f'Could not encode image: {path}')
    encoded.tofile(str(path))


def _writer(path: Path, fps: float, frame_size):
    result = cv2.VideoWriter(
        str(path), cv2.VideoWriter_fourcc(*'mp4v'),
        float(fps), tuple(frame_size),
    )
    if not result.isOpened():
        raise RuntimeError(f'VideoWriter failed: {path}')
    return result


def make_clip_from_file(source: Path, event: dict, target: Path, fps: float):
    """Matches E3's source frame bounds: floor(start*fps) ~ ceil(end*fps)."""
    cap = cv2.VideoCapture(str(source))
    if not cap.isOpened():
        raise IOError(f'Cannot reopen source file: {source}')
    writer = None
    try:
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        start_frame = max(0, int(np.floor(float(event['clip_start_sec']) * fps)))
        end_frame = min(total - 1, int(np.ceil(float(event['clip_end_sec']) * fps)))
        if end_frame <= start_frame:
            raise RuntimeError(f'Invalid clip range {start_frame}..{end_frame}')
        cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
        writer = _writer(target, fps, (width, height))
        count = 0
        for i in range(start_frame, end_frame + 1):
            ok, frame = cap.read()
            if not ok or frame is None:
                break
            writer.write(frame)
            count += 1
        if count < 8:
            raise RuntimeError('Too few extracted frames')
        return start_frame, count
    finally:
        cap.release()
        if writer is not None:
            writer.release()


def make_clip_from_ring(frames, target: Path, fps: float):
    writer = None
    try:
        for item in frames:
            frame = cv2.imdecode(np.frombuffer(item.encoded, dtype=np.uint8), cv2.IMREAD_COLOR)
            if frame is None:
                raise IOError(f'Cannot decode cached frame {item.index}')
            if writer is None:
                h, w = frame.shape[:2]
                writer = _writer(target, fps, (w, h))
            writer.write(frame)
        if len(frames) < 8:
            raise RuntimeError('Insufficient buffered frames')
        return int(frames[0].index), len(frames)
    finally:
        if writer is not None:
            writer.release()


def render_overlay_clip(clip_path: Path, dest: Path, fps: float,
                        selected_idx: int | None, measured_result: dict | None,
                        measured_debug: dict | None, cfg, event_id: int):
    """Overlay gap only around the measured frame, never on moving blade frames."""
    cap = cv2.VideoCapture(str(clip_path))
    if not cap.isOpened():
        raise IOError(clip_path)
    writer = None
    try:
        idx = 0
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            if writer is None:
                h, w = frame.shape[:2]
                writer = _writer(dest, fps, (w, h))
            if (selected_idx is not None and measured_result is not None
                and measured_debug is not None and abs(idx - selected_idx) <= 2):
                frame = gap.draw_overlay(frame, measured_result, measured_debug, cfg)
                cv2.putText(frame, 'MEASUREMENT', (20, 65), cv2.FONT_HERSHEY_SIMPLEX,
                            0.8, (60, 90, 255), 2, cv2.LINE_AA)
            cv2.putText(frame, f'TYPE2 EVENT {event_id:04d}', (20, 35),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.72, (255, 255, 255), 2, cv2.LINE_AA)
            writer.write(frame)
            idx += 1
        if idx < 1:
            raise RuntimeError('Overlay clip has no frames')
    finally:
        cap.release()
        if writer is not None:
            writer.release()


class EventProcessor:
    def __init__(self, options, rois, fps: float, archive=None):
        self.options = options
        self.rois = rois
        self.fps = float(fps)
        self.archive = archive
        self.output = Path(options.output)
        self.refs = None
        self.cfg = None
        self._initialize_measurement()

    def _initialize_measurement(self):
        o = self.options
        cfg = gap.Config(
            search_roi=tuple(self.rois['blade_template_search_roi']),
            measure_roi=tuple(self.rois['wafer_measurement_roi']),
            normal_x_ratio=o.normal_x_ratio,
            dark_x_ratio=o.dark_x_ratio,
            detail_scale=o.detail_scale,
            jpeg_quality=o.jpeg_quality,
        )
        self.refs = gap.load_references(o.bright_reference, o.dark_reference, cfg)
        self.cfg = cfg

    def save_rejected(self, event: dict, reason: str) -> dict:
        # Even a skipped job produces a traceable event folder and JSON.
        stamp = datetime.now()
        eid = int(event['event_id'])
        folder = (self.output / 'events' /
                  f"{stamp.strftime('%Y%m%d_%H%M%S_%f')}_e{eid:04d}")
        folder.mkdir(parents=True, exist_ok=False)
        record = {
            'event_id': eid,
            'session_id': self.options.session_id,
            'event_folder': str(folder.relative_to(self.output)),
            'status': reason,
            'error': 'Event worker queue was full',
            'top_gap_px': None,
            'bottom_gap_px': None,
            'gap_diff_px': None,
            'top_bottom_ratio_10': None,
        }
        report = {
            'schema_version': 1,
            'session_id': self.options.session_id,
            'judged_at': stamp.isoformat(timespec='microseconds'),
            'event_id': eid,
            'event': _json_safe(event),
            'measurement': {'status': reason, 'top_gap_px': None,
                            'bottom_gap_px': None, 'diff_px': None, 'ratio_10': None},
            'data_quality': {'status': 'NOT_MEASURED'},
            'quality_decision': {'status': 'NOT_EVALUATED', 'ok_ng': None, 'rule_version': None},
            'files': {},
            'error': record['error'],
        }
        (folder / 'result.json').write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
        pd.DataFrame([record]).to_csv(folder / 'result.csv', index=False, encoding='utf-8-sig')
        return record

    def process(self, event: dict) -> dict:
        event_id = int(event['event_id'])
        # Temporary event folder is renamed to the exact judgment timestamp.
        folder = (self.output / 'events' /
                  f"processing_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}_e{event_id:04d}")
        folder.mkdir(parents=True, exist_ok=False)
        t0 = time.perf_counter()
        metrics = {k: None for k in ('top_gap_px', 'bottom_gap_px', 'gap_diff_px',
                                     'top_ratio', 'bottom_ratio', 'top_bottom_ratio_10')}
        record = {
            'event_id': event_id,
            'session_id': self.options.session_id,
            'event_folder': str(folder.relative_to(self.output)),
            'cst_peak_sec': float(event['cst_peak_sec']),
            'clip_start_sec': float(event['clip_start_sec']),
            'clip_end_sec': float(event['clip_end_sec']),
            'measurement_frame_idx': None,
            'source_frame_idx': None,
            'measurement_video_sec': None,
            'status': 'processing',
            'error': None,
            'motion_frame_loss_near_event': bool(event.get('motion_frame_loss_near_event', False)),
            **metrics,
        }
        measured_result = None
        measured_debug = None
        measurement_idx = None
        work_context = None
        try:
            if self.options.save_intermediates == 'all':
                work = folder / 'intermediate'
                work.mkdir(parents=True, exist_ok=True)
            else:
                work_context = tempfile.TemporaryDirectory(prefix='epi_job_', dir=str(self.output))
                work = Path(work_context.name)
            clip_dir = work / 'clips'
            dep_dir = work / 'departure'
            sel_dir = work / 'selection'
            for path in (clip_dir, dep_dir, sel_dir):
                path.mkdir(parents=True, exist_ok=True)
            clip = folder / 'clip_original.mp4'
            if self.archive is None:
                source_start_idx, clip_count = make_clip_from_file(
                    self.options.video, event, clip, self.fps
                )
            else:
                encoded = self.archive.snapshot(
                    float(event['clip_start_sec']), float(event['clip_end_sec']),
                    self.fps, timeout=self.options.archive_wait_sec,
                )
                source_start_idx, clip_count = make_clip_from_ring(encoded, clip, self.fps)
            # Reference A2/A3 are invoked as pure functions on one clip.
            local_clip = clip_dir / f'type2_{event_id:03d}.mp4'
            if self.options.save_intermediates == 'all':
                shutil.copy2(clip, local_clip)
            else:
                # Re-use same bytes via hard link where possible, avoiding a second copy.
                try:
                    local_clip.hardlink_to(clip)
                except OSError:
                    shutil.copy2(clip, local_clip)
            sel_df = selector.run(
                clip_dir, dep_dir, sel_dir, pd.DataFrame([event]),
                cst_roi=self.rois['cst_motion_roi'],
                blade_departure_roi=self.rois['blade_departure_roi'],
                valley_threshold=self.options.valley_threshold,
                rise_threshold=self.options.rise_threshold,
                rise_delta=self.options.rise_delta,
                lead_frames=self.options.lead_frames,
                save_comparisons=self.options.save_intermediates == 'all',
            )
            select = sel_df.iloc[0].to_dict()
            record['selection_status'] = str(select.get('status', 'unknown'))
            if select.get('status') != 'ok':
                record['status'] = 'measurement_selection_failed'
                record['error'] = str(select.get('error', select.get('status')))
            else:
                measurement_idx = int(select['measurement_frame_idx'])
                record['measurement_frame_idx'] = measurement_idx
                record['source_frame_idx'] = source_start_idx + measurement_idx
                # From offline source/video FPS; live uses logical capture time.
                record['measurement_video_sec'] = (
                    record['source_frame_idx'] / self.fps if self.archive is None else None
                )
                # Prefer original source pixels over A3's already-reencoded JPEG.
                # The A3 choice (frame index) stays unchanged.
                source_img = None
                if self.options.measurement_source == 'original':
                    if self.archive is None:
                        direct = cv2.VideoCapture(str(self.options.video))
                        try:
                            if direct.isOpened():
                                direct.set(cv2.CAP_PROP_POS_FRAMES, record['source_frame_idx'])
                                success, source_img = direct.read()
                                if not success:
                                    source_img = None
                        finally:
                            direct.release()
                    elif measurement_idx < len(encoded):
                        source_img = cv2.imdecode(
                            np.frombuffer(encoded[measurement_idx].encoded, dtype=np.uint8),
                            cv2.IMREAD_COLOR,
                        )
                if source_img is None:
                    source_img = safe_imread(select['measurement_image'])
                if source_img is None:
                    raise IOError('Selected measurement image not readable')
                safe_write_image(folder / 'measurement_frame.jpg', source_img, self.options.jpeg_quality)
                measured_result, measured_debug = gap.analyze_image(source_img, self.refs, self.cfg)
                flat = gap.flatten_result('measurement_frame.jpg', measured_result)
                for key, value in flat.items():
                    if key not in {'image', 'event_id'}:
                        record[key] = _json_safe(value)
                safe_write_image(
                    folder / 'overlay.jpg',
                    gap.draw_overlay(source_img, measured_result, measured_debug, self.cfg),
                    self.options.jpeg_quality,
                )
                safe_write_image(
                    folder / 'detail.jpg',
                    gap.create_detail(source_img, measured_result, measured_debug, self.cfg),
                    self.options.jpeg_quality,
                )
                record['status'] = str(measured_result['status'])
                if self.options.save_intermediates == 'all':
                    (work / 'gap_debug').mkdir(parents=True, exist_ok=True)
                    gap.save_debug(work / 'gap_debug', f'type2_{event_id:03d}', measured_debug, measured_result)
            render_overlay_clip(
                clip, folder / 'clip_overlay.mp4', self.fps,
                measurement_idx, measured_result, measured_debug, self.cfg, event_id,
            )
            record['clip_frame_count'] = clip_count
        except Exception as exc:
            record['status'] = 'error'
            record['error'] = f'{type(exc).__name__}: {exc}'
        finally:
            # Keep both video outputs for review even when measurement fails.
            if (folder / 'clip_original.mp4').is_file() and not (folder / 'clip_overlay.mp4').is_file():
                try:
                    render_overlay_clip(
                        folder / 'clip_original.mp4', folder / 'clip_overlay.mp4', self.fps,
                        None, None, None, self.cfg, event_id,
                    )
                except Exception as overlay_exc:
                    record['overlay_clip_error'] = repr(overlay_exc)
            if work_context is not None:
                work_context.cleanup()
            judgment_time = datetime.now()
            final_folder = (self.output / 'events' /
                            f"{judgment_time.strftime('%Y%m%d_%H%M%S_%f')}_e{event_id:04d}")
            folder.rename(final_folder)
            folder = final_folder
            record['event_folder'] = str(folder.relative_to(self.output))
            record['process_ms'] = round(1000 * (time.perf_counter() - t0), 2)
            # Do not invent OK/NG logic. JSON is designed for later thresholding.
            report = {
                'schema_version': 1,
                'session_id': self.options.session_id,
                'event_id': event_id,
                'judged_at': judgment_time.isoformat(timespec='microseconds'),
                'event': _json_safe(event),
                'measurement': {
                    'status': record['status'],
                    'top_gap_px': _json_safe(record.get('top_gap_px')),
                    'bottom_gap_px': _json_safe(record.get('bottom_gap_px')),
                    'diff_px': _json_safe(record.get('gap_diff_px')),
                    'ratio_10': _json_safe(record.get('top_bottom_ratio_10')),
                    'top_ratio_percent': _json_safe(record.get('top_ratio')),
                    'bottom_ratio_percent': _json_safe(record.get('bottom_ratio')),
                },
                'data_quality': {
                    'motion_frame_loss_near_event': bool(record.get('motion_frame_loss_near_event')),
                    'status': 'DEGRADED' if record.get('motion_frame_loss_near_event') else 'COMPLETE',
                    'frame_origin': self.options.measurement_source,
                },
                'quality_decision': {
                    'status': 'NOT_EVALUATED',
                    'ok_ng': None,
                    'rule_version': None,
                },
                'files': {
                    key: key for key in ('clip_original.mp4', 'clip_overlay.mp4',
                                        'measurement_frame.jpg', 'overlay.jpg', 'detail.jpg')
                    if (folder / key).is_file()
                },
                'error': record.get('error'),
            }
            (folder / 'result.json').write_text(json.dumps(
                _json_safe(report), ensure_ascii=False, indent=2, allow_nan=False,
            ), encoding='utf-8')
            pd.DataFrame([record]).to_csv(folder / 'result.csv', index=False, encoding='utf-8-sig')
            print(f'[EVENT {event_id:04d}] {record["status"]} -> {folder}', flush=True)
        return record
