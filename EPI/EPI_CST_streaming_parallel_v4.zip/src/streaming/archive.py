"""Bounded JPEG archive for live camera. Offline files are re-read instead."""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import threading
import time

import cv2
import numpy as np


@dataclass(frozen=True)
class EncodedFrame:
    index: int
    second: float
    encoded: bytes


class RollingArchive:
    def __init__(self, seconds=45., max_mb=512.):
        self.max_seconds = float(seconds)
        self.max_bytes = int(max_mb * 1024 * 1024)
        self.frames = deque()
        self.bytes = 0
        self.cv = threading.Condition()
        self.closed = False
        self.evicted = 0

    def put(self, idx: int, second: float, frame, quality: int = 90):
        ok, buf = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, int(quality)])
        if not ok:
            raise IOError('Archive jpeg encoding failed')
        item = EncodedFrame(idx, second, buf.tobytes())
        with self.cv:
            self.frames.append(item)
            self.bytes += len(item.encoded)
            while self.frames and (
                second - self.frames[0].second > self.max_seconds
                or self.bytes > self.max_bytes
            ):
                old = self.frames.popleft()
                self.bytes -= len(old.encoded)
                self.evicted += 1
            self.cv.notify_all()

    def snapshot(self, start: float, end: float, fps: float, timeout: float):
        deadline = time.monotonic() + timeout
        with self.cv:
            while (not self.closed and (
                not self.frames or self.frames[-1].second < end - 1.5 / fps
            )):
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                self.cv.wait(remaining)
            selected = [f for f in self.frames if start - 0.5 / fps <= f.second <= end + 0.5 / fps]
        if not selected:
            raise RuntimeError('Archive frame range unavailable')
        missing = sum(max(0, b.index - a.index - 1) for a, b in zip(selected, selected[1:]))
        incomplete = (
            selected[0].second > start + 2 / fps
            or selected[-1].second < end - 2 / fps
            or missing > 0
        )
        if incomplete:
            raise RuntimeError(
                f'Archive incomplete: start={selected[0].second:.3f}, '
                f'end={selected[-1].second:.3f}, missing={missing}; '
                'increase archive capacity or reduce load'
            )
        return selected

    def close(self):
        with self.cv:
            self.closed = True
            self.cv.notify_all()
