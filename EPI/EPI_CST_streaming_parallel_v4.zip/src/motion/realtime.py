"""Fast CST + *single blade2* motion extractor.

Preserves the original E1 CST phase correlation and Blade frame-difference
calculation. blade1/blade3 and all Farneback optical flow are not computed.
"""
from __future__ import annotations


class SingleBladeMotion:
    def __init__(self, cst_roi, blade_roi, analysis_width=480):
        from . import _signal_core as core
        self.core = core
        self.cfg = core.Config(blade_analysis_width=int(analysis_width), frame_step=1)
        self.cst_roi = tuple(cst_roi)
        self.blade_roi = tuple(blade_roi)
        self.prev_cst = None
        self.prev_blade = None
        self._prior_index = None

    def process(self, frame, frame_idx: int, time_sec: float):
        core = self.core
        cst = core.prepare_cst(frame, self.cst_roi, self.cfg.cst_blur_ksize)
        blade = core.prepare_blade(frame, self.blade_roi, self.cfg.blade_analysis_width)
        if self.prev_cst is None:
            self.prev_cst, self.prev_blade = cst, blade
            self._prior_index = frame_idx
            return None   # E1 begins with frame index 1
        dx, dy, response = core.calculate_phase_shift(self.prev_cst, cst)
        motion_ratio, mean_diff = core.calculate_frame_difference(
            self.prev_blade, blade, self.cfg.blade_diff_pixel_threshold
        )
        row = {
            'frame_idx': int(frame_idx), 'time_sec': float(time_sec),
            'video_time': core.format_video_time(time_sec),
            'cst_dx': float(dx), 'cst_dy': float(dy),
            'cst_phase_response': float(response),
            'blade2_motion_ratio': float(motion_ratio),
            'blade2_mean_diff': float(mean_diff),
        }
        self.prev_cst, self.prev_blade = cst, blade
        self._prior_index = frame_idx
        return row
