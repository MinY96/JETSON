"""Portable OpenCV image loading for Unicode (including Korean) paths.

Keep cv2.imread's default return convention: unreadable files return None.
Uses NumPy to read path bytes, then OpenCV to decode those bytes.
"""
from __future__ import annotations

from os import PathLike

import cv2
import numpy as np


def safe_imread(
    filename: str | PathLike[str],
    flags: int = cv2.IMREAD_COLOR,
) -> np.ndarray | None:
    """Load an image from a filename without cv2.imread's path decoding issues.

    Args:
        filename: Path or str, including Korean/Unicode characters.
        flags: OpenCV decode flags, e.g. IMREAD_COLOR / GRAYSCALE / UNCHANGED.

    Returns:
        Decoded image, or None if the file cannot be read/decoded.
    """
    try:
        encoded = np.fromfile(filename, dtype=np.uint8)
        if encoded.size == 0:
            return None
        return cv2.imdecode(encoded, flags)
    except (OSError, ValueError, TypeError, cv2.error):
        return None
