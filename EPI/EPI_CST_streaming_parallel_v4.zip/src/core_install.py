"""Install verified algorithm implementations as role-named Python modules.

No subprocess is used. CLI entry points are stripped. All calls of
cv2.imread (or cv.imread) in generated and already-installed modules are
replaced by src.common.image_io.safe_imread, including existing installations.
The source scripts/ are kept unmodified by this installer; users can migrate
those legacy entry points with ``python tools/migrate_image_io.py``.
"""
from __future__ import annotations

import ast
from pathlib import Path

ALGORITHM_SOURCES = {
    "phase_e1_01_extract_motion_signals_v2.py": "src/motion/_signal_core.py",
    "phase_e3_03_extract_clips.py": "src/events/_event_core.py",
    "phase_a1_select_measurement_frame_v2.py": "src/frames/_departure_core.py",
    "phase_a1_select_measurement_frame_v3.py": "src/frames/_timing_core.py",
    "phase_b_template_matching_v5_1.py": "src/measurement/_gap_core.py",
}

SAFE_IMPORT = "from src.common.image_io import safe_imread"


def rewrite_direct_image_reads(source: str, *, standalone_script: bool = False) -> str:
    """AST-targeted replacement of *actual calls*, never comments/strings.

    When standalone_script=True, add a root-path fallback for running
    ``python scripts/phase_b_....py`` from the project root.
    """
    tree = ast.parse(source)
    calls = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if (
            isinstance(func, ast.Attribute)
            and func.attr == "imread"
            and isinstance(func.value, ast.Name)
            and func.value.id in {"cv", "cv2"}
        ):
            calls.append(func)

    if not calls:
        return source

    # AST columns are UTF-8 byte offsets; edit encoded bytes to support
    # Korean comments/strings before a call on the same line.
    payload = source.encode("utf-8")
    lines = payload.splitlines(keepends=True)
    line_offsets = [0]
    for line in lines:
        line_offsets.append(line_offsets[-1] + len(line))
    substitutions = []
    for func in calls:
        start = line_offsets[func.lineno - 1] + func.col_offset
        end = line_offsets[func.end_lineno - 1] + func.end_col_offset
        substitutions.append((start, end))
    for start, end in sorted(substitutions, reverse=True):
        payload = payload[:start] + b"safe_imread" + payload[end:]
    modified = payload.decode("utf-8")

    if SAFE_IMPORT not in modified:
        parsed = ast.parse(modified)
        # Must follow module docstring and __future__ imports.
        insert_after = 0
        for index, node in enumerate(parsed.body):
            if (
                index == 0
                and isinstance(node, ast.Expr)
                and isinstance(node.value, ast.Constant)
                and isinstance(getattr(node.value, "value", None), str)
            ):
                insert_after = max(insert_after, node.end_lineno)
            if isinstance(node, ast.ImportFrom) and node.module == "__future__":
                insert_after = max(insert_after, node.end_lineno)
        text_lines = modified.splitlines(keepends=True)
        if standalone_script:
            import_text = (
                "try:\n"
                "    from src.common.image_io import safe_imread\n"
                "except ModuleNotFoundError:\n"
                "    # Support running this file directly from scripts/.\n"
                "    import sys as _image_io_sys\n"
                "    from pathlib import Path as _image_io_Path\n"
                "    _image_io_sys.path.insert(0, str(_image_io_Path(__file__).resolve().parents[1]))\n"
                "    from src.common.image_io import safe_imread\n"
            )
        else:
            import_text = SAFE_IMPORT + "\n"
        text_lines.insert(insert_after, import_text)
        modified = "".join(text_lines)

    ast.parse(modified)
    return modified


def _without_cli_entry(source: Path) -> str:
    original = source.read_text(encoding="utf-8-sig")
    parsed = ast.parse(original, filename=str(source))
    lines = original.splitlines(keepends=True)
    remove = set()
    for node in parsed.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == "main":
            remove.update(range(node.lineno - 1, node.end_lineno))
        if isinstance(node, ast.If) and isinstance(node.test, ast.Compare):
            expr = node.test
            if isinstance(expr.left, ast.Name) and expr.left.id == "__name__":
                remove.update(range(node.lineno - 1, node.end_lineno))
    text = "".join(line for i, line in enumerate(lines) if i not in remove)
    ast.parse(text, filename=str(source))
    return text


def install_algorithms(project_root: Path, sync: bool = False) -> list[str]:
    """Install missing modules and update direct imread calls in existing ones.

    Existing locally modified algorithms retain their content unless sync=True.
    Their image-loading calls alone are migrated automatically.
    """
    project_root = Path(project_root)
    installed: list[str] = []
    missing: list[str] = []

    for script_name, module_relative in ALGORITHM_SOURCES.items():
        destination = project_root / module_relative
        script = project_root / "scripts" / script_name

        if destination.is_file() and not sync:
            existing = destination.read_text(encoding="utf-8-sig")
            updated = rewrite_direct_image_reads(existing)
            if updated != existing:
                temp = destination.with_suffix(destination.suffix + ".tmp")
                temp.write_text(updated, encoding="utf-8")
                temp.replace(destination)
                installed.append(f"migrated image reads: {module_relative}")
            continue

        if not script.is_file():
            missing.append(str(script))
            continue

        # Install from verified algorithm source, preserving its other logic.
        content = rewrite_direct_image_reads(_without_cli_entry(script))
        destination.parent.mkdir(parents=True, exist_ok=True)
        temp = destination.with_suffix(destination.suffix + ".tmp")
        temp.write_text(content, encoding="utf-8")
        temp.replace(destination)
        installed.append(f"{script_name} -> {module_relative}")

    absent = [
        str(project_root / dest)
        for dest in ALGORITHM_SOURCES.values()
        if not (project_root / dest).is_file()
    ]
    if absent:
        raise FileNotFoundError(
            "Required algorithm modules are missing. Place verified originals "
            "in scripts/ for initial installation.\nModules:\n  "
            + "\n  ".join(absent)
            + "\nUnresolved scripts:\n  "
            + "\n  ".join(missing)
        )
    return installed
