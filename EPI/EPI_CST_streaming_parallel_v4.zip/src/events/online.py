"""Incremental event dispatch, using unchanged E3 grouping and IN/OUT logic."""
from __future__ import annotations

from collections import deque
import math
import pandas as pd


class OnlineType2Events:
    def __init__(self, *, cst_motion_threshold=-2., type2_peak_min=-8.,
                 type2_peak_max=-2., history_sec=40., check_interval_sec=0.5):
        from . import _event_core as core
        self.core = core
        self.cfg = core.Config(
            blade_name='blade2',
            cst_motion_threshold=cst_motion_threshold,
            cst_type2_peak_min=type2_peak_min,
            cst_type2_peak_max=type2_peak_max,
        )
        self.history = deque()
        self.history_sec = float(history_sec)
        self.check_interval = float(check_interval_sec)
        self.last_check = -1e12
        self.processed_peaks = set()
        self.next_id = 1

    def add(self, row):
        t = float(row['time_sec'])
        self.history.append(row)
        while self.history and t - float(self.history[0]['time_sec']) > self.history_sec:
            self.history.popleft()
        if t - self.last_check < self.check_interval:
            return []
        self.last_check = t
        if len(self.history) < 4:
            return []
        signals = pd.DataFrame(list(self.history))
        signals = signals.sort_values('time_sec').reset_index(drop=True)
        mask = signals['cst_dy'].to_numpy() <= self.cfg.cst_motion_threshold
        groups = self.core.find_boolean_groups(
            signals, mask, max_gap_sec=self.cfg.cst_group_gap_sec,
            min_duration_sec=self.cfg.cst_min_event_sec,
        )
        found = []
        # Full future Blade OUT window must be available before finalizing.
        settle = self.cfg.blade_out_search_sec + self.cfg.cst_group_gap_sec + 0.15
        for group in groups:
            if t < float(group['end_time']) + settle:
                continue
            local = signals.iloc[group['start_idx']:group['end_idx'] + 1]
            peak_row = local.loc[local['cst_dy'].idxmin()]
            peak = float(peak_row['cst_dy'])
            peak_frame = int(peak_row['frame_idx'])
            if peak_frame in self.processed_peaks:
                continue
            if not (self.cfg.cst_type2_peak_min < peak <= self.cfg.cst_type2_peak_max):
                # Not a Type2 peak; safe to mark as decided.
                self.processed_peaks.add(peak_frame)
                continue
            cst = {
                'raw_event_id': peak_frame,
                'cst_start_time': float(group['start_time']),
                'cst_end_time': float(group['end_time']),
                'cst_peak_time': float(peak_row['time_sec']),
                'cst_peak_dy': peak,
                'cst_peak_frame': peak_frame,
                'cst_duration_sec': float(group['duration']),
            }
            # Keep original E3 searches + adaptive quantile thresholds.
            built = self.core.build_type2_events(signals, [cst], self.cfg)
            if built:
                event = built[0]
                event['event_id'] = self.next_id
                event['detected_at_sec'] = t
                self.next_id += 1
                found.append(event)
            self.processed_peaks.add(peak_frame)
        return found
