@echo off
python operate.py ^
  --source "rtsp://USER:PASS@CAMERA_IP/stream" ^
  --output output\operation ^
  --save-intermediates none ^
  --event-workers 1
