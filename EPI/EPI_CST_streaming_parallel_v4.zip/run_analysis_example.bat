@echo off
python analyze.py ^
  --video data\videos\test.mp4 ^
  --output output\analysis_test ^
  --save-intermediates all ^
  --measurement-source original
