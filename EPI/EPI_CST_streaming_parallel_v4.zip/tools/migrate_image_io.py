"""Replace cv2.imread / cv.imread in this project with shared safe_imread.

Run once in the existing project after copying the updated src/ directory:
    python tools/migrate_image_io.py --check
    python tools/migrate_image_io.py

The command visits main.py, src/**/*.py and scripts/**/*.py; it also
creates a backup for each changed legacy scripts/*.py file.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.core_install import rewrite_direct_image_reads


def find_python_sources(root: Path) -> list[Path]:
    paths = []
    if (root / "main.py").is_file():
        paths.append(root / "main.py")
    for folder in ("src", "scripts"):
        path = root / folder
        if path.is_dir():
            paths.extend(path.rglob("*.py"))
    return sorted(set(paths))


def migrate(root: Path, check: bool = False) -> tuple[list[Path], list[str]]:
    changed = []
    errors = []
    root = root.resolve()
    legacy = root / "scripts"

    for path in find_python_sources(root):
        try:
            original = path.read_text(encoding="utf-8-sig")
            standalone = path.is_relative_to(legacy)
            updated = rewrite_direct_image_reads(
                original, standalone_script=standalone
            )
            if updated == original:
                continue
            changed.append(path)
            if check:
                print(f"[WOULD UPDATE] {path.relative_to(root)}")
                continue
            if standalone:
                backup = path.with_suffix(path.suffix + ".before_safe_imread.bak")
                if not backup.exists():
                    backup.write_bytes(path.read_bytes())
            temp = path.with_suffix(path.suffix + ".safe_imread.tmp")
            temp.write_text(updated, encoding="utf-8")
            temp.replace(path)
            print(f"[UPDATED] {path.relative_to(root)}")
        except (OSError, ValueError, SyntaxError) as exc:
            errors.append(f"{path}: {type(exc).__name__}: {exc}")
            print(f"[ERROR] {errors[-1]}")

    print(f"\nScanned: {len(find_python_sources(root))} Python files")
    print(f"{'Pending' if check else 'Updated'}: {len(changed)}")
    print(f"Errors: {len(errors)}")
    return changed, errors


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--check", action="store_true", help="Preview only")
    args = parser.parse_args()
    _, errors = migrate(args.root, args.check)
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
