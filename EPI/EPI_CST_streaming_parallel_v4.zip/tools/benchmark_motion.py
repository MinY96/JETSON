"""Measure standalone CST + blade2 motion throughput (no clip encoding)."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import time

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.core_install import install_algorithms
from src.roi_config import resolve_rois


def main():
    p = argparse.ArgumentParser(description='Benchmark single-blade CST motion signal extraction')
    p.add_argument('--video', required=True, type=Path)
    p.add_argument('--roi-file', type=Path, default=Path('roi.txt'))
    p.add_argument('--frames', type=int, default=600)
    p.add_argument('--warmup-frames', type=int, default=30)
    p.add_argument('--analysis-width', type=int, default=480)
    p.add_argument('--opencv-threads', type=int, default=2)
    p.add_argument('--output-json', type=Path, default=None)
    args = p.parse_args()
    if not args.video.is_file():
        p.error(f'Video missing: {args.video}')
    cv2.setNumThreads(max(1, args.opencv_threads))
    install_algorithms(ROOT)
    from src.motion.realtime import SingleBladeMotion
    roi = resolve_rois(args.roi_file)
    motion = SingleBladeMotion(roi['cst_motion_roi'], roi['blade_motion_primary_roi'], args.analysis_width)
    cap = cv2.VideoCapture(str(args.video))
    if not cap.isOpened():
        raise RuntimeError(f'Cannot open video {args.video}')
    fps = float(cap.get(cv2.CAP_PROP_FPS))
    max_frames = max(2, args.frames + max(0, args.warmup_frames))
    loop_start = time.perf_counter()
    motion_times = []
    decode_times = []
    count = 0
    try:
        while count < max_frames:
            t0 = time.perf_counter()
            ok, frame = cap.read()
            t1 = time.perf_counter()
            if not ok or frame is None:
                break
            motion.process(frame, count, count / fps if fps > 0 else float(count))
            t2 = time.perf_counter()
            if count >= args.warmup_frames:
                decode_times.append(t1 - t0)
                motion_times.append(t2 - t1)
            count += 1
    finally:
        cap.release()
    total_sec = time.perf_counter() - loop_start
    if not motion_times:
        raise RuntimeError('Not enough frames for benchmark')
    motion_times = np.asarray(motion_times)
    decode_times = np.asarray(decode_times)
    analyzed = len(motion_times)
    report = {
        'video': str(args.video), 'video_fps': fps,
        'total_frames_read': count, 'measured_frames': analyzed,
        'motion_compute_fps': round(analyzed / motion_times.sum(), 2),
        'decode_compute_fps': round(analyzed / decode_times.sum(), 2),
        'motion_p50_ms': round(float(np.percentile(motion_times, 50) * 1e3), 3),
        'motion_p95_ms': round(float(np.percentile(motion_times, 95) * 1e3), 3),
        'decode_p95_ms': round(float(np.percentile(decode_times, 95) * 1e3), 3),
        'benchmark_wall_fps_including_warmup': round(count / total_sec, 2),
        'roi': {'cst': roi['cst_motion_roi'], 'blade2': roi['blade_motion_primary_roi']},
        'analysis_width': args.analysis_width,
        'opencv_threads': args.opencv_threads,
        'note': 'Video decoding + motion only; no RTSP network, clips, JPEG archive, A2/A3/B jobs.',
    }
    print(json.dumps(report, indent=2, ensure_ascii=False))
    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')


if __name__ == '__main__':
    main()
