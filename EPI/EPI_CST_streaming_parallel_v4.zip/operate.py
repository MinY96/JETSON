"""CCTV / RTSP monitoring process using the shared decision engine."""
import sys
from main import main

if __name__ == '__main__':
    main(['--mode', 'operation', *sys.argv[1:]])
