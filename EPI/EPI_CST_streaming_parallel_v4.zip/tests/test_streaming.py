"""Portable smoke tests that do not claim production CV accuracy."""
from __future__ import annotations
import sys
from pathlib import Path
import tempfile
import shutil
import subprocess
import json

import cv2
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.events.online import OnlineType2Events
from src.roi_config import load_roi_txt
from src.core_install import rewrite_direct_image_reads
from src.streaming.archive import RollingArchive


CORES={
'phase_e1_01_extract_motion_signals_v2.py': '''
from dataclasses import dataclass
import numpy as np
@dataclass
class Config:
 blade_analysis_width:int=480
 frame_step:int=1
 cst_blur_ksize:int=5
 blade_diff_pixel_threshold:int=12
def prepare_cst(frame,roi,blur):return frame[:2,:2,0].astype(np.float32)
def prepare_blade(frame,roi,width):return frame[:2,:2,1].astype(np.uint8)
def format_video_time(t):return str(t)
def calculate_phase_shift(prev,cur):
 v=int(cur[0,0]);return 0.0,(-5.0 if v in (10,11) else 0.),1.0
def calculate_frame_difference(prev,cur,th):return .2,.2
''',
'phase_e3_03_extract_clips.py': '''
from dataclasses import dataclass
import numpy as np
@dataclass
class Config:
 blade_name:str='blade2'
 cst_motion_threshold:float=-2
 cst_type2_peak_min:float=-8
 cst_type2_peak_max:float=-2
 cst_group_gap_sec:float=.40
 cst_min_event_sec:float=.03
 blade_out_search_sec:float=3.0
 blade_group_gap_sec:float=.20

def find_boolean_groups(df,mask,max_gap_sec,min_duration_sec):
 indices=np.where(mask)[0]
 if not len(indices):return []
 groups=[]; current=[indices[0]]
 for i in indices[1:]:
  if df.iloc[i]['time_sec']-df.iloc[current[-1]]['time_sec']<=max_gap_sec:current.append(i)
  else:groups.append(current);current=[i]
 groups.append(current)
 return [{'start_idx':g[0],'end_idx':g[-1],
          'start_time':float(df.iloc[g[0]]['time_sec']),
          'end_time':float(df.iloc[g[-1]]['time_sec']),
          'duration':float(df.iloc[g[-1]]['time_sec']-df.iloc[g[0]]['time_sec'])} 
         for g in groups if len(g)>=2]
def build_type2_events(df,events,cfg):
 return [dict(event_id=1,cst_peak_sec=x['cst_peak_time'],cst_peak_dy=x['cst_peak_dy'],
              clip_start_sec=max(0,x['cst_start_time']-.5),clip_end_sec=x['cst_end_time']+1.5)
         for x in events]
''',
'phase_a1_select_measurement_frame_v2.py': '''
from dataclasses import dataclass
import pandas as pd
@dataclass
class Config:
 cst_roi:tuple=(0,0,1,1)
 blade_roi:tuple=(0,0,1,1)
 save_debug_csv:bool=True
 save_comparison:bool=False
 save_debug_video:bool=False
 blade_diff_threshold:int=15
 inner_margin_ratio:float=.03
def preprocess_cst(frame,cfg):return frame[:8,:8,0].astype('float32')
def preprocess_blade(frame,cfg):return frame[:8,:8,1]
def detect_cst_peak(df,cfg):return {'frame_idx':5,'time_sec':5/15,'dy':-5}
def masked_image_difference(ref,image,threshold,margin):
 return {'change_ratio':.1,'change_energy':.1}
def detect_blade_out(blade_df,peak_idx,fps,cfg):
 return {'frame_idx':7,'change_ratio':.1,'temporal_ratio':.1,'growth':.1},.5
def choose_measurement_frame(out_start,peak,cfg):return 6
def save_comparison_image(*args,**kwargs):pass
''',
'phase_a1_select_measurement_frame_v3.py': '''
from dataclasses import dataclass
import cv2
@dataclass
class Config:
 valley_threshold:float=.06
 rise_threshold:float=.075
 rise_delta:float=.055
 measurement_lead_frames:int=1
def analyze_one_clip(csv_path,clips_dir,output_dir,cfg,old_result=None):
 cap=cv2.VideoCapture(str(clips_dir/(csv_path.stem.replace('_debug','')+'.mp4')))
 cap.set(cv2.CAP_PROP_POS_FRAMES,4);ok,im=cap.read();cap.release()
 if not ok:raise RuntimeError('Clip read error')
 dest=output_dir/'measurement_frames';dest.mkdir(parents=True,exist_ok=True)
 image_path=dest/(csv_path.stem.replace('_debug','')+'_measurement.jpg')
 cv2.imwrite(str(image_path),im)
 return {'status':'ok','measurement_frame_idx':4,'measurement_image':str(image_path),'measurement_sec':4/15}
''',
'phase_b_template_matching_v5_1.py': '''
from dataclasses import dataclass
@dataclass
class Config:
 search_roi:tuple=(0,0,200,100)
 measure_roi:tuple=(0,0,200,100)
 normal_x_ratio:float=.7
 dark_x_ratio:float=.7
 detail_scale:float=2.
 jpeg_quality:int=98
def load_references(bright,dark,cfg):return {}
def analyze_image(img,refs,cfg):return {'status':'ok','top_gap_px':19.,'bottom_gap_px':28.}, {}
def flatten_result(filename,result):return {'image':filename,'gap_diff_px':9.,'top_bottom_ratio_10':'4:6',**result}
def draw_overlay(img,result,debug,cfg):return img.copy()
def create_detail(img,result,debug,cfg):return img.copy()
def save_debug(debug_dir,stem,debug,result):pass
'''
}


def test_single_roi_and_legacy_config():
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/'roi.txt'
        p.write_text('cst_roi=(2039,110,149,654)\nblade1_roi=(16,267,621,360)\n'
                     'blade2_roi=(309,379,1593,236)\nblade3_roi=(74,300,1109,302)\n',encoding='utf-8')
        r=load_roi_txt(p)
        assert 'blade_motion_candidate_1_roi' not in r
        assert r['blade_motion_primary_roi']==(309,379,1593,236)


def test_image_read_rewrite():
    s='import cv2\nx = cv2.imread("abc.png")\n'
    assert 'safe_imread(' in rewrite_direct_image_reads(s)


def test_archive_bounds():
    a=RollingArchive(seconds=20,max_mb=10)
    img=np.zeros((32,32,3),dtype=np.uint8)
    for i in range(8):a.put(i,i/15,img)
    snap=a.snapshot(0,7/15,15,0)
    assert len(snap)==8
    a.close()


def test_end_to_end_mock():
    with tempfile.TemporaryDirectory() as d:
        root=Path(d)
        (root/'scripts').mkdir()
        for filename,source in CORES.items():
            (root/'scripts'/filename).write_text(source,encoding='utf-8')
        shutil.copytree(ROOT/'src',root/'src',ignore=shutil.ignore_patterns('__pycache__','_signal_core.py','_event_core.py','_departure_core.py','_timing_core.py','_gap_core.py'))
        shutil.copy(ROOT/'main.py',root/'main.py')
        (root/'reference').mkdir()
        for n in ('blade_left_bright.png','blade_left_dark.png'):
            cv2.imwrite(str(root/'reference'/n),np.zeros((8,8,3),np.uint8))
        (root/'data').mkdir()
        video=root/'data/test.mp4'
        wr=cv2.VideoWriter(str(video),cv2.VideoWriter_fourcc(*'mp4v'),15,(320,240))
        for i in range(95):
            image=np.zeros((240,320,3),dtype=np.uint8)
            image[:,:,0]=i
            wr.write(image)
        wr.release()
        # Mock signal core detects event in the short clip near idx 10,11.
        for save in ('none','all'):
            cmd=[sys.executable,'main.py','--video','data/test.mp4',
                '--output','output/'+save,'--save-intermediates',save]
            p=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=90)
            assert p.returncode==0, p.stdout+'\n'+p.stderr
            out=root/'output'/save
            results=pd.read_csv(out/'integrated_results.csv')
            assert len(results)==1, p.stdout
            assert float(results.iloc[0]['top_gap_px'])==19, (results.to_string(),p.stdout,p.stderr)
            folder=out/results.iloc[0]['event_folder']
            for fn in ('result.json','result.csv','clip_original.mp4',
                       'clip_overlay.mp4','measurement_frame.jpg','overlay.jpg','detail.jpg'):
                assert (folder/fn).is_file(),(fn,p.stdout)
            report=json.loads((folder/'result.json').read_text())
            assert report['quality_decision']['ok_ng'] is None
            assert (folder/'intermediate').exists() == (save=='all')
            print('[SMOKE]',save,results.iloc[0]['status'])
        # Live operational path: same file replayed at real-time frame rate;
        # bounded JPEG archive feeds A2/A3/B asynchronously.
        cmd=[sys.executable,'main.py','--mode','operation','--source','data/test.mp4',
             '--output','output/live','--capture-queue','150','--archive-queue','150',
             '--archive-jpeg-quality','95']
        p=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=90)
        assert p.returncode == 0, p.stdout+'\n'+p.stderr
        live_result=pd.read_csv(root/'output/live/integrated_results.csv')
        assert len(live_result)==1, p.stdout
        assert live_result.iloc[0]['status']=='ok', p.stdout
        live_folder=root/'output/live'/live_result.iloc[0]['event_folder']
        assert (live_folder/'clip_original.mp4').is_file()
        assert (live_folder/'clip_overlay.mp4').is_file()
        print('[SMOKE] operation:',live_result.iloc[0]['status'])


if __name__=='__main__':
    test_single_roi_and_legacy_config()
    test_image_read_rewrite()
    test_archive_bounds()
    test_end_to_end_mock()
    print('ALL MOCK TESTS PASS')
