# EPI CCTV Type2 — Streaming Blade/Wafer Gap Monitor (v4)

본 코드는 `scripts`에 보관된 검증된 Type2 검출(E-3), Blade OUT 측정시점 선정(A-v2/v3), Blade/Wafer gap 측정(B-v5.1) 함수를 재사용합니다. 기존 Batch 전체 단계 실행 대신 **프레임 도착 순서대로 신호를 추출**하고 **Type2 이벤트가 확정될 때마다 워커에게 비동기 작업을 전달**합니다.

## 설치 / 기존 프로젝트에 병합

이 ZIP의 `main.py`, `analyze.py`, `operate.py`, `roi.txt`, `src/`, `tests/`를 프로젝트 루트에 병합합니다. **기존 `scripts/` 원본 5개는 그대로 유지**하세요. 최초 실행 시 `src/core_install.py`가 해당 원본의 CLI `main()`을 제외하고 `_core.py` 파일로 이관합니다. 이후 E-3, A-v2/v3, B-v5.1은 **별도 Python subprocess 없이 함수 호출**로 동작합니다.

필수 패키지: `numpy`, `pandas`, `cv2`(OpenCV). Windows 개발 환경은 `pip install -r requirements_dev.txt`를 사용할 수 있습니다. **Jetson에서는 GStreamer 지원 OpenCV를 별도 설치한 상태를 우선 사용하세요.** 일반 `opencv-python` 휠을 덮어쓰면 하드웨어 디코딩 경로가 사라질 수 있습니다. Python 3.10 이상 권장.

원본 스크립트 파일명:

```
scripts/phase_e1_01_extract_motion_signals_v2.py
scripts/phase_e3_03_extract_clips.py
scripts/phase_a1_select_measurement_frame_v2.py
scripts/phase_a1_select_measurement_frame_v3.py
scripts/phase_b_template_matching_v5_1.py
```

`src/motion/realtime.py`는 E1 원본의 `prepare_cst`, `prepare_blade`, `calculate_phase_shift`, `calculate_frame_difference` 함수만 사용하며 `blade1`, `blade3`, Farneback Optical Flow는 **호출하지 않습니다.** 최종 Type2 검출에서 쓰는 신호는 원본과 동일한 `blade2_motion_ratio`, `cst_dy`입니다.

## 명령어

**분석용 (MP4, 입력 프레임 유실 없음 / 백프레셔):**

```bat
python analyze.py ^
  --video data\videos\test.mp4 ^
  --output output\analysis_001 ^
  --save-intermediates all ^
  --event-workers 1 ^
  --measurement-source original
```

**운영용 (RTSP):**

```bat
python operate.py ^
  --source "rtsp://USER:PASS@CAMERA_IP/stream" ^
  --output output\operation ^
  --save-intermediates none ^
  --event-workers 1 ^
  --capture-queue 12 ^
  --archive-queue 24 ^
  --archive-seconds 45 ^
  --archive-mb 512
```

**운영 기능을 MP4로 모의 (실시간 재생 속도로 처리 후 종료):**

```bat
python operate.py --source data\videos\test.mp4 --output output\operation_test
```

**하나의 진입점 사용:**

```bat
python main.py --mode analysis --video data\videos\test.mp4
python main.py --mode operation --source 0
```

**설정 확인:**

```bat
python main.py --video data\videos\test.mp4 --dry-run
```

## 시퀀스

```
                          ┌─ JPEG 원형 링 버퍼 (운영 모드만)
CCTV/MP4 → 캡처 스레드 ────┤
                          └─ bounded motion 큐 → 1개 모션 분석 스레드
                                                   │
                          CST shift + blade2 frame difference
                                                   │
                               E-3 Type2 그룹 및 Blade IN/OUT 확인
                                                   │
                                        이벤트 워커 큐 (동시 N개)
                                                   │
                     Clip → A2/A3 측정시점 → B Gap → 출력 7개 파일
```

- E-3의 이벤트 그룹 조건(`cst_dy` 피크 -8..-2, 그룹 시간 간격)과 Blade IN/OUT 경계 검출 함수는 검증된 원본에서 재사용합니다.
- E-3은 **Blade OUT 탐색 구간이 끝난 뒤** 이벤트를 확정하므로 측정 결과는 영상 시각보다 수초 늦게 생성됩니다. 그동안 캡처/모션 분석은 계속 진행됩니다.
- A2 → A3는 현재 원본에서 Debug CSV를 매개로 사용합니다. A2는 단순 영상 전체를 RAM에 보관하던 `read_video_frames` 대신 `src/frames/departure_fast.py`에서 작은 ROI 전처리 프레임만 보관하도록 변경했습니다. A2의 `detect_cst_peak`, `masked_image_difference`, `detect_blade_out`, `choose_measurement_frame` 계산 함수는 검증된 원본을 호출합니다. 실제 영상 기준으로 결과 동등성 검증이 필요합니다. `none` 모드에서는 이벤트 작업용 임시 디렉터리를 사용하고 완료 후 삭제합니다.
- A3가 선정한 프레임 인덱스는 기존과 같으며, 최종 B 이미지 품질을 위해 `--measurement-source original`(기본)은 가능한 한 원본 MP4 프레임 / 운영 모드의 JPEG 링 버퍼 프레임을 직접 읽습니다. 과거 A3 JPEG 기준 Gap 결과와 직접 비교하려면 `--measurement-source selected`로 실행하세요.
- Clip은 `mp4v`로 다시 인코딩되며 **압축 전 원본 바이트와 동일하지 않습니다.** 운영 모드 원형 버퍼도 JPEG 압축 보관입니다.

## 출력 (이벤트별 폴더)

```
output/cst_monitoring/
├── integrated_results.csv      # 이벤트별 판정 행, 이벤트 완료 시 갱신
├── runtime_metrics.json        # FPS, 처리량, 유실 프레임, 큐 크기
├── summary.json
└── events/
    └── 20261012_151403_392811_e0001/
        ├── clip_original.mp4   # 측정 표시 없는 클립
        ├── clip_overlay.mp4    # 이벤트 ID + 측정프레임 인접 구간만 Gap Overlay
        ├── measurement_frame.jpg
        ├── overlay.jpg         # 전체 프레임, 우측 정보창 없음
        ├── detail.jpg          # ROI 원본 확대 후 재렌더링 + 우측 정보창
        ├── result.csv
        ├── result.json         # 향후 OK/NG 규칙 적용용 구조
        └── intermediate/       # --save-intermediates all 인 경우
```

JSON `quality_decision`은 아직 판정 기준이 없으므로 `status=NOT_EVALUATED`, `ok_ng=null`입니다. Gap / 차이 / Top:Bottom 비율은 계측 성공 시 채워집니다. `result.json`의 `judged_at`은 실제 처리 완료 시각입니다. 폴더명은 **측정 작업 종료/판정 시각**이며 `result.json.judged_at`과 같은 시각을 사용합니다.

## 실시간 성능 및 안전한 운영 범위

1. **세 ROI의 Optical Flow 제거**가 핵심 속도 개선입니다. Type2 판정에 사용되는 2개 신호(`cst_dy`, `blade2_motion_ratio`)의 정의는 변경하지 않았습니다.
2. `cv2.setNumThreads(--opencv-threads)`로 OpenCV 내부 과다 스레딩을 제한합니다. Jetson 보드 종류와 CPU 부하에 따라 1, 2, 4를 비교하세요.
3. RTSP 캡처는 모션 분석 및 이벤트 저장과 별도 스레드입니다. 분석이 수집 FPS보다 낮으면 운영 모드는 **최신 프레임 우선**으로 오래된 프레임을 버리고 `dropped_motion_frames`, `motion_input_gaps`를 기록합니다. **프레임 유실 없는 감지를 보장하지 않습니다.** 이벤트 근처 유실 여부는 `result.json.data_quality.motion_frame_loss_near_event`에 남습니다.
4. 원본 영상을 처리하는 분석 모드는 `queue.put` 역압력을 사용하므로 입력 프레임을 누락하지 않습니다. 단, FPS보다 느리면 완료 시간은 영상 길이보다 길어질 수 있습니다.
5. 운영 모드의 JPEG 링 버퍼는 메모리/시간 상한이 있습니다. 아카이브가 지연되거나 보관량이 부족하면 **오류로 기록**하고 누락된 클립을 정상이라고 주장하지 않습니다. 이 경우 디스크 상시녹화(GStreamer/FFmpeg `-c copy`)를 추가하는 것이 프로덕션에서 더 안전합니다.
6. `runtime_metrics.json`의 `motion_capacity_fps`는 모션 계산에 실제 쓴 CPU 처리시간의 역수, `analysis_fps_average`는 캡처 대기와 이벤트 처리까지 포함한 평균입니다. `motion_capacity_fps >= camera_fps`와 dropped=0을 장시간 검증해야 합니다.
7. GStreamer 파이프라인 문자열에 `appsink`가 포함된 경우 OpenCV의 `CAP_GSTREAMER`를 시도합니다. Jetson 하드웨어 디코딩을 사용하려면 OpenCV가 GStreamer 지원으로 빌드되어 있어야 하고, 카메라 코덱에 맞는 파이프라인 설정이 필요합니다.

현재 자료에는 실제 RTSP 스트림 및 최종 측정 GT가 없어 **30 FPS 안정적 동작이나 기존 25/25 검출 재현을 검증하지 못했습니다.** 먼저 동일 MP4에서 Type2 개수, A3 측정 프레임 인덱스, B Gap, 입력 유실률을 비교하세요.

## 테스트

```bat
python tests\test_streaming.py
```

모의 E1/E3/A2/A3/B 함수 및 소형 영상으로 파일 모드 `all`/`none`과 실시간 재생 모드의 전체 이벤트 폴더 생성까지 검증합니다. **모의 테스트는 실제 모델 정확도 검증이 아닙니다.**

## 속도 측정과 운영 승인 점검

단일 Blade2만 사용하는 **모션 계산 자체**의 처리량을 측정하려면:

```bat
python tools\benchmark_motion.py ^
  --video data\videos\test.mp4 ^
  --frames 600 ^
  --analysis-width 480 ^
  --opencv-threads 2 ^
  --output-json output\motion_benchmark.json
```

`motion_compute_fps`는 CST/Blade2 신호 처리 시간만 대상으로 하고, `benchmark_wall_fps_including_warmup`은 비디오 디코딩 시간을 포함합니다. 이벤트별 클립 인코딩, 영상 아카이브, 네트워크 지연은 포함하지 않으므로 **RTSP 운영 속도를 보장하는 수치는 아닙니다.** `--opencv-threads` 1/2/4와 `--analysis-width` 480(기준)/320(시험)을 각각 검증하되, 너비를 변경하면 기존 신호 threshold의 유효성을 재검증하세요.

`runtime_metrics.json`의 `source_fps`, `motion_capacity_fps`, `motion_capacity_above_source_fps`, `dropped_motion_frames`, `dropped_archive_frames`, `motion_input_gaps`, `max_motion_queue`를 장시간 살펴보세요. `motion_capacity_fps`가 카메라 FPS 이하이면 오래된 프레임 폐기 때문에 이벤트 누락 가능성이 있습니다. 프레임 누락이 0이더라도 네트워크/카메라 측의 전송 유실은 OpenCV 프레임 ID만으로 확정할 수 없습니다. 현장에서는 하드웨어 디코딩과 실제 네트워크 재접속을 별도로 검증해야 합니다.

동일한 `--output` 디렉터리로 재실행하면 이전 `integrated_results.csv` 행을 유지하고 새로운 분석 세션의 이벤트 결과를 덧붙입니다. `session_id`가 세션을 구분하며, `summary.json`과 `runtime_metrics.json`은 가장 최근 세션 기준으로 갱신됩니다.

### 추론/판정이 분리된 이유

현재 OK/NG 규칙 및 허용 Gap Spec이 정의되지 않았으므로 `result.json`은 기하학적 측정값만 기록합니다. 품질 라벨은 항상 `quality_decision.status=NOT_EVALUATED`, `ok_ng=null`입니다. `status=ok`는 **영상 처리 및 두 Gap 측정 성공**을 뜻하지 제품 OK 판정을 의미하지 않습니다.

### 메모리 주의

기존 측정 프레임 선택 알고리즘(A-v2)은 각 이벤트 클립의 프레임을 메모리에 전부 로드합니다. 예를 들어 2048×1152 BGR 이미지는 1장 약 7.1 MB이며, 10초×15 FPS 클립이면 원본 프레임 배열만 1 GB 이상일 수 있습니다. 운영 환경에서는 우선 `--event-workers 1`로 시작하고, RAM/CPU/저장장치 부하를 실제 영상으로 측정하세요. 이벤트가 자주 겹치거나 하드웨어 자원이 빠듯한 경우, 후속 개선으로 A-v2/A-v3를 인메모리 ROI 시그널 분석으로 바꾸고 클립을 원본 CCTV의 H.264/H.265 하드웨어 녹화로 분리하는 것이 좋습니다.
