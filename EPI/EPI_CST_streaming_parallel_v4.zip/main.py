"""Entry point for offline analysis or continuous CCTV Type2 monitoring."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from src.roi_config import DEFAULT_ROIS
from src.streaming.engine import StreamOptions, StreamAnalyzer

ROOT = Path(__file__).resolve().parent


def rooted(text):
    if text is None:
        return None
    path = Path(text)
    return path if path.is_absolute() else ROOT / path


def build_parser():
    p = argparse.ArgumentParser(description='CST Type2 Blade/Wafer streaming gap monitoring')
    p.add_argument('--mode', choices=('analysis', 'operation'), default='analysis')
    p.add_argument('--video', default=None, help='Offline file input (analysis mode)')
    p.add_argument('--source', default=None, help='RTSP URL, GStreamer pipeline, or camera index (operation mode)')
    p.add_argument('--output', default='output/cst_monitoring')
    p.add_argument('--roi-file', default='roi.txt')
    p.add_argument('--reference-bright', default='reference/blade_left_bright.png')
    p.add_argument('--reference-dark', default='reference/blade_left_dark.png')
    p.add_argument('--save-intermediates', choices=('none', 'all'), default='none')
    p.add_argument('--sync-algorithms', action='store_true')
    p.add_argument('--dry-run', action='store_true')
    p.add_argument('--analysis-width', type=int, default=480)
    p.add_argument('--detail-scale', type=float, default=2.)
    p.add_argument('--measurement-source', choices=('original', 'selected'), default='original')
    p.add_argument('--jpeg-quality', type=int, default=98)
    p.add_argument('--normal-x-ratio', type=float, default=0.7)
    p.add_argument('--dark-x-ratio', type=float, default=0.7)
    p.add_argument('--cst-motion-threshold', type=float, default=-2.)
    p.add_argument('--type2-peak-min', type=float, default=-8.)
    p.add_argument('--type2-peak-max', type=float, default=-2.)
    p.add_argument('--valley-threshold', type=float, default=0.06)
    p.add_argument('--rise-threshold', type=float, default=0.075)
    p.add_argument('--rise-delta', type=float, default=0.055)
    p.add_argument('--lead-frames', type=int, default=1)
    p.add_argument('--event-workers', type=int, default=1)
    p.add_argument('--pending-events', type=int, default=4)
    p.add_argument('--opencv-threads', type=int, default=2)
    p.add_argument('--capture-queue', type=int, default=12)
    p.add_argument('--archive-queue', type=int, default=24)
    p.add_argument('--archive-seconds', type=float, default=45.)
    p.add_argument('--archive-mb', type=float, default=512.)
    p.add_argument('--archive-jpeg-quality', type=int, default=90)
    p.add_argument('--archive-wait-sec', type=float, default=20.)
    p.add_argument('--fallback-fps', type=float, default=15.)
    p.add_argument('--max-frames', type=int, default=0)
    p.add_argument('--max-seconds', type=float, default=0.)
    p.add_argument('--reconnect-delay', type=float, default=2.)
    p.add_argument('--reconnect-attempts', type=int, default=10)
    for key in DEFAULT_ROIS:
        p.add_argument('--' + key.replace('_', '-'), type=int, nargs=4, default=None)
    return p


def main(argv=None):
    p = build_parser()
    args = p.parse_args(argv)
    if args.mode == 'analysis' and not args.video:
        p.error('--video is required for analysis mode')
    if args.mode == 'operation' and args.source is None:
        p.error('--source is required for operation mode')
    options = StreamOptions(
        project_root=ROOT,
        video=rooted(args.video) if args.mode == 'analysis' else None,
        live_source=args.source if args.mode == 'operation' else None,
        output=rooted(args.output),
        bright_reference=rooted(args.reference_bright),
        dark_reference=rooted(args.reference_dark),
        roi_file=rooted(args.roi_file),
        roi_overrides={k: getattr(args, k) for k in DEFAULT_ROIS},
        save_intermediates=args.save_intermediates,
        sync_algorithms=args.sync_algorithms,
        dry_run=args.dry_run,
        analysis_width=args.analysis_width,
        detail_scale=args.detail_scale,
        measurement_source=args.measurement_source,
        jpeg_quality=args.jpeg_quality,
        normal_x_ratio=args.normal_x_ratio,
        dark_x_ratio=args.dark_x_ratio,
        cst_motion_threshold=args.cst_motion_threshold,
        type2_peak_min=args.type2_peak_min,
        type2_peak_max=args.type2_peak_max,
        valley_threshold=args.valley_threshold,
        rise_threshold=args.rise_threshold,
        rise_delta=args.rise_delta,
        lead_frames=args.lead_frames,
        event_workers=args.event_workers,
        pending_events=args.pending_events,
        opencv_threads=args.opencv_threads,
        capture_queue=args.capture_queue,
        archive_queue=args.archive_queue,
        archive_seconds=args.archive_seconds,
        archive_mb=args.archive_mb,
        archive_jpeg_quality=args.archive_jpeg_quality,
        archive_wait_sec=args.archive_wait_sec,
        fallback_fps=args.fallback_fps,
        max_frames=args.max_frames,
        max_seconds=args.max_seconds,
        reconnect_delay=args.reconnect_delay,
        reconnect_attempts=args.reconnect_attempts,
    )
    result = StreamAnalyzer(options).run()
    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    return result


if __name__ == '__main__':
    main()
