-- APPLY ONCE BEFORE RUNNING THE NEW CODE.
-- This is a NON-DESTRUCTIVE migration built from repository usage.
-- The user-mentioned original DB creation SQL was not available in this session.
-- Run in the target schema using the correct PostgreSQL search_path.
BEGIN;
ALTER TABLE dm_recipe_info ADD COLUMN IF NOT EXISTS parse_status VARCHAR(20);
ALTER TABLE dm_recipe_info ADD COLUMN IF NOT EXISTS parse_error TEXT;
UPDATE dm_recipe_info
   SET parse_status = 'pending'
 WHERE parse_status IS NULL AND is_remove = false AND status IN ('new','update');
CREATE INDEX IF NOT EXISTS idx_dm_recipe_info_equip_parse_status
    ON dm_recipe_info(equip, parse_status, recipe_key)
    WHERE is_remove = false;
COMMIT;
