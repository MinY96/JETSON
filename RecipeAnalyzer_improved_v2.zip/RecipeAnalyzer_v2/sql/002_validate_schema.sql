-- Read-only schema/constraint verification before first run.
SELECT table_schema, table_name, column_name, data_type
FROM information_schema.columns
WHERE table_schema = current_schema()
 AND table_name IN ('dm_recipe_info','dm_recipe_para','dm_update_history')
ORDER BY table_name, ordinal_position;
SELECT conrelid::regclass::text AS table_name, conname, pg_get_constraintdef(oid)
FROM pg_constraint
WHERE conrelid IN ('dm_recipe_info'::regclass, 'dm_recipe_para'::regclass,
                  'dm_update_history'::regclass)
ORDER BY table_name, conname;
