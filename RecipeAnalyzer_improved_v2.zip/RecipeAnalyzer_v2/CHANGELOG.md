# RecipeAnalyzer 변경내역 (운영 안정화 1~6)

- 999건 UPSERT chunk 유지. 실패 시 buffer 보존. 최대 chunk 범위 검증.
- FTP NLST 대신 Unix LIST 사용, 디렉터리 명 누락 대비. 부정확한 응답이면 예외.
- 필수 Recipe 파일을 별도 staging으로 다운로드, 오류 시 기존 Recipe 보존.
- FTP 전체 탐색 실패, 빈 탐색, 다운로드 오류, 위험한 대량 제거 비율이면 삭제/집계 차단.
- 기존 Recipe DB 조회를 pandas 반복 필터링에서 dict lookup으로 변경.
- 문자열 dt_edit_time 유지, lexicographic timestamp comparison.
- 새 Recipe/변경 Recipe UPSERT 시 parse_status=pending. 삭제된 Recipe 복원 시 is_remove=false 반영.
- 파싱 상태 pending/success/failed 관리. 오류 메시지 기록 및 다음 회차 재시도.
- 파싱 큐를 keyset 기준 PARSE_BATCH_SIZE 행으로 읽고 처리.
- 파라미터 전체 교체 + mode 갱신 + parse 성공 마킹을 단일 트랜잭션 처리.
- 0개 parse 결과 DataFrame KeyError 해결.
- Oracle MES bind 인자 사용, Oracle 900 Device 단위 분할, 중복 MES 정보 검증.
- PostgreSQL 삭제/유지 키는 ANY(%s) 파라미터 바인딩.
- 장비 스캔 최종 삭제/유지 상태 갱신 및 update history 기록 원자적 처리.
- 소스만으로 안전하게 추론 가능한 새 필드에 한정한 비파괴 DB migration 및 사전 검증 SQL 동봉.
- 19개 단위 테스트 통과(내부 DB fake). 실제 운영 연결 검증 필요.
