"""DM Recipe FTP collection followed by recoverable parsing."""
from __future__ import annotations
import logging
import os
from src import create_collector, create_recipe_parser
from src.databases import close_pools


def main() -> None:
    logging.basicConfig(level=getattr(logging, os.getenv('LOG_LEVEL', 'INFO').upper(), logging.INFO),
                        format='%(asctime)s %(levelname)s %(name)s - %(message)s')
    try:
        collector = create_collector()
        parser = create_recipe_parser()
        # Each equipment failure is isolated by Collector and RecipeParser.
        # Parser always runs even if the previous collecting pass failed.
        collector.run()
        parser.run()
    finally:
        close_pools()


if __name__ == '__main__':
    main()
