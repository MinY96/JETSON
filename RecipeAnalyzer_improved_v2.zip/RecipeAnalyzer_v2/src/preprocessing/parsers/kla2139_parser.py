"""KLA2139 ins.dat parser; raises on malformed input rather than swallowing errors."""
from __future__ import annotations
from pathlib import Path
from typing import Any
from src.core.types import SafeList
from src.preprocessing.parsers.parser import Parser


class KLA2139Parser(Parser):
    def parse(self, file_path: Path) -> dict[str, Any]:
        data = None
        # Preserve legacy fallback sequence; latin1 decodes any bytes and is last.
        for encoding in ('utf-8', 'cp949', 'euc-kr', 'latin1'):
            try:
                with file_path.open('r', encoding=encoding) as stream:
                    data = [line.rstrip('\r\n').split('\t') for line in stream]
                break
            except UnicodeDecodeError:
                continue
        if data is None or not data:
            raise ValueError(f'Unparseable or empty KLA2139 file: {file_path}')
        info = self._analyze_recipe_lines(data)
        if not info:
            raise ValueError(f'KLA2139 test[0]. structure missing: {file_path}')

        pixel = self._safe_get_first(info, ['.lens_desc.', '.pixel_size'])
        try:
            pixel = format(float(pixel), '.2f').rstrip('0').rstrip('.')
        except (ValueError, TypeError):
            pixel = None
        focus = self._safe_get_first(info, ['.premap_sites.', '.site[0].', '.focus_offset'])
        threshold = self._safe_get_first(info, ['.sens.', '.ds_thresha'])
        thresh_mode = self._safe_get_first(info, ['.sens.', '.thresh_mode'])
        mode = {'a':'AUTO','s':'SAT','f':'FIXED'}.get(thresh_mode)
        filter_value = self._safe_get_first(info, ['.sens.', '.filter.', '.fdata.', '.name'])
        filter_value = filter_value.upper() if filter_value is not None else None
        th_seg = SafeList(self._numeric_values(self._safe_get(info, ['.sens.', '.sat_convolver_bounds'], [])))
        th_max = SafeList(self._numeric_values(self._safe_get(info, ['.sens.', '.sat_threshold_max'], [])))
        th_offset = SafeList(self._numeric_values(self._safe_get(info, ['.sens.', '.sat_threshold_offset'], [])))
        edge = {'0':'Exclude','5':'Include'}.get(self._safe_get_first(info, ['.splan.', '.edge_cells']))
        result = {'pixel': pixel, 'mode': mode, 'filter': filter_value,
                  'threshold': threshold, 'edge': edge, 'focus_offset': focus}
        for i in range(4):
            result[f'th_max_s{i}'] = th_max[i]
            result[f'th_offset_s{i}'] = th_offset[i]
            result[f'th_offset_r{i}'] = th_seg[i]
        if all(v is None for v in result.values()):
            raise ValueError(f'No recognized KLA2139 parameters: {file_path}')
        return result

    @staticmethod
    def _numeric_values(values: Any) -> list[int]:
        if not isinstance(values, list):
            return []
        return [int(v) if v is not None and str(v).strip() else None for v in values[:4]]

    @staticmethod
    def _safe_get(d: dict, keys: list[str], default=None):
        for key in keys:
            if isinstance(d, dict) and key in d:
                d = d[key]
            else:
                return default
        return d

    def _safe_get_first(self, d: dict, keys: list[str]):
        value = self._safe_get(d, keys, [None])
        return value[0] if isinstance(value, list) and value else None

    @staticmethod
    def _check_line_level(line: list[str]) -> int:
        count = 0
        for token in line:
            if token:
                break
            count += 1
        return count

    def _analyze_recipe_lines(self, lines: list[list[str]]) -> dict:
        root: dict = {}
        path: list[str | None] = [None] * 5
        for line in lines:
            level = self._check_line_level(line)
            if level >= 5 or len(line) <= level:
                continue
            key = line[level]
            path[level] = key
            for depth in range(level + 1, 5):
                path[depth] = None
            if level == 0:
                root[key] = {}
                continue
            if path[0] is None:
                raise ValueError('KLA2139 hierarchy missing root')
            current = root[path[0]]
            for depth in range(1, level):
                parent = path[depth]
                if parent is None:
                    raise ValueError('KLA2139 hierarchy missing parent')
                if not isinstance(current.get(parent), dict):
                    current[parent] = {}
                current = current[parent]
            current[key] = line[level + 1:]
        return root.get('test[0].', {})
