"""Parser contract and validation helpers."""
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

class Parser(ABC):
    name = 'DM Recipe Parser'

    @abstractmethod
    def parse(self, file_path: Path) -> dict[str, Any]:
        """Return extracted parameters or raise on any parse failure."""

    @staticmethod
    def as_list(value: Any) -> list:
        if value is None:
            return []
        return value if isinstance(value, list) else [value]

    @staticmethod
    def leaf(value: Any, default=None):
        if not isinstance(value, dict):
            return default
        val = value.get('value')
        return val if val is not None else default

    @staticmethod
    def four(values: Any) -> list:
        if isinstance(values, str):
            vals = values.split()
        elif isinstance(values, (list, tuple)):
            vals = list(values)
        else:
            vals = []
        return (vals + [None] * 4)[:4]
