"""Legacy FTP compatibility, safe traversal, verified staging downloads."""
from __future__ import annotations
from dataclasses import dataclass
from ftplib import FTP, error_perm
from pathlib import Path, PurePosixPath
import os
import shutil
import uuid


class FTPListingError(RuntimeError):
    """LIST traversal was not complete/reliable."""


class FTPDownloadError(RuntimeError):
    """At least one remote file could not be transferred."""


@dataclass(frozen=True, slots=True)
class FTPEntry:
    name: str
    is_dir: bool
    raw: str


def parse_list_line(line: str) -> FTPEntry | None:
    """Strict Unix LIST parsing; do not silently treat malformed listings as empty."""
    line = line.strip()
    if not line or line.startswith('total '):
        return None
    parts = line.split(maxsplit=8)
    if len(parts) < 9 or not parts[0].startswith(('d', '-', 'l')):
        raise FTPListingError(f'Unsupported FTP LIST response: {line!r}')
    name = parts[8]
    if name in ('.', '..'):
        return None
    if '\x00' in name or '/' in name or '\\' in name or name.startswith('..'):
        raise FTPListingError(f'Unsafe FTP path: {name!r}')
    # Symlink paths are intentionally prohibited to prevent recursive cycles.
    if parts[0][0] == 'l':
        return None
    return FTPEntry(name, parts[0][0] == 'd', line)


def list_entries(ftp: FTP) -> list[FTPEntry]:
    """LIST detects child folders omitted by some legacy FTP NLST servers."""
    lines: list[str] = []
    ftp.retrlines('LIST', lines.append)
    result = []
    for line in lines:
        item = parse_list_line(line)
        if item is not None:
            result.append(item)
    return result


def ftp_download_tree(ftp: FTP, remote_dir: str, local_dir: Path) -> None:
    """Download recursively; exceptions are *never* swallowed."""
    current = ftp.pwd()
    ftp.cwd(remote_dir)
    try:
        entries = list_entries(ftp)
        local_dir.mkdir(parents=True, exist_ok=True)
        for entry in entries:
            target = local_dir / entry.name
            if entry.is_dir:
                ftp_download_tree(ftp, entry.name, target)
            elif not entry.name.endswith('~'):
                part = target.with_name(target.name + '.part')
                try:
                    with part.open('wb') as stream:
                        ftp.retrbinary(f'RETR {entry.name}', stream.write)
                    os.replace(part, target)
                finally:
                    part.unlink(missing_ok=True)
    finally:
        ftp.cwd(current)


def safe_download_recipe(ftp: FTP, recipe: str, dest: Path, required_file: str) -> None:
    """Stage entire recipe, verify required file, swap into place with rollback."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    suffix = uuid.uuid4().hex
    stage = dest.with_name(f'.{dest.name}.staging-{suffix}')
    previous = dest.with_name(f'.{dest.name}.previous-{suffix}')
    try:
        ftp_download_tree(ftp, recipe, stage)
        expected = stage / required_file
        if not expected.is_file() or expected.stat().st_size == 0:
            raise FTPDownloadError(f'Required recipe file missing/empty: {recipe}/{required_file}')
        if dest.exists():
            dest.rename(previous)
        try:
            stage.rename(dest)
        except Exception:
            if previous.exists() and not dest.exists():
                previous.rename(dest)
            raise
        if previous.exists():
            shutil.rmtree(previous)
    finally:
        if stage.exists():
            shutil.rmtree(stage)


def ftp_remove_tree(ftp: FTP, remote_dir: str) -> None:
    """Preserved recursive deletion utility; never called by data collection."""
    current = ftp.pwd()
    ftp.cwd(remote_dir)
    try:
        entries = list_entries(ftp)
        for entry in entries:
            if entry.is_dir:
                ftp_remove_tree(ftp, entry.name)
            else:
                ftp.delete(entry.name)
    finally:
        ftp.cwd(current)
    ftp.rmd(remote_dir)
