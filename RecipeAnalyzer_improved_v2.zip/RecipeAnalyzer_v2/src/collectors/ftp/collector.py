"""DM Recipe FTP equipment scanner with bounded 999-row UPSERT batches."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from ftplib import FTP
from pathlib import Path
from typing import Any
import logging
import os
import re
import pandas as pd
from dateutil.relativedelta import relativedelta
from src.config.config import RECIPE_BATCH_SIZE
from src.domain.entities.equipment import Equipment, create_equipment
from src.collectors.ftp.client import FTPEntry, list_entries, safe_download_recipe
from src.databases import OracleCRUD, PostgresCRUD

log = logging.getLogger(__name__)
UPSERT_BATCH_SIZE = RECIPE_BATCH_SIZE
COLS = ['recipe_key', 'model', 'equip', 'device', 'recipe', 'folder_path',
        'file_path', 'dt_edit_time', 'backup_folder_path', 'backup_file_path',
        'dt_backup', 'status', 'tech_prod', 'tech', 'prod_group', 'level', 'layer',
        'is_remove', 'parse_status', 'parse_error']


def parse_edit_time(line: str) -> str:
    """Preserve legacy datetime *string* representation, YYYY-MM-DD HH:MM."""
    now = datetime.now()
    # Unix FTP: 'Oct 26 14:32' or 'Oct  6 2025' ; no year => current year.
    match = re.search(r'\b([A-Za-z]{3})\s+(\d{1,2})\s+(\d{2}:\d{2}|\d{4})\b', line)
    if match:
        month, day, last = match.groups()
        if ':' in last:
            value = datetime.strptime(f'{now.year} {month} {day} {last}', '%Y %b %d %H:%M')
        else:
            value = datetime.strptime(f'{month} {day} {last}', '%b %d %Y')
    else:
        # Localized Korean LIST variants: 8월 30일 2012년 / 8월 30일 14:32
        localized = re.search(r'(\d{1,2})월\s*(\d{1,2})일\s*(\d{4})년?', line)
        local_clock = re.search(r'(\d{1,2})월\s*(\d{1,2})일\s*(\d{1,2}:\d{2})', line)
        if localized:
            m, d, y = localized.groups()
            value = datetime(int(y), int(m), int(d))
        elif local_clock:
            m, d, clock = local_clock.groups()
            hour, minute = map(int, clock.split(':'))
            value = datetime(now.year, int(m), int(d), hour, minute)
        else:
            # Unknown listing format means we cannot reliably compute changes/deletions.
            raise ValueError(f'Unable to parse FTP date: {line!r}')
    if value > now:
        value -= relativedelta(years=1)
    return value.strftime('%Y-%m-%d %H:%M')


def recipe_filter(name: str) -> bool:
    if name.startswith(('.', '_')) or name.endswith(('~', '.inf', '.DAT')):
        return False
    parts = name.split('_')
    return len(parts) == 2 and len(parts[0]) == 4


def is_recipe(entry: FTPEntry) -> bool:
    return entry.is_dir and recipe_filter(entry.name)


def is_recipe_kla2365(entry: FTPEntry, device: str, layer: str) -> bool:
    if not is_recipe(entry):
        return False
    a, b = entry.name.split('_')
    return a == device and b.endswith(layer)


def is_device(entry: FTPEntry) -> bool:
    return entry.is_dir and len(entry.name) == 4 and not entry.name.startswith(('.', '_'))


def is_layer(entry: FTPEntry) -> bool:
    return is_device(entry)


def build_equipment_lookup(equip_db: pd.DataFrame) -> dict[str, dict]:
    """O(N) one-time build; O(1) average Recipe key lookups thereafter."""
    if equip_db.empty:
        return {}
    return equip_db.set_index('recipe_key').to_dict(orient='index')


def is_file_update(equip_lookup: dict[str, dict], rcp_key: str,
                   edit_time: str, backup_file_path: Path) -> tuple[bool, str | None]:
    """dt_edit_time is str on BOTH sides. No pandas Timestamp conversion."""
    info = equip_lookup.get(rcp_key)
    if info is None:
        return True, 'new'
    if not backup_file_path.is_file():
        return True, 'update'
    return (True, 'update') if edit_time > info['dt_edit_time'] else (False, None)


def join_mes_info(upserts: list[dict[str, Any]]) -> pd.DataFrame:
    """Bound Oracle queries and unambiguous single row per device MES merge."""
    if not upserts:
        return pd.DataFrame(columns=COLS)
    frame = pd.DataFrame.from_records(upserts)
    devices = list(dict.fromkeys(frame['device'].tolist()))
    matches: dict[str, set[tuple]] = {device: set() for device in devices}
    for offset in range(0, len(devices), 900):
        chunk = devices[offset:offset + 900]
        binds = {f'd{i}': device for i, device in enumerate(chunk)}
        holders = ','.join(f':d{i}' for i in range(len(chunk)))
        query = f'''SELECT DISTINCT MAT_ID product, MAT_CMF_21 device,
                    MAT_CMF_5 device_name, MAT_CMF_6 tech_prod,
                    MAT_CMF_7 tech, MAT_CMF_23 prod_group
                    FROM IDBMGR.MWIPMATDEF WHERE FACTORY='AFB1'
                      AND MAT_CMF_21 IN ({holders})'''
        mes = OracleCRUD.select_query(query, binds)
        for row in mes.itertuples(index=False):
            product = getattr(row, 'product', None)
            device = str(getattr(row, 'device', ''))
            device_name = getattr(row, 'device_name', None)
            if device not in matches:
                continue
            if device_name not in (None, '', ' ') and (not product or device not in str(product)):
                continue
            matches[device].add((getattr(row, 'tech_prod', None),
                                 getattr(row, 'tech', None), getattr(row, 'prod_group', None)))
    # Do not arbitrary-drop conflicting master metadata. Keep null & log conflict.
    for name, index in (('tech_prod', 0), ('tech', 1), ('prod_group', 2)):
        frame[name] = frame['device'].map(lambda dev: next(iter(matches[dev]))[index] if len(matches[dev]) == 1 else None)
    for device, variants in matches.items():
        if len(variants) > 1:
            log.warning('MES metadata is ambiguous for device=%s (%d values)', device, len(variants))
    return frame[COLS]


@dataclass
class CollectionState:
    equip: Equipment
    batch_size: int = UPSERT_BATCH_SIZE
    upserts: list[dict[str, Any]] = field(default_factory=list)
    seen_keys: set[str] = field(default_factory=set)
    unchanged_keys: set[str] = field(default_factory=set)
    new_cnt: int = 0
    update_cnt: int = 0
    download_failures: int = 0

    def __post_init__(self) -> None:
        if not 1 <= self.batch_size <= 999:
            raise ValueError('batch_size must be within [1, 999]')

    def append(self, recipe: dict[str, Any]) -> None:
        self.upserts.append(recipe)
        if len(self.upserts) >= self.batch_size:
            self.flush()

    def flush(self) -> None:
        if not self.upserts:
            return
        enriched = join_mes_info(self.upserts)
        update_database(self.equip, enriched, [], [], finalize=False)
        self.new_cnt += sum(x['status'] == 'new' for x in self.upserts)
        self.update_cnt += sum(x['status'] == 'update' for x in self.upserts)
        log.info('[%s] flushed %s rows', self.equip.name, len(self.upserts))
        self.upserts.clear()


def _recipe_info(equip: Equipment, entry: FTPEntry, device: str, layer: str,
                 path_parts: list[str], required: str, file_status: str) -> dict:
    recipe = entry.name
    remote = '/'.join([equip.ftp_info.remote_directory.rstrip('/'), *path_parts, recipe])
    return {
        'recipe_key': f'{equip.name}-{recipe}', 'model': equip.model,
        'equip': equip.name, 'device': device, 'layer': layer, 'level': layer[:4],
        'recipe': recipe, 'folder_path': remote, 'file_path': f'{remote}/{required}',
        'dt_edit_time': parse_edit_time(entry.raw),
        'backup_folder_path': f'/{equip.name}/{recipe}',
        'backup_file_path': f'/{equip.name}/{recipe}/{required}',
        'dt_backup': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'status': file_status, 'is_remove': False,
        'parse_status': 'pending', 'parse_error': None,
    }


def _scan_recipe(ftp: FTP, entry: FTPEntry, equip: Equipment, equip_dir: Path,
                 lookup: dict, state: CollectionState, required: str,
                 device: str, layer: str, path_parts: list[str]) -> None:
    key = f'{equip.name}-{entry.name}'
    if key in state.seen_keys:
        raise RuntimeError(f'Duplicate Recipe key in FTP traversal: {key}')
    state.seen_keys.add(key)
    dest = equip_dir / entry.name
    edit_time = parse_edit_time(entry.raw)
    needs_update, status = is_file_update(lookup, key, edit_time, dest / required)
    if not needs_update:
        state.unchanged_keys.add(key)
        return
    try:
        safe_download_recipe(ftp, entry.name, dest, required)
    except Exception as exc:
        state.download_failures += 1
        log.exception('[%s] Recipe download failed: %s', equip.name, entry.name)
        # Download failure is recoverable for this Recipe; it cannot be treated as a deletion.
        return
    state.append(_recipe_info(equip, entry, device, layer, path_parts, required, status))


def _scan_nested_device(ftp: FTP, equip: Equipment, equip_dir: Path,
                        lookup: dict, state: CollectionState, device: str) -> None:
    """Runs in FTP remote_directory, traversing device/layer/recipe directories."""
    base = ftp.pwd()
    try:
        ftp.cwd(device)
        for layer_entry in list_entries(ftp):
            if not is_layer(layer_entry):
                continue
            layer = layer_entry.name
            ftp.cwd(layer)
            try:
                for entry in list_entries(ftp):
                    if is_recipe_kla2365(entry, device, layer):
                        _scan_recipe(ftp, entry, equip, equip_dir, lookup,
                                     state, 'Sensitivity1.xml', device,
                                     entry.name.split('_', 1)[1], [device, layer])
            finally:
                ftp.cwd('..')
    finally:
        ftp.cwd(base)


def collect_kla2139(equip: Equipment, equip_dir: Path, lookup: dict,
                    state: CollectionState) -> None:
    with FTP(timeout=equip.ftp_info.timeout_seconds, encoding=equip.ftp_info.encoding) as ftp:
        ftp.connect(equip.ftp_info.host, equip.ftp_info.port)
        ftp.login(equip.ftp_info.username, equip.ftp_info.password)
        ftp.cwd(equip.ftp_info.remote_directory)
        for entry in list_entries(ftp):
            if is_recipe(entry):
                device, layer = entry.name.split('_', 1)
                _scan_recipe(ftp, entry, equip, equip_dir, lookup,
                             state, 'ins.dat', device, layer, [])


def collect_kla2365(equip: Equipment, equip_dir: Path, lookup: dict,
                    state: CollectionState) -> None:
    with FTP(timeout=equip.ftp_info.timeout_seconds, encoding=equip.ftp_info.encoding) as ftp:
        ftp.connect(equip.ftp_info.host, equip.ftp_info.port)
        ftp.login(equip.ftp_info.username, equip.ftp_info.password)
        # KLA2365/PUMA: original code lists Device dirs directly at FTP login cwd.
        for entry in list_entries(ftp):
            if is_device(entry):
                _scan_nested_device(ftp, equip, equip_dir, lookup, state, entry.name)


def collect_puma(equip: Equipment, equip_dir: Path, lookup: dict,
                 state: CollectionState) -> None:
    collect_kla2365(equip, equip_dir, lookup, state)


def update_database(equip: Equipment, upserts: pd.DataFrame, remove_keys: list[str],
                    unchange_keys: list[str], *, finalize: bool = True,
                    new_cnt: int | None = None, update_cnt: int | None = None) -> None:
    if not upserts.empty:
        PostgresCRUD.upsert('dm_recipe_info', 'dm_recipe_info_pkey', upserts)
    if not finalize:
        return
    if new_cnt is None:
        new_cnt = int(upserts['status'].eq('new').sum()) if 'status' in upserts else 0
    if update_cnt is None:
        update_cnt = int(upserts['status'].eq('update').sum()) if 'status' in upserts else 0
    history = pd.DataFrame([{
        'model': equip.model, 'equip': equip.name, 'new_rcp': new_cnt,
        'update_rcp': update_cnt, 'remove_rcp': len(remove_keys),
        'aggregation_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    }])
    PostgresCRUD.finalize_equipment_scan(equip.name, remove_keys, unchange_keys, history,
                                         chunk_size=UPSERT_BATCH_SIZE)
    log.info('[%s] new=%d update=%d removed=%d unchanged=%d',
             equip.name, new_cnt, update_cnt, len(remove_keys), len(unchange_keys))


def collect_equip_data(equip: Equipment, equip_dir: Path) -> None:
    equip_db = PostgresCRUD.select_query('''SELECT recipe_key, dt_edit_time, device,
        layer, recipe, backup_file_path FROM dm_recipe_info
        WHERE equip=%s AND is_remove=false''', (equip.name,))
    lookup = build_equipment_lookup(equip_db)
    del equip_db  # free the source DataFrame; retain only indexed Recipe values
    state = CollectionState(equip=equip)
    match equip.model:
        case 'KLA2139':
            collect_kla2139(equip, equip_dir, lookup, state)
        case 'KLA2365':
            collect_kla2365(equip, equip_dir, lookup, state)
        case 'PUMA':
            collect_puma(equip, equip_dir, lookup, state)
        case _:
            raise ValueError(f'Unsupported equipment model: {equip.model}')
    state.flush()
    old_keys = set(lookup)
    if old_keys and not state.seen_keys:
        raise RuntimeError(f'[{equip.name}] FTP returned no Recipe; deletion blocked')
    remove_keys = list(old_keys - state.seen_keys)
    # Large removal is never applied without explicit operator-controlled review.
    allowed_fraction = float(os.getenv('MAX_AUTO_REMOVAL_RATIO', '0.25'))
    if old_keys and (len(remove_keys) / len(old_keys)) > allowed_fraction:
        raise RuntimeError(f'[{equip.name}] Removal ratio {len(remove_keys)}/{len(old_keys)} '
                           f'exceeds {allowed_fraction:.0%}; deletion blocked')
    if state.download_failures:
        # Keep already committed upserts; postpone destructive finalization.
        raise RuntimeError(f'[{equip.name}] {state.download_failures} downloads failed; '
                           'delete/update-history skipped; pending parses remain available')
    update_database(equip, pd.DataFrame(columns=['status']), remove_keys,
                    list(state.unchanged_keys), new_cnt=state.new_cnt,
                    update_cnt=state.update_cnt)


class Collector:
    def __init__(self, equipments: list[dict], dm_dir: Path) -> None:
        self.equipments = equipments
        self.dm_dir = dm_dir

    def run(self) -> None:
        failures = []
        for eq_info in self.equipments:
            equip = create_equipment(eq_info)
            if not equip.enabled:
                continue
            equip_dir = self.dm_dir / equip.name
            equip_dir.mkdir(parents=True, exist_ok=True)
            try:
                log.info('[%s] FTP collection started', equip.name)
                collect_equip_data(equip, equip_dir)
            except Exception:
                failures.append(equip.name)
                log.exception('[%s] FTP collection failed; other equipment continues', equip.name)
        if failures:
            log.error('FTP collection failed for: %s', ', '.join(failures))
