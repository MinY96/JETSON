"""DM RecipeAnalyzer factories."""
from pathlib import Path
from .config.config import DATA_BASE_DIR, load_equipment_config
from .collectors.ftp.collector import Collector
from .workers.dm_recipe.worker import RecipeParser


def _equipments():
    return load_equipment_config(Path(__file__).parent / 'config' / 'equipments.yaml')


def create_collector() -> Collector:
    DATA_BASE_DIR.mkdir(parents=True, exist_ok=True)
    return Collector(equipments=_equipments(), dm_dir=DATA_BASE_DIR)


def create_recipe_parser() -> RecipeParser:
    DATA_BASE_DIR.mkdir(parents=True, exist_ok=True)
    return RecipeParser(equipments=_equipments(), dm_dir=DATA_BASE_DIR)
