"""Shared types."""
from typing import Any
Record = dict[str, Any]

class SafeList(list):
    """Allow positive out-of-bounds indexing without IndexError."""
    def __getitem__(self, index):
        if isinstance(index, int) and index >= len(self):
            return None
        return super().__getitem__(index)
