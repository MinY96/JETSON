"""XML to dictionary, preserving legacy leaf {'type', 'value'} representation."""
from pathlib import Path
import xml.etree.ElementTree as ET
from collections import defaultdict


def xml_to_dict(xml_source: str | Path, from_file: bool = True) -> dict:
    root = ET.parse(xml_source).getroot() if from_file else ET.fromstring(xml_source)

    def get_tag_name(tag: str) -> str:
        return tag.split('}', 1)[-1]

    def convert_value(value: str, dtype: str):
        if dtype.lower() in ('float', 'double'):
            return float(value)
        if dtype.lower() in ('int', 'integer'):
            return int(value)
        if dtype.lower() in ('bool', 'boolean'):
            return value.strip().lower() in ('true', '1')
        return value

    def parse_element(element: ET.Element) -> dict:
        children = list(element)
        dtype = None
        attributes = {}
        for key, value in element.attrib.items():
            attr_name = get_tag_name(key)
            if attr_name == 'dt':
                dtype = value
            else:
                attributes[attr_name] = value
        if not children:
            value = (element.text or '').strip()
            result = {'type': dtype or 'string', 'value': convert_value(value, dtype) if value and dtype else value}
            if attributes:
                result['@attributes'] = attributes
            return result
        grouped = defaultdict(list)
        for child in children:
            grouped[get_tag_name(child.tag)].append(parse_element(child))
        result = {}
        if attributes:
            result['@attributes'] = attributes
        for tag, items in grouped.items():
            result[tag] = items[0] if len(items) == 1 else items
        return result

    return {get_tag_name(root.tag): parse_element(root)}
