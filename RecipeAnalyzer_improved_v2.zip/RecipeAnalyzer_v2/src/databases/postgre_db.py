"""PostgreSQL CRUD, transactionally safe bulk operations, and parse persistence."""
from __future__ import annotations
from contextlib import contextmanager
from threading import Lock
from typing import Any, Iterator, Mapping, Sequence
import re
import pandas as pd
import numpy as np
from psycopg2 import sql
from psycopg2.extras import execute_values
from psycopg2.pool import ThreadedConnectionPool
from src.config import config

Params = Mapping[str, Any] | Sequence[Any] | None
_pool: ThreadedConnectionPool | None = None
_pool_lock = Lock()


def _get_pool():
    global _pool
    if _pool is None:
        with _pool_lock:
            if _pool is None:
                schema = config.POSTGRES_SCHEMA
                if not re.fullmatch(r'[a-z_][a-z0-9_]*', schema):
                    raise ValueError('Invalid POSTGRES_SCHEMA')
                _pool = ThreadedConnectionPool(
                    minconn=config.POSTGRES_POOL_MIN_SIZE,
                    maxconn=config.POSTGRES_POOL_MAX_SIZE,
                    host=config.POSTGRES_HOST, port=config.POSTGRES_PORT,
                    database=config.POSTGRES_DATABASE,
                    user=config.POSTGRES_USER, password=config.POSTGRES_PASSWORD,
                    connect_timeout=config.POSTGRES_CONNECT_TIMEOUT,
                    options=f'-c search_path={schema},public',
                )
    return _pool


@contextmanager
def transaction() -> Iterator[tuple[Any, Any]]:
    pool = _get_pool()
    conn = pool.getconn()
    try:
        with conn.cursor() as cursor:
            yield conn, cursor
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        pool.putconn(conn)


def close_pool() -> None:
    global _pool
    with _pool_lock:
        if _pool is not None:
            _pool.closeall()
            _pool = None


def _select_sql(query: str) -> str:
    if not isinstance(query, str) or not re.match(r'^\s*(SELECT|WITH)\b', query, re.I):
        raise ValueError('Expected a SELECT query')
    return query.strip().rstrip(';')


def _table_id(name: str):
    if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)?', name):
        raise ValueError(f'Invalid table identifier: {name!r}')
    return sql.Identifier(*name.split('.'))


def _db_value(value):
    if value is None:
        return None
    if isinstance(value, pd.Timestamp):
        return None if pd.isna(value) else value.to_pydatetime()
    if isinstance(value, pd.Timedelta):
        return None if pd.isna(value) else value.to_pytimedelta()
    if isinstance(value, np.generic):
        return _db_value(value.item())
    if isinstance(value, (dict, list, tuple, np.ndarray)):
        # Arrays/JSON must be adapted by the caller; never call pd.isna() on vectors.
        return value
    return None if pd.isna(value) else value


def _constraint_key_columns(cursor, name: str, constraint_name: str) -> list[str]:
    cursor.execute('''
        SELECT a.attname FROM pg_catalog.pg_constraint c
        JOIN LATERAL unnest(c.conkey) WITH ORDINALITY AS k(attnum, ord) ON TRUE
        JOIN pg_catalog.pg_attribute a ON a.attrelid=c.conrelid AND a.attnum=k.attnum
        WHERE c.conrelid=%s::regclass AND c.conname=%s AND c.contype IN ('p','u')
          AND c.condeferrable=false ORDER BY k.ord
    ''', (name, constraint_name))
    return [row[0] for row in cursor.fetchall()]


def _upsert_on_cursor(conn, cursor, table: str, constraint_name: str,
                      frame: pd.DataFrame, chunk_size: int = 1000) -> int:
    if frame.empty:
        return 0
    table_id = _table_id(table)
    if not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*', constraint_name):
        raise ValueError('Invalid constraint identifier')
    columns = list(frame.columns)
    if len(set(columns)) != len(columns) or not all(re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*', c) for c in columns):
        raise ValueError('Invalid/duplicate dataframe columns')
    keys = _constraint_key_columns(cursor, table_id.as_string(conn), constraint_name)
    if not keys or not set(keys).issubset(columns):
        raise ValueError(f'Constraint missing or key mismatch: {table}.{constraint_name}')
    updates = [c for c in columns if c not in keys]
    if updates:
        action = sql.SQL('DO UPDATE SET {}').format(sql.SQL(',').join(
            sql.SQL('{}=EXCLUDED.{}').format(sql.Identifier(c), sql.Identifier(c))
            for c in updates))
    else:
        action = sql.SQL('DO NOTHING')
    statement = sql.SQL('INSERT INTO {} ({}) VALUES %s ON CONFLICT ON CONSTRAINT {} {}').format(
        table_id, sql.SQL(',').join(map(sql.Identifier, columns)),
        sql.Identifier(constraint_name), action).as_string(conn)
    affected = 0
    for start in range(0, len(frame), chunk_size):
        chunk = frame.iloc[start:start + chunk_size]
        complete = chunk[keys].notna().all(axis=1)
        chunk = chunk.loc[~(complete & chunk.duplicated(keys, keep='last'))]
        values = [tuple(_db_value(v) for v in row)
                  for row in chunk.itertuples(index=False, name=None)]
        if not values:
            continue
        execute_values(cursor, statement, values, page_size=len(values))
        affected += max(cursor.rowcount, 0)
    return affected


class PostgresCRUD:
    @staticmethod
    def select_query(query: str, params: Params = None) -> pd.DataFrame:
        with transaction() as (_, cur):
            cur.execute(_select_sql(query), params)
            cols = [desc.name for desc in cur.description]
            rows = cur.fetchall()
        return pd.DataFrame.from_records(rows, columns=cols)

    @staticmethod
    def select_query_by_list(query: str, params: Params = None, *, null_value: Any = 'NULL') -> list[Any]:
        with transaction() as (_, cur):
            cur.execute(_select_sql(query), params)
            return [r[0] if r[0] is not None else null_value for r in cur]

    @staticmethod
    def select_one(query: str, params: Params = None) -> dict | None:
        with transaction() as (_, cur):
            cur.execute(_select_sql(query), params)
            row = cur.fetchone()
            return dict(zip((d.name for d in cur.description), row)) if row else None

    @staticmethod
    def select_scalar(query: str, params: Params = None, *, default=None):
        with transaction() as (_, cur):
            cur.execute(_select_sql(query), params)
            row = cur.fetchone()
            return row[0] if row else default

    @staticmethod
    def select_query_by_conditions(query: str, conditions: list[dict], *, params: Params = None,
                                   batch_size: int = 1000) -> pd.DataFrame:
        """Batched composite-key selection; all condition maps must have matching keys."""
        if not conditions:
            return pd.DataFrame()
        keys = list(conditions[0])
        if not keys or any(set(row) != set(keys) for row in conditions):
            raise ValueError('All condition dictionaries must have identical keys')
        if not all(re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*', k) for k in keys):
            raise ValueError('Invalid column name')
        rows = list(dict.fromkeys(tuple(d[k] for k in keys) for d in conditions))
        if batch_size < 1:
            raise ValueError('batch_size must be positive')
        results = []
        cols = None
        with transaction() as (conn, cur):
            base = cur.mogrify(_select_sql(query), params).decode(conn.encoding).replace('%', '%%')
            for start in range(0, len(rows), batch_size):
                chunk = rows[start:start + batch_size]
                predicate = sql.SQL(' AND ').join(
                    # An all-NULL VALUES column has no useful SQL type. Use IS NULL
                    # instead of a cross-type comparison (e.g. int versus text).
                    (sql.SQL('src.{} IS NULL').format(sql.Identifier(k))
                     if all(row[j] is None for row in chunk) else
                     sql.SQL('src.{} IS NOT DISTINCT FROM cond.{}').format(
                         sql.Identifier(k), sql.Identifier(k)))
                    for j, k in enumerate(keys))
                q = sql.SQL('SELECT src.* FROM ({}) src WHERE EXISTS (SELECT 1 FROM (VALUES %s) cond ({}) WHERE {})').format(
                    sql.SQL(base),sql.SQL(',').join(map(sql.Identifier, keys)),predicate)
                results.extend(execute_values(cur, q.as_string(conn), chunk, fetch=True, page_size=len(chunk)))
                if cols is None:
                    cols = [d.name for d in cur.description]
        return pd.DataFrame.from_records(results, columns=cols)

    @staticmethod
    def upsert(table: str, constraint_name: str, dataframe: pd.DataFrame, *, chunk_size: int = 1000) -> int:
        if not isinstance(dataframe, pd.DataFrame):
            raise TypeError('dataframe must be DataFrame')
        if chunk_size < 1:
            raise ValueError('chunk_size must be positive')
        if dataframe.empty:
            return 0
        with transaction() as (conn, cur):
            return _upsert_on_cursor(conn, cur, table, constraint_name, dataframe, chunk_size)

    @staticmethod
    def execute(query: str, params: Params = None) -> int:
        with transaction() as (_, cur):
            cur.execute(query, params)
            return cur.rowcount

    @staticmethod
    def execute_many_values(query: str, values: Sequence[Sequence[Any]], *,
                            template: str | None = None, page_size: int = 1000) -> int:
        affected = 0
        with transaction() as (_, cur):
            for start in range(0, len(values), page_size):
                batch = values[start:start + page_size]
                execute_values(cur, query, batch, template=template, page_size=len(batch))
                affected += max(cur.rowcount, 0)
        return affected

    @staticmethod
    def finalize_equipment_scan(equip_name: str, remove_keys: list[str],
                                unchanged_keys: list[str], history: pd.DataFrame,
                                *, chunk_size: int = 999) -> None:
        """Delete marking, unchanged status resets, and aggregate row atomically."""
        with transaction() as (conn, cur):
            for offset in range(0, len(remove_keys), chunk_size):
                cur.execute('''UPDATE dm_recipe_info SET is_remove=true,status='remove'
                    WHERE equip=%s AND recipe_key=ANY(%s)''',
                    (equip_name, remove_keys[offset:offset + chunk_size]))
            for offset in range(0, len(unchanged_keys), chunk_size):
                cur.execute('''UPDATE dm_recipe_info SET status=NULL
                    WHERE equip=%s AND recipe_key=ANY(%s)''',
                    (equip_name, unchanged_keys[offset:offset + chunk_size]))
            _upsert_on_cursor(conn, cur, 'dm_update_history',
                              'dm_update_history_pkey', history)

    @staticmethod
    def replace_recipe_parameters(results: list[tuple[str, dict]]) -> int:
        """Atomically replace all params, update mode and mark parse success for a batch.

        A failed transaction leaves parse_status='pending' so the next run retries.
        """
        if not results:
            return 0
        keys = [key for key, _ in results]
        rows = [{'recipe_key': key, 'para_nm': name, 'para_value': value, 'matching': None}
                for key, params in results for name, value in params.items() if value is not None]
        modes = [(params.get('mode'), key) for key, params in results if 'mode' in params]
        with transaction() as (conn, cur):
            cur.execute('DELETE FROM dm_recipe_para WHERE recipe_key = ANY(%s)', (keys,))
            if rows:
                _upsert_on_cursor(conn, cur, 'dm_recipe_para', 'recipe_para_pk', pd.DataFrame(rows))
            if modes:
                cur.executemany('UPDATE dm_recipe_info SET mode = %s WHERE recipe_key = %s', modes)
            cur.execute('''
                UPDATE dm_recipe_info
                SET parse_status='success', parse_error=NULL
                WHERE recipe_key=ANY(%s)
            ''', (keys,))
        return len(keys)

    @staticmethod
    def mark_parse_failure(recipe_key: str, message: str) -> None:
        PostgresCRUD.execute('''
            UPDATE dm_recipe_info
            SET parse_status='failed', parse_error=%s
            WHERE recipe_key=%s
        ''', (message[:2000], recipe_key))
