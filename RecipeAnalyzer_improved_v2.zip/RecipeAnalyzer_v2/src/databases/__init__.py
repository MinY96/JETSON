from .oracle_db import OracleCRUD, close_pool as close_oracle_pool
from .postgre_db import PostgresCRUD, close_pool as close_postgres_pool

__all__ = ['OracleCRUD', 'PostgresCRUD', 'close_pools']

def close_pools():
    close_postgres_pool()
    close_oracle_pool()
