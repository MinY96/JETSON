from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock
import pandas as pd
import pytest
from src.collectors.ftp import collector as mod
from src.domain.entities.equipment import Equipment, FTPConnectionInfo


def equip():
    return Equipment('SMDI01','FAB1','DM','KLA2139',
            FTPConnectionInfo('localhost','u','p',21,'cp949',30,'/remote'))


def test_lookup_and_string_edit_time(tmp_path):
    records = pd.DataFrame([{'recipe_key':'SMDI01-A301_TEST',
                             'dt_edit_time':'2025-10-01 15:25'}])
    lookup = mod.build_equipment_lookup(records)
    old = tmp_path / 'ins.dat'
    old.write_text('x')
    assert mod.is_file_update(lookup,'SMDI01-A301_TEST','2025-10-02 11:00',old) == (True, 'update')
    assert mod.is_file_update(lookup,'SMDI01-A301_TEST','2025-10-01 14:00',old) == (False, None)
    assert mod.is_file_update(lookup,'SMDI01-A302_TEST','2025-10-01 14:00',old) == (True, 'new')
    assert len(lookup) == 1


def test_flush_999_and_last_one(monkeypatch):
    sizes = []
    monkeypatch.setattr(mod, 'join_mes_info', lambda records: pd.DataFrame(records))
    monkeypatch.setattr(mod, 'update_database', lambda e, data, *args, **kw: sizes.append(len(data)))
    state = mod.CollectionState(equip())
    for i in range(1000):
        state.append({'recipe_key':f'key_{i}','status':'new'})
    assert sizes == [999]
    assert len(state.upserts) == 1
    state.flush()
    assert sizes == [999,1] and state.new_cnt == 1000


def test_failed_flush_keeps_buffer(monkeypatch):
    monkeypatch.setattr(mod, 'join_mes_info', lambda records: pd.DataFrame(records))
    def fail(*args, **kwargs):
        raise RuntimeError('db failed')
    monkeypatch.setattr(mod, 'update_database', fail)
    state = mod.CollectionState(equip(), batch_size=1)
    with pytest.raises(RuntimeError):
        state.append({'recipe_key':'x','status':'new'})
    assert len(state.upserts) == 1
    assert state.new_cnt == 0


def test_mes_ambiguous_metadata_nulls(monkeypatch):
    monkeypatch.setattr(mod.OracleCRUD, 'select_query', staticmethod(
        lambda *a, **k: pd.DataFrame([
            {'product':'A301_A','device':'A301','device_name':'n','tech_prod':'X','tech':'T1','prod_group':'G'},
            {'product':'A301_B','device':'A301','device_name':'n','tech_prod':'Y','tech':'T2','prod_group':'G'},
        ])
    ))
    recipe = {col: None for col in mod.COLS}
    recipe['device'] = 'A301'
    frame = mod.join_mes_info([recipe])
    assert len(frame) == 1
    assert pd.isna(frame.iloc[0]['tech'])


def test_mass_deletion_blocked(monkeypatch,tmp_path):
    equip_value = equip()
    original = pd.DataFrame({'recipe_key':[f'r{i}' for i in range(10)],
                             'dt_edit_time':['2025-01-01 00:00']*10})
    monkeypatch.setattr(mod.PostgresCRUD, 'select_query', staticmethod(lambda *args:original))
    def fake_collect(eq, eqdir, lookup, state):
        state.seen_keys.update(['r1', 'r2'])
    monkeypatch.setattr(mod,'collect_kla2139',fake_collect)
    with pytest.raises(RuntimeError, match='Removal ratio'):
        mod.collect_equip_data(equip_value,tmp_path)


def test_scan_error_does_not_run_removal(monkeypatch, tmp_path):
    previous = pd.DataFrame({'recipe_key':['A301','A302'],
                             'dt_edit_time':['2026-01-01 00:00'] * 2})
    monkeypatch.setattr(mod.PostgresCRUD, 'select_query', staticmethod(lambda *a,**k:previous))
    def failure(eq, eqdir, lookup, state):
        state.seen_keys.add('A301')
        raise ConnectionError('FTP LIST failed for remaining folder')
    monkeypatch.setattr(mod, 'collect_kla2139', failure)
    committed = []
    monkeypatch.setattr(mod, 'update_database', lambda *a,**k: committed.append(1))
    with pytest.raises(ConnectionError):
        mod.collect_equip_data(equip(), tmp_path)
    assert not committed


def test_date_format_preserved_as_string():
    assert mod.parse_edit_time('drw-rw-rw- 1 user group 0 Aug 30 2012 A301_RECIPE') == '2012-08-30 00:00'
