from pathlib import Path
import pytest
from src.collectors.ftp.client import (
    FTPListingError, FTPDownloadError, parse_list_line,
    list_entries, safe_download_recipe,
)


def test_unix_list_directory_and_file():
    directory = parse_list_line('drw-rw-rw-    1 user group 0 Aug 30  2012 CP31_BSRPP')
    file = parse_list_line('-rw-rw-rw- 1 user group 123 Aug 30 2012 ins.dat')
    assert directory.name == 'CP31_BSRPP' and directory.is_dir
    assert file.name == 'ins.dat' and not file.is_dir
    with pytest.raises(FTPListingError):
        parse_list_line('unexpected FTP listing line')


class FakeFTP:
    def __init__(self, fail_retr=False):
        self.parts = []
        self.fail_retr = fail_retr

    def pwd(self):
        return '/' + '/'.join(self.parts)

    def cwd(self, where):
        if where == '..':
            self.parts.pop()
        elif where == '/':
            self.parts = []
        elif where == self.pwd():
            pass
        elif where.startswith('/'):
            self.parts = [v for v in where.split('/') if v]
        else:
            self.parts.append(where)

    def retrlines(self, command, callback):
        assert command == 'LIST'
        if self.parts == []:
            callback('drw-rw-rw- 1 user group 0 Aug 30 2012 A301_TEST')
        elif self.parts == ['A301_TEST']:
            callback('-rw-rw-rw- 1 user group 12 Aug 30 2012 ins.dat')

    def retrbinary(self, command, callback):
        if self.fail_retr:
            raise OSError('connection lost')
        callback(b'example contents')


def test_list_recognizes_nested_folders():
    ftp = FakeFTP()
    assert list_entries(ftp)[0].name == 'A301_TEST'


def test_download_atomic_success(tmp_path: Path):
    ftp = FakeFTP()
    dest = tmp_path / 'A301_TEST'
    safe_download_recipe(ftp, 'A301_TEST', dest, 'ins.dat')
    assert (dest / 'ins.dat').read_bytes() == b'example contents'
    assert ftp.pwd() == '/'


def test_failed_download_keeps_old_contents(tmp_path: Path):
    ftp = FakeFTP(fail_retr=True)
    dest = tmp_path / 'A301_TEST'
    dest.mkdir()
    (dest / 'ins.dat').write_bytes(b'original')
    with pytest.raises(OSError):
        safe_download_recipe(ftp, 'A301_TEST', dest, 'ins.dat')
    assert (dest / 'ins.dat').read_bytes() == b'original'
    assert ftp.pwd() == '/'
