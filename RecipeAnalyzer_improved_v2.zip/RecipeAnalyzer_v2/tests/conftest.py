"""Isolate unit tests from company database credentials and native Oracle client."""
from __future__ import annotations
import sys
import types
import pytest

# The unit tests exercise the scanner, parser and worker logic but not real DB clients.
# A real connection requires dependencies from requirements.txt and live credentials.
fake_db = types.ModuleType('src.databases')
class FakePostgres:
    @staticmethod
    def select_query(*a, **kw):
        raise RuntimeError('Mock DB before calling')
    @staticmethod
    def upsert(*a, **kw):
        raise RuntimeError('Mock DB before calling')
    @staticmethod
    def execute(*a, **kw):
        raise RuntimeError('Mock DB before calling')
    @staticmethod
    def replace_recipe_parameters(*a, **kw):
        raise RuntimeError('Mock DB before calling')
    @staticmethod
    def mark_parse_failure(*a, **kw):
        raise RuntimeError('Mock DB before calling')
fake_db.PostgresCRUD = FakePostgres
fake_db.OracleCRUD = type('FakeOracle', (), {'select_query': staticmethod(lambda *a,**kw: __import__('pandas').DataFrame())})
fake_db.close_pools = lambda: None
sys.modules['src.databases'] = fake_db
