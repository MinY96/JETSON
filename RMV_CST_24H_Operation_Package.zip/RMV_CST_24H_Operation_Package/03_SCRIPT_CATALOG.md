# RMV CST 주요 스크립트 기능 및 실행 방법

기준 작업 폴더:

```bash
cd /home/fab1innfo/rmv_cst
```

## 1. `final_cst_inference_operation.py`

### 기능

- 실시간 캡처 또는 MP4 입력
- Empty/Pink/Wafer 판정
- Cycle Lock과 WARNING 우선 처리
- PATLITE 알람
- 이벤트 영상 저장
- 일 단위 실시간 CSV 로그
- 랜덤 프레임 및 이상 판정 Review Queue 자동 저장
- 자동 프레임 총량 약 5GB 유지

### 실시간 운영

```bash
sudo -E ./rmv_cst_trt_env/bin/python \
  src/final_cst_inference_operation.py \
  --input_mode capture \
  --capture_index 0 \
  --use_patlite true \
  --show_window false
```

### MP4 테스트

```bash
./rmv_cst_trt_env/bin/python \
  src/final_cst_inference_operation.py \
  --input_mode mp4 \
  --video_path ./videos/test.mp4 \
  --use_patlite false \
  --show_window true \
  --display_scale 0.5
```

## 2. `thermal_watchdog.py`

### 기능

- Jetson thermal zone 온도 감시
- 75°C 경고
- 82°C 추론 서비스 중지
- 75°C 이하 추론 재시작
- 88°C 60초 지속 시 재부팅
- 일 단위 온도 로그 및 N일 보관

### 수동 테스트

```bash
sudo /usr/bin/python3 src/thermal_watchdog.py \
  --service rmv_cst.service \
  --log_dir ./logs/thermal
```

## 3. `roi_labeling_tool.py`

### 기능

수집된 Full Frame을 보면서 Left/Right ROI를 클래스 폴더에 저장한다.

키:

```text
1 left/pink
2 left/non_pink
3 left/empty
4 left/unknown
5 right/pink
6 right/non_pink
7 right/no_wafer
8 right/wafer_exist
9 right/empty
0 right/unknown
```

### 실행

```bash
./rmv_cst_trt_env/bin/python \
  src/roi_labeling_tool.py \
  --image_dir ./captured_frames \
  --frame_root ./frames \
  --left_roi 3 85 300 410 \
  --right_roi 1210 240 540 600 \
  --display_scale 0.5
```

## 4. `build_empty_references.py`

### 기능

- `frames/left/empty`, `frames/right/empty`에서 랜덤 Reference 추출
- 원본 frames는 수정하지 않음
- 기존 `reference_empty/left`, `right` 출력 이미지만 교체
- 추출 이력 CSV 저장

### 실행

```bash
./rmv_cst_trt_env/bin/python \
  src/build_empty_references.py \
  --frame_root ./frames \
  --output_dir ./reference_empty \
  --left_count 10 \
  --right_count 10 \
  --seed 42
```

## 5. `find_pink_rule_threshold.py`

### 기능

- Left/Right의 pink와 non_pink 이미지에서 RGB/HSV 특징 추출
- 반복 Stratified Random Split 검증
- 단일 Threshold 및 2-feature AND Rule 탐색
- Pink Recall 우선, NonPink→Pink 오판 최소화
- `pink_rule_thresholds.json` 생성

### 실행

```bash
./rmv_cst_trt_env/bin/python \
  src/find_pink_rule_threshold.py \
  --frame_root ./frames \
  --output_dir ./pink_rule_search \
  --n_splits 30 \
  --val_ratio 0.3 \
  --min_pink_recall 1.0
```

## 6. `validate_empty_and_pink_logic_rule.py`

### 기능

- Empty Reference 판정 성능 검증
- Rule 기반 Pink 판정 성능 검증
- Left/Right별 confusion matrix, details.csv, metrics.json 생성

### 실행

```bash
./rmv_cst_trt_env/bin/python \
  src/validate_empty_and_pink_logic_rule.py \
  --frame_root ./frames \
  --reference_empty_dir ./reference_empty \
  --output_dir ./validation_results_rule \
  --left_empty_threshold 19 \
  --right_empty_threshold 18
```

## 7. `train_wafer_mobilenetv3_kfold.py`

### 기능

- `frames/right/no_wafer`, `frames/right/wafer_exist` 학습
- MobileNetV3-Small
- Stratified K-Fold 검증
- 최종 PyTorch 모델 및 ONNX 생성
- 클래스 불균형 가중치 적용

### 실행

```bash
./rmv_cst_trt_env/bin/python \
  src/train_wafer_mobilenetv3_kfold.py \
  --data_root ./frames/right \
  --output_model_dir ./models \
  --output_log_dir ./logs \
  --epochs 20 \
  --final_epochs 20 \
  --batch_size 32 \
  --k_folds 5 \
  --img_size 224
```

### TensorRT 변환

```bash
/usr/src/tensorrt/bin/trtexec \
  --onnx=models/wafer_mobilenetv3_small.onnx \
  --saveEngine=models/wafer_mobilenetv3_small_fp16.engine \
  --fp16
```

## 8. `capture_reference_empty_realtime.py`

### 기능

- 실시간 캡처 화면에서 Left/Right Empty ROI 수집
- 지정 개수 완료 시 자동 종료
- 새로운 카메라 위치나 조명 변경 시 Reference 생성용

### 실행 예시

```bash
./rmv_cst_trt_env/bin/python \
  src/capture_reference_empty_realtime.py \
  --capture_index 0 \
  --left_roi 3 85 300 410 \
  --right_roi 1210 240 540 600 \
  --display_scale 0.5
```

## 9. `capture_pink_threshold_realtime.py`

### 기능

- 실시간 Left/Right Pink CST ROI 수집
- `l`, `r` 키로 방향별 저장
- 종료 후 Pink Threshold 생성 지원

### 실행 예시

```bash
./rmv_cst_trt_env/bin/python \
  src/capture_pink_threshold_realtime.py \
  --capture_index 0 \
  --left_roi 3 85 300 410 \
  --right_roi 1210 240 540 600
```

## 10. 재학습 데이터 반영 순서

```text
auto_frames/review_queue 수동 검토
→ 잘못된 pseudo label 수정
→ frames/left 또는 frames/right의 정식 클래스 폴더로 복사
→ Empty Reference 재생성
→ Pink Rule 재탐색 및 검증
→ Wafer K-Fold 재학습 및 검증
→ ONNX/TensorRT 엔진 재생성
→ MP4 테스트
→ 서비스 파일 교체 후 재시작
```
