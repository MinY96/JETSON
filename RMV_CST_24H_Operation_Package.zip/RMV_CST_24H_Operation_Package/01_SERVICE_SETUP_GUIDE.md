# RMV CST 서비스 등록·시작·중지 가이드

작성일: 2026-07-13

## 1. 배치 위치

압축을 해제한 뒤 다음처럼 배치한다.

```text
/home/fab1innfo/rmv_cst/
├── src/
│   ├── final_cst_inference_operation.py
│   └── thermal_watchdog.py
├── models/
│   ├── wafer_mobilenetv3_small_fp16.engine
│   └── wafer_class_meta.json
├── reference_empty/
│   ├── left/
│   └── right/
├── pink_rule_search/
│   └── pink_rule_thresholds.json
├── event/
├── logs/
├── history/
└── auto_frames/
```

```bash
cd /home/fab1innfo/rmv_cst
mkdir -p src models reference_empty/left reference_empty/right \
  pink_rule_search event logs history auto_frames
```

## 2. 서비스 등록 전 수동 확인

```bash
cd /home/fab1innfo/rmv_cst

sudo -E ./rmv_cst_trt_env/bin/python \
  src/final_cst_inference_operation.py \
  --input_mode capture \
  --capture_index 0 \
  --use_patlite true \
  --show_window false \
  --max_frames 300
```

다음을 확인한다.

- `[INFO] PATLITE LR6-USB connected`
- 캡처카드가 정상적으로 열림
- TensorRT 엔진 로드 오류가 없음
- `logs/`, `history/`에 일 단위 CSV가 생성됨
- `auto_frames/`에 랜덤 수집 파일이 생성될 수 있음

## 3. 추론 서비스 등록

```bash
sudo nano /etc/systemd/system/rmv_cst.service
```

```ini
[Unit]
Description=RMV CST 24H Inference
After=multi-user.target
StartLimitIntervalSec=300
StartLimitBurst=10

[Service]
Type=simple
User=fab1innfo
WorkingDirectory=/home/fab1innfo/rmv_cst

ExecStart=/home/fab1innfo/rmv_cst/rmv_cst_trt_env/bin/python \
  /home/fab1innfo/rmv_cst/src/final_cst_inference_operation.py \
  --input_mode capture \
  --capture_index 0 \
  --capture_backend v4l2 \
  --capture_width 1920 \
  --capture_height 1080 \
  --capture_fps 30 \
  --fourcc MJPG \
  --left_roi 3 85 300 410 \
  --right_roi 1210 240 540 600 \
  --use_patlite true \
  --show_window false \
  --keep_log_days 7 \
  --log_every_n_frames 10 \
  --enable_auto_frame_save true \
  --random_save_interval_sec 30 \
  --random_save_probability 0.2 \
  --auto_frame_max_gb 5 \
  --random_quota_ratio 0.8 \
  --storage_check_interval_sec 600 \
  --min_free_gb 5

Restart=always
RestartSec=10
TimeoutStopSec=30
KillSignal=SIGINT

Environment=PYTHONUNBUFFERED=1
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

> `log_every_n_frames=10`은 30fps 기준 최대 초당 약 3행을 기록한다. 모든 프레임이 필요하면 1로 바꿀 수 있지만 디스크 쓰기량이 크게 증가한다.

## 4. 온도 Watchdog 서비스 등록

```bash
sudo nano /etc/systemd/system/rmv_cst_thermal_watchdog.service
```

```ini
[Unit]
Description=RMV CST Thermal Watchdog
After=multi-user.target

[Service]
Type=simple
User=root
WorkingDirectory=/home/fab1innfo/rmv_cst

ExecStart=/usr/bin/python3 \
  /home/fab1innfo/rmv_cst/src/thermal_watchdog.py \
  --service rmv_cst.service \
  --log_dir /home/fab1innfo/rmv_cst/logs/thermal \
  --keep_log_days 30 \
  --check_interval_sec 10 \
  --warn_temp 75 \
  --pause_temp 82 \
  --resume_temp 75 \
  --reboot_temp 88 \
  --reboot_hold_sec 60

Restart=always
RestartSec=10
Environment=PYTHONUNBUFFERED=1
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

Watchdog는 `systemctl stop/start/reboot` 권한이 필요하므로 `root`로 실행한다.

## 5. 서비스 활성화

```bash
sudo systemctl daemon-reload
sudo systemctl enable rmv_cst.service
sudo systemctl enable rmv_cst_thermal_watchdog.service

sudo systemctl start rmv_cst.service
sudo systemctl start rmv_cst_thermal_watchdog.service
```

부팅 시 자동 실행 여부:

```bash
systemctl is-enabled rmv_cst.service
systemctl is-enabled rmv_cst_thermal_watchdog.service
```

둘 다 `enabled`여야 한다.

## 6. 상태와 로그 확인

```bash
sudo systemctl status rmv_cst.service
sudo systemctl status rmv_cst_thermal_watchdog.service
```

```bash
journalctl -u rmv_cst.service -f
journalctl -u rmv_cst_thermal_watchdog.service -f
```

최근 200줄:

```bash
journalctl -u rmv_cst.service -n 200 --no-pager
journalctl -u rmv_cst_thermal_watchdog.service -n 200 --no-pager
```

## 7. 시작·중지·재시작

```bash
sudo systemctl start rmv_cst.service
sudo systemctl stop rmv_cst.service
sudo systemctl restart rmv_cst.service
```

```bash
sudo systemctl start rmv_cst_thermal_watchdog.service
sudo systemctl stop rmv_cst_thermal_watchdog.service
sudo systemctl restart rmv_cst_thermal_watchdog.service
```

추론을 장시간 수동 중지할 때는 Watchdog도 함께 중지한다. Watchdog가 추론 서비스 비활성 상태를 장애로 보고 다시 시작할 수 있기 때문이다.

```bash
sudo systemctl stop rmv_cst_thermal_watchdog.service
sudo systemctl stop rmv_cst.service
```

재개:

```bash
sudo systemctl start rmv_cst.service
sudo systemctl start rmv_cst_thermal_watchdog.service
```

## 8. 서비스 파일 변경 후 적용

```bash
sudo systemctl daemon-reload
sudo systemctl restart rmv_cst.service
sudo systemctl restart rmv_cst_thermal_watchdog.service
```

## 9. 자동 실행 해제

```bash
sudo systemctl disable --now rmv_cst_thermal_watchdog.service
sudo systemctl disable --now rmv_cst.service
```

## 10. 재부팅 검증

```bash
sudo reboot
```

부팅 후:

```bash
systemctl status rmv_cst.service --no-pager
systemctl status rmv_cst_thermal_watchdog.service --no-pager
ls -l /home/fab1innfo/rmv_cst/logs
```

캡처카드의 `/dev/videoN` 번호가 재부팅 후 달라질 수 있다면 `/dev/v4l/by-id/` 기반 고정 경로 사용을 별도로 검토한다.
