#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
final_cst_inference_operation.py

RMV CST 최종 운영 추론 - 24H / Warning Lock / Daily Log / Auto Frame Collection

핵심 로직
1. 좌/우 CST 중 하나라도 Empty -> NonEmpty로 바뀌면 Cycle 시작
2. STABILIZE 단계에서 좌/우 둘 다 NonEmpty가 N프레임 유지되면 1회 판정
3. 일정 시간/프레임이 지나도 둘 중 하나가 Empty이면 INCOMPLETE로 1회 판정
4. 판정 후 Status Lock
5. LOCKED 상태에서는 Pink/Wafer 판정 중지
6. 좌/우 CST 중 하나라도 Empty로 돌아오면 Cycle 종료 후 Reset
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
import shutil
import time
from collections import deque
from datetime import datetime, timedelta
from pathlib import Path
from typing import Deque, Dict, List, Optional, Tuple, Union

import cv2
import numpy as np
import pandas as pd
from PIL import Image

try:
    import torch
    import tensorrt as trt
    from torchvision import transforms
except Exception:
    torch = None
    trt = None
    transforms = None


BASE_DIR = Path(__file__).resolve().parent.parent

DEFAULT_LEFT_ROI = (3, 85, 300, 410)
DEFAULT_RIGHT_ROI = (1210, 240, 540, 600)

DEFAULT_REFERENCE_EMPTY_DIR = BASE_DIR / "reference_empty"
DEFAULT_PINK_RULE_FILE = BASE_DIR / "pink_rule_search" / "pink_rule_thresholds.json"
DEFAULT_ENGINE_PATH = BASE_DIR / "models" / "wafer_mobilenetv3_small_fp16.engine"
DEFAULT_META_PATH = BASE_DIR / "models" / "wafer_class_meta.json"

DEFAULT_LOG_DIR = BASE_DIR / "logs"
DEFAULT_HISTORY_DIR = BASE_DIR / "history"
DEFAULT_EVENT_DIR = BASE_DIR / "event"
DEFAULT_AUTO_FRAME_DIR = BASE_DIR / "auto_frames"

DEFAULT_LEFT_EMPTY_THRESHOLD = 19.0
DEFAULT_RIGHT_EMPTY_THRESHOLD = 18.0
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}

DISPLAY_COLORS = {
    "pink": (203, 72, 255),
    "non_pink": (180, 180, 180),
    "empty": (0, 255, 255),
    "unknown": (255, 255, 255),
    "normal": (0, 255, 0),
    "incomplete": (0, 255, 255),
    "abnormal": (0, 165, 255),
    "warning": (0, 0, 255),
    "idle": (180, 180, 180),
}


def str2bool(v: Union[str, bool]) -> bool:
    if isinstance(v, bool):
        return v
    v = str(v).strip().lower()
    if v in ("true", "1", "yes", "y", "t"):
        return True
    if v in ("false", "0", "no", "n", "f"):
        return False
    raise argparse.ArgumentTypeError("true/false 값을 입력하세요.")


def ensure_dir(path: Union[str, Path]) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def parse_roi(values: List[int]) -> Tuple[int, int, int, int]:
    if len(values) != 4:
        raise ValueError("ROI는 x y w h 4개 정수여야 합니다.")
    return tuple(map(int, values))


def safe_json_load(path: Union[str, Path]) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def list_images(folder: Union[str, Path]) -> List[Path]:
    folder = Path(folder)
    if not folder.exists():
        return []
    return sorted([p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS])


def cleanup_old_files(folder: Union[str, Path], keep_days: int = 7) -> None:
    folder = Path(folder)
    if not folder.exists():
        return
    cutoff = datetime.now() - timedelta(days=keep_days)
    for p in folder.rglob("*"):
        if not p.is_file():
            continue
        try:
            if datetime.fromtimestamp(p.stat().st_mtime) < cutoff:
                p.unlink()
                print(f"[CLEANUP] deleted old file: {p}")
        except Exception as e:
            print(f"[WARN] cleanup failed: {p}, error={e}")


class DailyCsvLogger:
    """일 단위 CSV 로그 파일을 실시간 append 방식으로 기록한다.

    - 파일명: {prefix}_YYYYMMDD.csv
    - 날짜가 바뀌면 자동으로 새 파일 생성
    - keep_days가 지난 로그 파일 자동 삭제
    - 프로그램 종료 시 한꺼번에 저장하지 않고 매 write마다 flush
    """

    def __init__(self, log_dir: Union[str, Path], prefix: str, keep_days: int = 7):
        self.log_dir = ensure_dir(log_dir)
        self.prefix = prefix
        self.keep_days = keep_days
        self.current_date = None
        self.current_path = None
        self.fieldnames = None
        cleanup_old_files(self.log_dir, keep_days=self.keep_days)

    def _today_path(self) -> Path:
        today = datetime.now().strftime("%Y%m%d")
        return self.log_dir / f"{self.prefix}_{today}.csv"

    def write(self, row: dict) -> None:
        path = self._today_path()
        today = datetime.now().strftime("%Y%m%d")
        if self.current_date != today:
            self.current_date = today
            cleanup_old_files(self.log_dir, keep_days=self.keep_days)
        file_exists = path.exists() and path.stat().st_size > 0

        # 첫 row 기준으로 컬럼 고정. 이후 없는 컬럼은 빈 값, 추가 컬럼은 무시하지 않고 컬럼 목록에 확장.
        if self.fieldnames is None:
            self.fieldnames = list(row.keys())
        else:
            for key in row.keys():
                if key not in self.fieldnames:
                    self.fieldnames.append(key)

        # 컬럼이 확장된 경우 기존 파일 헤더와 다를 수 있으므로 운영상 주요 컬럼은 고정해서 쓰는 것을 권장.
        with open(path, "a", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=self.fieldnames)
            if not file_exists:
                writer.writeheader()
            writer.writerow({k: row.get(k, "") for k in self.fieldnames})
            f.flush()


def center_crop(img: np.ndarray, ratio: float) -> np.ndarray:
    if ratio >= 0.999:
        return img
    h, w = img.shape[:2]
    ch = max(1, int(round(h * ratio)))
    cw = max(1, int(round(w * ratio)))
    y1 = (h - ch) // 2
    x1 = (w - cw) // 2
    return img[y1:y1 + ch, x1:x1 + cw].copy()


def crop_roi(frame: np.ndarray, roi: Tuple[int, int, int, int]) -> np.ndarray:
    x, y, w, h = roi
    H, W = frame.shape[:2]
    x1 = max(0, x)
    y1 = max(0, y)
    x2 = min(W, x + w)
    y2 = min(H, y + h)
    if x1 >= x2 or y1 >= y2:
        raise ValueError(f"Invalid ROI: {roi}, frame_size=({W},{H})")
    return frame[y1:y2, x1:x2].copy()


class BoolHoldState:
    def __init__(self, stable_label: bool = True, candidate_label: bool = True, candidate_count: int = 0):
        self.stable_label = stable_label
        self.candidate_label = candidate_label
        self.candidate_count = candidate_count


def update_hold_bool(state: BoolHoldState, pred: bool, hold_frames: int) -> BoolHoldState:
    if hold_frames <= 1:
        state.stable_label = pred
        state.candidate_label = pred
        state.candidate_count = 0
        return state
    if pred == state.stable_label:
        state.candidate_label = pred
        state.candidate_count = 0
        return state
    if pred == state.candidate_label:
        state.candidate_count += 1
    else:
        state.candidate_label = pred
        state.candidate_count = 1
    if state.candidate_count >= hold_frames:
        state.stable_label = state.candidate_label
        state.candidate_count = 0
    return state


class PatliteLR6USBController:
    VENDOR_ID = 0x191A
    DEVICE_ID = 0x8003
    ENDPOINT_ADDRESS = 1
    SEND_TIMEOUT = 1000
    COMMAND_VERSION = 0x00
    COMMAND_ID = 0x00
    LED_OFF = 0x0
    LED_PATTERN1 = 0x2
    BUZZER_OFF = 0x0
    BUZZER_PATTERN1 = 0x2
    BUZZER_PATTERN2 = 0x3
    BUZZER_PITCH_OFF = 0x0
    BUZZER_PITCH1 = 0x1
    BUZZER_PITCH2 = 0x2

    def __init__(self, enabled: bool = False):
        self.enabled = enabled
        self.dev = None
        self.current_alarm = None
        if not self.enabled:
            print("[INFO] PATLITE disabled")
            return
        try:
            import usb.core
            self.dev = usb.core.find(idVendor=self.VENDOR_ID, idProduct=self.DEVICE_ID)
            if self.dev is None:
                raise RuntimeError("PATLITE LR6-USB device not found")
            try:
                if self.dev.is_kernel_driver_active(0):
                    self.dev.detach_kernel_driver(0)
            except Exception:
                pass
            self.dev.set_configuration()
            self.reset()
            print("[INFO] PATLITE LR6-USB connected")
        except Exception as e:
            self.enabled = False
            self.dev = None
            print(f"[WARN] PATLITE init failed. Run without lamp. error={e}")

    def _send(self, red: int, yellow: int, green: int = 0, blue: int = 0, white: int = 0, buzzer: int = 0, buzzer_pitch: int = 0) -> bool:
        if not self.enabled or self.dev is None:
            return False
        led_ry = (red << 4) | yellow
        led_gb = (green << 4) | blue
        led_w = white << 4
        data = bytes([self.COMMAND_VERSION, self.COMMAND_ID, buzzer, buzzer_pitch, led_ry, led_gb, led_w, 0x00])
        try:
            return self.dev.write(self.ENDPOINT_ADDRESS, data, self.SEND_TIMEOUT) == len(data)
        except Exception as e:
            print(f"[WARN] PATLITE send failed: {e}")
            return False

    def reset(self) -> None:
        self._send(red=self.LED_OFF, yellow=self.LED_OFF, buzzer=self.BUZZER_OFF, buzzer_pitch=self.BUZZER_PITCH_OFF)
        self.current_alarm = "PASS"

    def set_alarm(self, alarm: str) -> None:
        alarm = str(alarm).upper()
        if alarm == self.current_alarm:
            return
        self.current_alarm = alarm
        if not self.enabled:
            print(f"[ALARM] {alarm}")
            return
        if alarm == "RED":
            self._send(red=self.LED_PATTERN1, yellow=self.LED_OFF, buzzer=self.BUZZER_PATTERN2, buzzer_pitch=self.BUZZER_PITCH2)
        elif alarm == "ORANGE":
            self._send(red=self.LED_OFF, yellow=self.LED_PATTERN1, buzzer=self.BUZZER_PATTERN1, buzzer_pitch=self.BUZZER_PITCH1)
        else:
            self.reset()

    def cleanup(self) -> None:
        self.reset()


def alarm_from_status(status: str) -> str:
    if status == "WARNING":
        return "RED"
    if status == "ABNORMAL":
        return "ORANGE"
    return "PASS"


def preprocess_for_empty(img_bgr: np.ndarray, center_crop_ratio: float, blur_ksize: int) -> np.ndarray:
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    gray = center_crop(gray, center_crop_ratio)
    if blur_ksize >= 3:
        if blur_ksize % 2 == 0:
            blur_ksize += 1
        gray = cv2.GaussianBlur(gray, (blur_ksize, blur_ksize), 0)
    return gray.astype(np.float32)


def load_empty_refs(reference_dir: Union[str, Path], center_crop_ratio: float, blur_ksize: int) -> Dict[str, List[np.ndarray]]:
    reference_dir = Path(reference_dir)
    refs = {"left": [], "right": []}
    for side in ["left", "right"]:
        for p in list_images(reference_dir / side):
            img = cv2.imread(str(p))
            if img is not None:
                refs[side].append(preprocess_for_empty(img, center_crop_ratio, blur_ksize))
    return refs


def compare_empty(curr_gray: np.ndarray, ref_gray: np.ndarray) -> float:
    curr = curr_gray.astype(np.float32)
    ref = ref_gray.astype(np.float32)
    if curr.shape != ref.shape:
        ref = cv2.resize(ref, (curr.shape[1], curr.shape[0]), interpolation=cv2.INTER_LINEAR)
    curr_mean = float(curr.mean())
    ref_mean = float(ref.mean())
    if curr_mean > 1e-6:
        curr = curr * (ref_mean / curr_mean)
    curr = np.clip(curr, 0, 255)
    diff = np.abs(curr - ref)
    diff[diff < 3] = 0
    return float(diff.mean())


def predict_empty(roi_bgr: np.ndarray, refs: List[np.ndarray], threshold: float, center_crop_ratio: float, blur_ksize: int) -> Tuple[bool, float]:
    if not refs:
        return False, float("inf")
    curr = preprocess_for_empty(roi_bgr, center_crop_ratio, blur_ksize)
    score = float(np.min([compare_empty(curr, ref) for ref in refs]))
    return score <= threshold, score


def normalize_rule_config(data: dict) -> Dict[str, dict]:
    if "left" in data and "right" in data:
        return {"left": data["left"], "right": data["right"]}
    raise ValueError("pink rule json에는 left/right rule이 필요합니다.")


def extract_pink_features(img_bgr: np.ndarray, center_crop_ratio: float, blur_ksize: int) -> Dict[str, float]:
    img = center_crop(img_bgr, center_crop_ratio)
    if blur_ksize >= 3:
        if blur_ksize % 2 == 0:
            blur_ksize += 1
        img = cv2.GaussianBlur(img, (blur_ksize, blur_ksize), 0)
    b, g, r = cv2.split(img)
    r_f = r.astype(np.float32)
    g_f = g.astype(np.float32)
    b_f = b.astype(np.float32)
    rg = r_f - g_f
    rb = r_f - b_f
    bg = b_f - g_f
    return {
        "rg_diff_median": float(np.median(rg)),
        "rb_diff_median": float(np.median(rb)),
        "bg_diff_median": float(np.median(bg)),
        "rg_diff_mean": float(rg.mean()),
        "rb_diff_mean": float(rb.mean()),
        "bg_diff_mean": float(bg.mean()),
    }


def eval_condition(value: float, op: str, threshold: float) -> bool:
    if op == ">=":
        return value >= threshold
    if op == "<=":
        return value <= threshold
    if op == ">":
        return value > threshold
    if op == "<":
        return value < threshold
    raise ValueError(f"Unsupported op: {op}")


def apply_pink_rule(features: Dict[str, float], rule: dict) -> Tuple[str, dict]:
    f1 = rule["feature1"]
    op1 = rule["op1"]
    th1 = float(rule["threshold1"])
    v1 = float(features[f1])
    cond1 = eval_condition(v1, op1, th1)
    debug = {"rule_type": rule["rule_type"], "feature1": f1, "value1": v1, "op1": op1, "threshold1": th1, "cond1": cond1}
    if rule["rule_type"] == "single":
        is_pink = cond1
    elif rule["rule_type"] == "and2":
        f2 = rule["feature2"]
        op2 = rule["op2"]
        th2 = float(rule["threshold2"])
        v2 = float(features[f2])
        cond2 = eval_condition(v2, op2, th2)
        debug.update({"feature2": f2, "value2": v2, "op2": op2, "threshold2": th2, "cond2": cond2})
        is_pink = cond1 and cond2
    else:
        raise ValueError(f"Unsupported rule_type: {rule['rule_type']}")
    return ("pink" if is_pink else "non_pink"), debug


def predict_pink(roi_bgr: np.ndarray, side: str, rules: Dict[str, dict], center_crop_ratio: float, blur_ksize: int) -> Tuple[str, Dict[str, float], dict]:
    features = extract_pink_features(roi_bgr, center_crop_ratio, blur_ksize)
    label, debug = apply_pink_rule(features, rules[side])
    return label, features, debug


class TensorRTWaferClassifier:
    def __init__(self, engine_path: Union[str, Path], meta_path: Union[str, Path]):
        if torch is None or trt is None or transforms is None:
            raise RuntimeError("torch/tensorrt/torchvision import failed")
        meta = safe_json_load(meta_path)
        self.class_to_idx = meta["class_to_idx"]
        self.idx_to_class = {int(k): v for k, v in meta["idx_to_class"].items()}
        self.img_size = int(meta.get("img_size", 224))
        self.positive_label = meta.get("positive_label", "wafer_exist")
        logger = trt.Logger(trt.Logger.WARNING)
        runtime = trt.Runtime(logger)
        with open(engine_path, "rb") as f:
            self.engine = runtime.deserialize_cuda_engine(f.read())
        if self.engine is None:
            raise RuntimeError(f"TensorRT engine load failed: {engine_path}")
        self.context = self.engine.create_execution_context()
        self.input_name = self.engine.get_tensor_name(0)
        self.output_name = self.engine.get_tensor_name(1)
        self.input_tensor = torch.empty((1, 3, self.img_size, self.img_size), dtype=torch.float32, device="cuda")
        self.output_tensor = torch.empty((1, len(self.class_to_idx)), dtype=torch.float32, device="cuda")
        self.tf = transforms.Compose([
            transforms.Resize((self.img_size, self.img_size)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ])

    def preprocess(self, roi_bgr: np.ndarray) -> torch.Tensor:
        roi_rgb = cv2.cvtColor(roi_bgr, cv2.COLOR_BGR2RGB)
        pil_img = Image.fromarray(roi_rgb).convert("RGB")
        return self.tf(pil_img).unsqueeze(0)

    def predict(self, roi_bgr: np.ndarray) -> Tuple[str, float, Dict[str, float]]:
        x_cpu = self.preprocess(roi_bgr)
        self.input_tensor.copy_(x_cpu, non_blocking=True)
        self.context.set_tensor_address(self.input_name, int(self.input_tensor.data_ptr()))
        self.context.set_tensor_address(self.output_name, int(self.output_tensor.data_ptr()))
        ok = self.context.execute_async_v3(stream_handle=torch.cuda.current_stream().cuda_stream)
        if not ok:
            raise RuntimeError("TensorRT execute_async_v3 failed")
        torch.cuda.current_stream().synchronize()
        probs = torch.softmax(self.output_tensor[0], dim=0).detach().cpu().numpy()
        pred_idx = int(np.argmax(probs))
        pred_label = self.idx_to_class[pred_idx]
        conf = float(probs[pred_idx])
        prob_dict = {self.idx_to_class[i]: float(probs[i]) for i in range(len(probs))}
        return pred_label, conf, prob_dict


class DummyWaferClassifier:
    def __init__(self):
        self.positive_label = "wafer_exist"

    def predict(self, roi_bgr: np.ndarray) -> Tuple[str, float, Dict[str, float]]:
        return "no_wafer", 1.0, {"no_wafer": 1.0, "wafer_exist": 0.0}


def derive_final_status(left_empty: bool, right_empty: bool, left_pink_label: str, right_wafer_label: str, right_pink_label: str, wafer_positive_label: str) -> Tuple[str, str]:
    if (not right_empty) and (right_wafer_label == wafer_positive_label):
        return "WARNING", "Wafer detected inside RIGHT CST at cycle start"
    if left_empty or right_empty:
        return "INCOMPLETE", "At least one CST is EMPTY at cycle start"
    if left_pink_label not in ("pink", "non_pink"):
        return "UNKNOWN", "LEFT pink decision unknown"
    if right_pink_label not in ("pink", "non_pink"):
        return "UNKNOWN", "RIGHT pink decision unknown"
    if (left_pink_label == "pink") == (right_pink_label == "pink"):
        return "NORMAL", "Left/Right CST colors are matched"
    return "ABNORMAL", "Left/Right CST colors are mismatched"


class CycleStateMachine:
    WAIT = "WAIT_ANY_CST"
    STABILIZE = "STABILIZE"
    EVALUATE = "EVALUATE"
    LOCKED = "LOCKED"

    def __init__(self, stabilize_frames: int = 10, stabilize_timeout_frames: int = 60, reset_empty_frames: int = 5):
        self.state = self.WAIT
        self.stabilize_frames = max(1, stabilize_frames)
        self.stabilize_timeout_frames = max(self.stabilize_frames, stabilize_timeout_frames)
        self.reset_empty_frames = max(1, reset_empty_frames)
        self.both_non_empty_count = 0
        self.stabilize_elapsed = 0
        self.reset_empty_count = 0
        self.locked_status = "IDLE"
        self.locked_message = "Waiting for CST"
        self.locked_info = {}
        self.event_triggered = False
        self.review_saved = False

    def on_frame(self, left_empty: bool, right_empty: bool) -> str:
        any_non_empty = (not left_empty) or (not right_empty)
        both_non_empty = (not left_empty) and (not right_empty)
        any_empty = left_empty or right_empty
        if self.state == self.WAIT:
            self.locked_status = "IDLE"
            self.locked_message = "Waiting for Left/Right CST"
            self.locked_info = {}
            self.event_triggered = False
            self.review_saved = False
            if any_non_empty:
                self.state = self.STABILIZE
                self.both_non_empty_count = 1 if both_non_empty else 0
                self.stabilize_elapsed = 1
                self.reset_empty_count = 0
                print("[CYCLE] CST detected -> STABILIZE")
        elif self.state == self.STABILIZE:
            self.stabilize_elapsed += 1
            if both_non_empty:
                self.both_non_empty_count += 1
            else:
                self.both_non_empty_count = 0
            if self.both_non_empty_count >= self.stabilize_frames:
                self.state = self.EVALUATE
                print("[CYCLE] both CST stable -> EVALUATE")
            elif self.stabilize_elapsed >= self.stabilize_timeout_frames:
                self.state = self.EVALUATE
                print("[CYCLE] stabilize timeout -> EVALUATE")
        elif self.state == self.LOCKED:
            # WARNING은 우측 CST에 Wafer가 존재한다고 판정된 Cycle이므로
            # 이후 Wafer가 사라져도 우측 CST가 제거되어 Empty가 될 때까지 WARNING을 유지한다.
            if self.locked_status == "WARNING":
                reset_condition = right_empty
                reset_message = "Right CST removed after WARNING -> RESET"
            else:
                # NORMAL/ABNORMAL/UNKNOWN/INCOMPLETE는 좌/우 중 하나라도 Empty가 되면 Cycle 종료
                reset_condition = any_empty
                reset_message = "At least one CST removed -> RESET"

            if reset_condition:
                self.reset_empty_count += 1
                if self.reset_empty_count >= self.reset_empty_frames:
                    print(f"[CYCLE] {reset_message}")
                    self.reset()
            else:
                self.reset_empty_count = 0
        return self.state

    def lock(self, status: str, message: str, info: dict) -> None:
        self.locked_status = status
        self.locked_message = message
        self.locked_info = info
        self.event_triggered = False
        self.review_saved = False
        self.reset_empty_count = 0
        self.state = self.LOCKED
        print(f"[CYCLE] LOCKED status={status}, msg={message}")

    def reset(self) -> None:
        self.state = self.WAIT
        self.both_non_empty_count = 0
        self.stabilize_elapsed = 0
        self.reset_empty_count = 0
        self.locked_status = "IDLE"
        self.locked_message = "Waiting for Left/Right CST"
        self.locked_info = {}
        self.event_triggered = False


class AutoFrameCollector:
    """재학습 후보 프레임을 랜덤 및 이상 판정 기준으로 저장하고 용량을 제한한다.

    저장 구조
    - auto_frames/random/YYYYMMDD/{full,left,right,meta}
    - auto_frames/review_queue/{WARNING,ABNORMAL,UNKNOWN,INCOMPLETE}/YYYYMMDD/

    주의: review_queue의 라벨은 모델 예측값(pseudo label)이므로 사람이 검토한 뒤
    정식 frames 학습 폴더로 이동해야 한다.
    """

    REVIEW_STATUSES = {"WARNING", "ABNORMAL", "UNKNOWN", "INCOMPLETE"}

    def __init__(
        self,
        root_dir: Union[str, Path],
        enabled: bool = True,
        random_interval_sec: float = 30.0,
        random_probability: float = 0.2,
        max_total_gb: float = 5.0,
        random_quota_ratio: float = 0.8,
        storage_check_interval_sec: float = 600.0,
        min_free_gb: float = 5.0,
        jpeg_quality: int = 90,
    ):
        self.root_dir = ensure_dir(root_dir)
        self.random_root = ensure_dir(self.root_dir / "random")
        self.review_root = ensure_dir(self.root_dir / "review_queue")
        self.enabled = enabled
        self.random_interval_sec = max(1.0, random_interval_sec)
        self.random_probability = min(1.0, max(0.0, random_probability))
        self.max_total_bytes = int(max_total_gb * 1024 ** 3)
        self.random_max_bytes = int(self.max_total_bytes * random_quota_ratio)
        self.review_max_bytes = self.max_total_bytes - self.random_max_bytes
        self.storage_check_interval_sec = max(30.0, storage_check_interval_sec)
        self.min_free_bytes = int(min_free_gb * 1024 ** 3)
        self.jpeg_quality = int(min(100, max(50, jpeg_quality)))
        self.last_random_candidate_time = 0.0
        self.last_storage_check_time = 0.0
        self.random_save_paused = False

    @staticmethod
    def _dir_size(folder: Path) -> int:
        total = 0
        for p in folder.rglob("*"):
            if p.is_file():
                try:
                    total += p.stat().st_size
                except OSError:
                    pass
        return total

    @staticmethod
    def _files_oldest_first(folder: Path) -> List[Path]:
        files = [p for p in folder.rglob("*") if p.is_file()]
        files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0)
        return files

    def _enforce_quota(self, folder: Path, max_bytes: int) -> None:
        total = self._dir_size(folder)
        if total <= max_bytes:
            return
        for p in self._files_oldest_first(folder):
            if total <= max_bytes:
                break
            try:
                size = p.stat().st_size
                p.unlink()
                total -= size
                print(f"[AUTO_FRAME] quota delete: {p}")
            except OSError as e:
                print(f"[WARN] auto-frame quota delete failed: {p}, error={e}")

    def check_storage(self, force: bool = False) -> None:
        if not self.enabled:
            return
        now = time.time()
        if not force and now - self.last_storage_check_time < self.storage_check_interval_sec:
            return
        self.last_storage_check_time = now

        usage = shutil.disk_usage(self.root_dir)
        self.random_save_paused = usage.free < self.min_free_bytes
        if self.random_save_paused:
            print(f"[WARN] random frame save paused: free={usage.free / 1024 ** 3:.2f}GB")

        self._enforce_quota(self.random_root, self.random_max_bytes)
        self._enforce_quota(self.review_root, self.review_max_bytes)

    def _write_image(self, path: Path, image: np.ndarray) -> bool:
        path.parent.mkdir(parents=True, exist_ok=True)
        return bool(cv2.imwrite(str(path), image, [cv2.IMWRITE_JPEG_QUALITY, self.jpeg_quality]))

    @staticmethod
    def _write_json(path: Path, data: dict) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def _save_bundle(
        self,
        base_dir: Path,
        prefix: str,
        frame: np.ndarray,
        left_img: np.ndarray,
        right_img: np.ndarray,
        metadata: dict,
    ) -> Dict[str, str]:
        paths = {
            "full": base_dir / "full" / f"{prefix}_full.jpg",
            "left": base_dir / "left" / f"{prefix}_left.jpg",
            "right": base_dir / "right" / f"{prefix}_right.jpg",
            "meta": base_dir / "meta" / f"{prefix}.json",
        }
        self._write_image(paths["full"], frame)
        self._write_image(paths["left"], left_img)
        self._write_image(paths["right"], right_img)
        metadata = dict(metadata)
        metadata.update({k + "_path": str(v) for k, v in paths.items() if k != "meta"})
        self._write_json(paths["meta"], metadata)
        return {k: str(v) for k, v in paths.items()}

    def maybe_save_random(
        self,
        frame: np.ndarray,
        left_img: np.ndarray,
        right_img: np.ndarray,
        cycle_state: str,
        status: str,
        info: dict,
    ) -> Optional[Dict[str, str]]:
        if not self.enabled:
            return None
        now = time.time()
        if now - self.last_random_candidate_time < self.random_interval_sec:
            return None
        self.last_random_candidate_time = now
        self.check_storage()
        if self.random_save_paused or random.random() > self.random_probability:
            return None

        dt = datetime.now()
        prefix = dt.strftime("%Y%m%d_%H%M%S_%f")[:-3]
        base_dir = self.random_root / dt.strftime("%Y%m%d")
        metadata = {
            "timestamp": dt.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
            "collection_type": "random",
            "cycle_state": cycle_state,
            "status": status if cycle_state == CycleStateMachine.LOCKED else "UNLABELED",
            "pseudo_label": cycle_state == CycleStateMachine.LOCKED,
            "reviewed": False,
            **info,
        }
        saved = self._save_bundle(base_dir, prefix, frame, left_img, right_img, metadata)
        print(f"[AUTO_FRAME] random saved: {saved['full']}")
        return saved

    def save_review_case(
        self,
        status: str,
        frame: np.ndarray,
        left_img: np.ndarray,
        right_img: np.ndarray,
        info: dict,
        message: str,
    ) -> Optional[Dict[str, str]]:
        status = str(status).upper()
        if not self.enabled or status not in self.REVIEW_STATUSES:
            return None

        self.check_storage()
        usage = shutil.disk_usage(self.root_dir)
        if usage.free < 2 * 1024 ** 3:
            print("[WARN] review frame save skipped: free disk below 2GB")
            return None

        dt = datetime.now()
        prefix = dt.strftime("%Y%m%d_%H%M%S_%f")[:-3]
        base_dir = self.review_root / status / dt.strftime("%Y%m%d")
        metadata = {
            "timestamp": dt.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
            "collection_type": "review_queue",
            "status": status,
            "message": message,
            "pseudo_label": True,
            "reviewed": False,
            **info,
        }
        saved = self._save_bundle(base_dir, prefix, frame, left_img, right_img, metadata)
        print(f"[AUTO_FRAME] review saved: status={status}, path={saved['full']}")
        return saved


class EventClipRecorder:
    def __init__(self, event_dir: Union[str, Path], fps: float, frame_size: Tuple[int, int], pre_seconds: float = 10.0, post_seconds: float = 10.0, codec: str = "mp4v", cooldown_seconds: float = 10.0):
        self.event_dir = ensure_dir(event_dir)
        self.fps = float(fps)
        self.frame_size = frame_size
        self.pre_frames = max(1, int(round(self.fps * pre_seconds)))
        self.post_frames = max(1, int(round(self.fps * post_seconds)))
        self.codec = codec
        self.cooldown_seconds = cooldown_seconds
        self.pre_buffer: Deque[np.ndarray] = deque(maxlen=self.pre_frames)
        self.writer = None
        self.active_path = None
        self.remaining_post_frames = 0
        self.last_event_time = 0.0

    def append_pre_frame(self, frame: np.ndarray) -> None:
        self.pre_buffer.append(frame.copy())

    def trigger(self, event_type: str, frame: np.ndarray) -> Optional[Path]:
        now = time.time()
        if self.writer is not None:
            return None
        if (now - self.last_event_time) < self.cooldown_seconds:
            return None
        event_type = str(event_type).upper()
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = self.event_dir / f"{ts}_{event_type}.mp4"
        writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*self.codec), self.fps, self.frame_size)
        if not writer.isOpened():
            print(f"[WARN] event writer open failed: {path}")
            return None
        for buffered in self.pre_buffer:
            writer.write(buffered)
        writer.write(frame)
        self.writer = writer
        self.active_path = path
        self.remaining_post_frames = self.post_frames
        self.last_event_time = now
        print(f"[EVENT] clip started: {path}")
        return path

    def update(self, frame: np.ndarray) -> None:
        if self.writer is None:
            return
        if self.remaining_post_frames > 0:
            self.writer.write(frame)
            self.remaining_post_frames -= 1
        if self.remaining_post_frames <= 0:
            self.writer.release()
            print(f"[EVENT] clip saved: {self.active_path}")
            self.writer = None
            self.active_path = None

    def close(self) -> None:
        if self.writer is not None:
            self.writer.release()
            print(f"[EVENT] clip saved: {self.active_path}")
            self.writer = None
            self.active_path = None


def draw_transparent_box(img, pt1, pt2, color, alpha=0.35):
    overlay = img.copy()
    cv2.rectangle(overlay, pt1, pt2, color, -1)
    return cv2.addWeighted(overlay, alpha, img, 1 - alpha, 0)


def draw_overlay(frame, left_roi, right_roi, cycle_state, left_empty, right_empty, left_empty_score, right_empty_score, status, message, alarm_action, info, stabilize_info):
    out = frame.copy()
    for roi, name, empty, score in [(left_roi, "LEFT", left_empty, left_empty_score), (right_roi, "RIGHT", right_empty, right_empty_score)]:
        x, y, w, h = roi
        color = DISPLAY_COLORS["empty"] if empty else DISPLAY_COLORS["non_pink"]
        label = f"{name}: {'EMPTY' if empty else 'NON_EMPTY'} | e={score:.2f}"
        cv2.rectangle(out, (x, y), (x + w, y + h), color, 3)
        cv2.putText(out, label, (x, max(25, y - 10)), cv2.FONT_HERSHEY_SIMPLEX, 0.72, color, 2, cv2.LINE_AA)
    status_color = {"IDLE": DISPLAY_COLORS["idle"], "NORMAL": DISPLAY_COLORS["normal"], "INCOMPLETE": DISPLAY_COLORS["incomplete"], "UNKNOWN": DISPLAY_COLORS["unknown"], "ABNORMAL": DISPLAY_COLORS["abnormal"], "WARNING": DISPLAY_COLORS["warning"]}.get(status, (255, 255, 255))
    out = draw_transparent_box(out, (30, 30), (1420, 255), (0, 0, 0), alpha=0.58)
    cv2.rectangle(out, (30, 30), (1420, 255), status_color, 3)
    cv2.putText(out, f"STATE: {cycle_state}", (55, 75), cv2.FONT_HERSHEY_SIMPLEX, 0.95, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.putText(out, f"STATUS: {status}", (55, 120), cv2.FONT_HERSHEY_SIMPLEX, 1.15, status_color, 3, cv2.LINE_AA)
    cv2.putText(out, message[:110], (55, 160), cv2.FONT_HERSHEY_SIMPLEX, 0.72, status_color, 2, cv2.LINE_AA)
    cv2.putText(out, f"L_PINK={info.get('left_pink', 'unknown')} | R_WAFER={info.get('right_wafer_label', 'unknown')}({float(info.get('right_wafer_conf', 0.0)):.3f}) | R_PINK={info.get('right_pink', 'unknown')} | ALARM={alarm_action}", (55, 200), cv2.FONT_HERSHEY_SIMPLEX, 0.68, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.putText(out, stabilize_info[:115], (55, 235), cv2.FONT_HERSHEY_SIMPLEX, 0.62, (220, 220, 220), 2, cv2.LINE_AA)
    return out


def open_video_source(args) -> cv2.VideoCapture:
    if args.input_mode == "mp4":
        if not args.video_path:
            raise ValueError("--input_mode mp4 사용 시 --video_path가 필요합니다.")
        cap = cv2.VideoCapture(args.video_path)
    else:
        cap = cv2.VideoCapture(args.capture_index, cv2.CAP_V4L2 if args.capture_backend == "v4l2" else 0)
        if args.fourcc:
            cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*args.fourcc))
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.capture_width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.capture_height)
        cap.set(cv2.CAP_PROP_FPS, args.capture_fps)
    if not cap.isOpened():
        raise RuntimeError(f"video source open failed: mode={args.input_mode}")
    return cap


def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="RMV CST Both-CST Cycle Lock Final Inference")
    p.add_argument("--input_mode", choices=["capture", "mp4"], default="capture")
    p.add_argument("--video_path", default="")
    p.add_argument("--capture_index", type=int, default=0)
    p.add_argument("--capture_backend", choices=["default", "v4l2"], default="v4l2")
    p.add_argument("--capture_width", type=int, default=1920)
    p.add_argument("--capture_height", type=int, default=1080)
    p.add_argument("--capture_fps", type=float, default=30.0)
    p.add_argument("--fourcc", default="MJPG")
    p.add_argument("--left_roi", nargs=4, type=int, default=list(DEFAULT_LEFT_ROI))
    p.add_argument("--right_roi", nargs=4, type=int, default=list(DEFAULT_RIGHT_ROI))
    p.add_argument("--reference_empty_dir", default=str(DEFAULT_REFERENCE_EMPTY_DIR))
    p.add_argument("--left_empty_threshold", type=float, default=DEFAULT_LEFT_EMPTY_THRESHOLD)
    p.add_argument("--right_empty_threshold", type=float, default=DEFAULT_RIGHT_EMPTY_THRESHOLD)
    p.add_argument("--empty_center_crop_ratio", type=float, default=0.7)
    p.add_argument("--color_center_crop_ratio", type=float, default=0.8)
    p.add_argument("--blur_ksize", type=int, default=5)
    p.add_argument("--pink_rule_file", default=str(DEFAULT_PINK_RULE_FILE))
    p.add_argument("--engine_path", default=str(DEFAULT_ENGINE_PATH))
    p.add_argument("--meta_path", default=str(DEFAULT_META_PATH))
    p.add_argument("--wafer_conf_threshold", type=float, default=0.5)
    p.add_argument("--disable_wafer_model", type=str2bool, default=False)
    p.add_argument("--wafer_check_interval", type=int, default=2)
    p.add_argument("--empty_hold_frames", type=int, default=5)
    p.add_argument("--stabilize_frames", type=int, default=10)
    p.add_argument("--stabilize_timeout_frames", type=int, default=60)
    p.add_argument("--reset_empty_frames", type=int, default=5)
    p.add_argument("--use_patlite", type=str2bool, default=False)
    p.add_argument("--event_dir", default=str(DEFAULT_EVENT_DIR))
    p.add_argument("--event_pre_seconds", type=float, default=10.0)
    p.add_argument("--event_post_seconds", type=float, default=10.0)
    p.add_argument("--event_cooldown_seconds", type=float, default=10.0)
    p.add_argument("--event_codec", default="mp4v")
    p.add_argument("--log_dir", default=str(DEFAULT_LOG_DIR))
    p.add_argument("--history_dir", default=str(DEFAULT_HISTORY_DIR))
    p.add_argument("--keep_log_days", type=int, default=7)
    p.add_argument("--log_every_n_frames", type=int, default=1)

    p.add_argument("--enable_auto_frame_save", type=str2bool, default=True)
    p.add_argument("--auto_frame_dir", default=str(DEFAULT_AUTO_FRAME_DIR))
    p.add_argument("--random_save_interval_sec", type=float, default=30.0)
    p.add_argument("--random_save_probability", type=float, default=0.2)
    p.add_argument("--auto_frame_max_gb", type=float, default=5.0)
    p.add_argument("--random_quota_ratio", type=float, default=0.8)
    p.add_argument("--storage_check_interval_sec", type=float, default=600.0)
    p.add_argument("--min_free_gb", type=float, default=5.0)
    p.add_argument("--auto_frame_jpeg_quality", type=int, default=90)
    p.add_argument("--show_window", type=str2bool, default=False)
    p.add_argument("--display_scale", type=float, default=0.5)
    p.add_argument("--max_frames", type=int, default=-1)
    return p


def main() -> None:
    args = build_argparser().parse_args()
    left_roi = parse_roi(args.left_roi)
    right_roi = parse_roi(args.right_roi)
    log_dir = ensure_dir(args.log_dir)
    history_dir = ensure_dir(args.history_dir)
    event_dir = ensure_dir(args.event_dir)
    cleanup_old_files(log_dir, keep_days=args.keep_log_days)
    cleanup_old_files(history_dir, keep_days=args.keep_log_days)
    refs = load_empty_refs(args.reference_empty_dir, args.empty_center_crop_ratio, args.blur_ksize)
    if not refs["left"]:
        raise FileNotFoundError(f"left empty reference not found: {Path(args.reference_empty_dir) / 'left'}")
    if not refs["right"]:
        raise FileNotFoundError(f"right empty reference not found: {Path(args.reference_empty_dir) / 'right'}")
    pink_rules = normalize_rule_config(safe_json_load(args.pink_rule_file))
    wafer_classifier = DummyWaferClassifier() if args.disable_wafer_model else TensorRTWaferClassifier(args.engine_path, args.meta_path)
    patlite = PatliteLR6USBController(enabled=args.use_patlite)
    cap = open_video_source(args)
    fps = cap.get(cv2.CAP_PROP_FPS)
    if not fps or math.isnan(fps) or fps <= 0:
        fps = args.capture_fps if args.capture_fps > 0 else 30.0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or args.capture_width)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or args.capture_height)
    frame_size = (width, height)
    print(f"[INFO] source opened: mode={args.input_mode}, {width}x{height}, fps={fps:.2f}")
    print(f"[INFO] left_roi={left_roi}, right_roi={right_roi}")
    print(f"[INFO] cycle: stabilize_frames={args.stabilize_frames}, stabilize_timeout_frames={args.stabilize_timeout_frames}, reset_empty_frames={args.reset_empty_frames}")
    event_recorder = EventClipRecorder(event_dir=event_dir, fps=fps, frame_size=frame_size, pre_seconds=args.event_pre_seconds, post_seconds=args.event_post_seconds, codec=args.event_codec, cooldown_seconds=args.event_cooldown_seconds)
    cycle = CycleStateMachine(stabilize_frames=args.stabilize_frames, stabilize_timeout_frames=args.stabilize_timeout_frames, reset_empty_frames=args.reset_empty_frames)
    left_empty_hold = BoolHoldState(True, True, 0)
    right_empty_hold = BoolHoldState(True, True, 0)
    frame_logger = DailyCsvLogger(log_dir, prefix="frame_results", keep_days=args.keep_log_days)
    event_logger = DailyCsvLogger(log_dir, prefix="event_summary", keep_days=args.keep_log_days)
    run_logger = DailyCsvLogger(history_dir, prefix="run_status", keep_days=args.keep_log_days)
    auto_collector = AutoFrameCollector(
        root_dir=args.auto_frame_dir,
        enabled=args.enable_auto_frame_save,
        random_interval_sec=args.random_save_interval_sec,
        random_probability=args.random_save_probability,
        max_total_gb=args.auto_frame_max_gb,
        random_quota_ratio=args.random_quota_ratio,
        storage_check_interval_sec=args.storage_check_interval_sec,
        min_free_gb=args.min_free_gb,
        jpeg_quality=args.auto_frame_jpeg_quality,
    )
    auto_collector.check_storage(force=True)
    run_logger.write({
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "event": "RUN_START",
        "input_mode": args.input_mode,
        "video_path": args.video_path,
        "left_roi": str(list(left_roi)),
        "right_roi": str(list(right_roi)),
        "engine_path": str(args.engine_path),
        "pink_rule_file": str(args.pink_rule_file),
        "auto_frame_dir": str(args.auto_frame_dir),
        "auto_frame_max_gb": args.auto_frame_max_gb,
    })
    frame_log_count = 0
    event_log_count = 0
    frame_idx = -1
    try:
        while True:
            ok, frame = cap.read()
            if not ok or frame is None:
                if args.input_mode == "mp4":
                    print("[INFO] mp4 end")
                    break
                print("[WARN] frame read failed")
                time.sleep(0.05)
                continue
            frame_idx += 1
            if args.max_frames > 0 and frame_idx >= args.max_frames:
                break
            t0 = time.perf_counter()
            left_img = crop_roi(frame, left_roi)
            right_img = crop_roi(frame, right_roi)
            le_raw, le_score = predict_empty(left_img, refs["left"], args.left_empty_threshold, args.empty_center_crop_ratio, args.blur_ksize)
            re_raw, re_score = predict_empty(right_img, refs["right"], args.right_empty_threshold, args.empty_center_crop_ratio, args.blur_ksize)
            left_empty_hold = update_hold_bool(left_empty_hold, le_raw, args.empty_hold_frames)
            right_empty_hold = update_hold_bool(right_empty_hold, re_raw, args.empty_hold_frames)
            left_empty = left_empty_hold.stable_label
            right_empty = right_empty_hold.stable_label
            current_state = cycle.on_frame(left_empty=left_empty, right_empty=right_empty)
            status = cycle.locked_status
            message = cycle.locked_message
            info = dict(cycle.locked_info)
            if current_state == CycleStateMachine.STABILIZE:
                status = "IDLE"
                message = "CST detected. Stabilizing before color evaluation"
                info = {}

                # 1st priority rule:
                # Right CST가 NonEmpty이면 좌/우 안정화 완료 여부와 무관하게 Wafer 존재 여부를 즉시 확인한다.
                # Wafer Exist로 판정되면 즉시 WARNING으로 Lock하고, Right CST가 Empty가 될 때까지 유지한다.
                if (not right_empty) and (frame_idx % max(1, args.wafer_check_interval) == 0):
                    _, _, wafer_probs = wafer_classifier.predict(right_img)
                    wafer_prob = float(wafer_probs.get(wafer_classifier.positive_label, 0.0))
                    right_wafer_label = (
                        wafer_classifier.positive_label
                        if wafer_prob >= args.wafer_conf_threshold
                        else "no_wafer"
                    )

                    if right_wafer_label == wafer_classifier.positive_label:
                        status = "WARNING"
                        message = "Wafer detected inside RIGHT CST before color evaluation"
                        info = {
                            "left_pink": "unknown",
                            "right_pink": "unknown",
                            "right_wafer_label": right_wafer_label,
                            "right_wafer_conf": wafer_prob,
                            "left_empty_at_eval": left_empty,
                            "right_empty_at_eval": right_empty,
                            "left_empty_score_at_eval": le_score,
                            "right_empty_score_at_eval": re_score,
                            "wafer_check_stage": "STABILIZE_IMMEDIATE",
                        }
                        cycle.lock(status=status, message=message, info=info)
                        if not cycle.review_saved:
                            auto_collector.save_review_case(status, frame, left_img, right_img, info, message)
                            cycle.review_saved = True

            if current_state == CycleStateMachine.EVALUATE:
                left_pink = "unknown"
                right_pink = "unknown"
                right_wafer_label = "unknown"
                right_wafer_conf = 0.0
                if not left_empty:
                    left_pink, _, _ = predict_pink(left_img, "left", pink_rules, args.color_center_crop_ratio, args.blur_ksize)
                if not right_empty:
                    _, _, wafer_probs = wafer_classifier.predict(right_img)
                    wafer_prob = float(wafer_probs.get(wafer_classifier.positive_label, 0.0))
                    right_wafer_label = wafer_classifier.positive_label if wafer_prob >= args.wafer_conf_threshold else "no_wafer"
                    right_wafer_conf = wafer_prob
                    if right_wafer_label != wafer_classifier.positive_label:
                        right_pink, _, _ = predict_pink(right_img, "right", pink_rules, args.color_center_crop_ratio, args.blur_ksize)
                status, message = derive_final_status(left_empty=left_empty, right_empty=right_empty, left_pink_label=left_pink, right_wafer_label=right_wafer_label, right_pink_label=right_pink, wafer_positive_label=wafer_classifier.positive_label)
                info = {"left_pink": left_pink, "right_pink": right_pink, "right_wafer_label": right_wafer_label, "right_wafer_conf": right_wafer_conf, "left_empty_at_eval": left_empty, "right_empty_at_eval": right_empty, "left_empty_score_at_eval": le_score, "right_empty_score_at_eval": re_score}
                cycle.lock(status=status, message=message, info=info)
                if not cycle.review_saved and status in AutoFrameCollector.REVIEW_STATUSES:
                    auto_collector.save_review_case(status, frame, left_img, right_img, info, message)
                    cycle.review_saved = True
            alarm_action = alarm_from_status(status)
            patlite.set_alarm(alarm_action)
            infer_ms = (time.perf_counter() - t0) * 1000.0
            stabilize_info = f"both_non_empty_count={cycle.both_non_empty_count}/{cycle.stabilize_frames}, reset_empty_count={cycle.reset_empty_count}/{cycle.reset_empty_frames}"
            overlay = draw_overlay(frame=frame, left_roi=left_roi, right_roi=right_roi, cycle_state=cycle.state, left_empty=left_empty, right_empty=right_empty, left_empty_score=le_score, right_empty_score=re_score, status=status, message=message, alarm_action=alarm_action, info=info, stabilize_info=stabilize_info)
            event_recorder.append_pre_frame(overlay)
            if cycle.state == CycleStateMachine.LOCKED and status in ("WARNING", "ABNORMAL") and not cycle.event_triggered:
                event_path = event_recorder.trigger(status, overlay)
                cycle.event_triggered = True
                if event_path is not None:
                    event_logger.write({"time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "frame_idx": frame_idx, "event_type": status, "clip_path": str(event_path), "message": message})
                    event_log_count += 1
            event_recorder.update(overlay)
            auto_collector.maybe_save_random(
                frame=frame,
                left_img=left_img,
                right_img=right_img,
                cycle_state=cycle.state,
                status=status,
                info=info,
            )
            if args.show_window:
                display = overlay
                if args.display_scale != 1.0:
                    display = cv2.resize(overlay, None, fx=args.display_scale, fy=args.display_scale, interpolation=cv2.INTER_AREA)
                cv2.imshow("RMV CST Both-CST Cycle Inference", display)
                key = cv2.waitKey(1) & 0xFF
                if key in (27, ord("q")):
                    break
            if frame_idx % max(1, args.log_every_n_frames) == 0:
                frame_logger.write({"time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "frame_idx": frame_idx, "cycle_state": cycle.state, "both_non_empty_count": cycle.both_non_empty_count, "reset_empty_count": cycle.reset_empty_count, "inference_time_ms": round(float(infer_ms), 3), "left_empty": left_empty, "right_empty": right_empty, "left_empty_score": round(float(le_score), 6), "right_empty_score": round(float(re_score), 6), "status": status, "message": message, "alarm_action": alarm_action, "left_pink": info.get("left_pink", ""), "right_pink": info.get("right_pink", ""), "right_wafer_label": info.get("right_wafer_label", ""), "right_wafer_conf": round(float(info.get("right_wafer_conf", 0.0)), 6)})
                frame_log_count += 1
    except KeyboardInterrupt:
        print("[INFO] interrupted by user")
    finally:
        cap.release()
        event_recorder.close()
        patlite.cleanup()
        if args.show_window:
            cv2.destroyAllWindows()
        try:
            run_logger.write({
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "event": "RUN_END",
                "input_mode": args.input_mode,
                "video_path": args.video_path,
                "frame_log_count": frame_log_count,
                "event_log_count": event_log_count,
                "left_empty_threshold": args.left_empty_threshold,
                "right_empty_threshold": args.right_empty_threshold,
                "stabilize_frames": args.stabilize_frames,
                "stabilize_timeout_frames": args.stabilize_timeout_frames,
                "reset_empty_frames": args.reset_empty_frames,
                "empty_hold_frames": args.empty_hold_frames,
                "wafer_check_interval": args.wafer_check_interval,
            })
        except Exception as e:
            print(f"[WARN] run end log failed: {e}")
        print("[DONE] realtime daily logs updated")
        print(f"- logs: {log_dir}")
        print(f"- history: {history_dir}")
        print("=== DONE ===")


if __name__ == "__main__":
    main()
