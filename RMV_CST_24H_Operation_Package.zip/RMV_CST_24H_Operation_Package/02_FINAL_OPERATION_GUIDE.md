# RMV CST 24시간 최종 운영 방식

## 1. 전체 구조

```text
전원 인가
  ↓
Jetson 자동 부팅
  ↓
rmv_cst.service
  ├─ HDMI-USB 실시간 영상 수신
  ├─ Empty / Pink / Wafer 판정
  ├─ PATLITE 알람
  ├─ 이상 이벤트 전후 10초 영상 저장
  ├─ 일 단위 실시간 CSV 로그
  ├─ 랜덤 재학습 프레임 수집
  └─ 이상 판정 프레임 Review Queue 저장

rmv_cst_thermal_watchdog.service
  ├─ 75°C 경고
  ├─ 82°C 추론 중지
  ├─ 75°C 이하 추론 재개
  └─ 88°C 60초 지속 시 Jetson 재부팅
```

## 2. 추론 Cycle 로직

### 2.1 Cycle 시작

좌/우 CST 중 하나라도 `Empty → NonEmpty`가 되면 `STABILIZE`로 들어간다.

### 2.2 우측 Wafer 최우선 판정

`STABILIZE` 중 우측 CST가 NonEmpty이면 좌우 색상 안정화 여부와 관계없이 Wafer 모델을 실행한다.

- Wafer Exist: 즉시 `WARNING` Lock
- WARNING 상태는 **우측 CST가 Empty로 돌아올 때까지 유지**
- WARNING Lock 후에는 Pink/Wafer 재판정을 중지

### 2.3 색상 판정

Wafer가 검출되지 않은 경우, 좌우 CST가 모두 NonEmpty 상태로 설정 프레임 수만큼 안정화되면 색상을 한 번 판정한다.

| Left | Right | 결과 |
|---|---|---|
| Pink | Pink | NORMAL |
| NonPink | NonPink | NORMAL |
| Pink | NonPink | ABNORMAL |
| NonPink | Pink | ABNORMAL |
| 한쪽이라도 Unknown | - | UNKNOWN |
| 안정화 제한까지 한쪽 Empty | - | INCOMPLETE |

### 2.4 Status 유지와 Reset

- WARNING: 우측 CST가 Empty가 된 상태가 `reset_empty_frames`만큼 지속되면 Reset
- 그 외 Status: 좌우 중 하나라도 Empty가 된 상태가 `reset_empty_frames`만큼 지속되면 Reset

## 3. 알람 정책

- WARNING: PATLITE 빨간불 점멸 + 부저 2단계
- ABNORMAL: PATLITE 주황불 점멸 + 부저 1단계
- NORMAL / UNKNOWN / INCOMPLETE / IDLE: 알람 해제

## 4. 이벤트 영상

WARNING 또는 ABNORMAL이 한 Cycle에서 최초 확정될 때만 저장한다.

```text
event/YYYYMMDD_HHMMSS_WARNING.mp4
event/YYYYMMDD_HHMMSS_ABNORMAL.mp4
```

기본 구성:

- 발생 전 Overlay 10초
- 발생 후 Overlay 10초
- `event/`는 자동 삭제하지 않음

이벤트 파일은 무기한 누적될 수 있으므로 월 1회 이상 별도 백업 또는 디스크 사용량 점검이 필요하다.

## 5. 실시간 로그

프로그램 종료 시 일괄 생성하지 않고 실행 중 계속 append한다.

```text
logs/frame_results_YYYYMMDD.csv
logs/event_summary_YYYYMMDD.csv
history/run_status_YYYYMMDD.csv
logs/thermal/thermal_watchdog_YYYYMMDD.log
```

- 날짜가 바뀌면 자동으로 새 파일 생성
- 추론 로그와 history는 기본 7일 보관
- 온도 로그는 기본 30일 보관
- CSV는 write마다 flush하여 비정상 종료 시 손실 범위를 줄임

## 6. 재학습용 프레임 자동 수집

### 6.1 저장 구조

```text
auto_frames/
├── random/YYYYMMDD/
│   ├── full/
│   ├── left/
│   ├── right/
│   └── meta/
└── review_queue/
    ├── WARNING/YYYYMMDD/
    ├── ABNORMAL/YYYYMMDD/
    ├── UNKNOWN/YYYYMMDD/
    └── INCOMPLETE/YYYYMMDD/
```

### 6.2 랜덤 수집

기본 정책:

- 30초마다 저장 후보 발생
- 후보 중 20% 확률로 저장
- 평균 약 150초당 한 번 저장
- Full Frame, Left ROI, Right ROI, JSON metadata를 함께 저장

LOCKED 상태가 아닌 랜덤 프레임은 `UNLABELED`로 저장한다.

### 6.3 이상 판정 수집

WARNING, ABNORMAL, UNKNOWN, INCOMPLETE가 확정되면 해당 Cycle에서 한 번 저장한다.

JSON에는 다음 항목이 포함된다.

- 판정 시각
- status와 message
- left/right empty 상태와 score
- left/right pink 판정
- right wafer label과 confidence
- `pseudo_label: true`
- `reviewed: false`

자동 라벨은 정답이 아니라 **pseudo label**이다. 사람이 확인하기 전에는 `frames/right/wafer_exist` 같은 정식 학습 폴더로 직접 합치지 않는다.

### 6.4 용량 관리

기본 총량: 약 5GB

- random: 80%, 약 4GB
- review_queue: 20%, 약 1GB
- 각 영역에서 오래된 파일부터 삭제
- 남은 디스크가 5GB 미만이면 랜덤 수집 일시 중지
- 남은 디스크가 2GB 미만이면 review 저장도 생략
- event 폴더는 이 정책의 대상이 아님

## 7. 발열 대책

### 하드웨어

- Jetson 정품 또는 충분한 풍량의 팬 사용
- 방열판 먼지 제거
- 밀폐함 내부 사용 시 흡기·배기 통풍구 확보
- HDMI 캡처카드와 Jetson 전원 어댑터 주변 열원 분리
- 케이블이 팬 흡입구를 막지 않도록 고정

### 소프트웨어 Watchdog

| 조건 | 동작 |
|---|---|
| 75°C 이상 | 경고 로그 |
| 82°C 이상 | 추론 서비스 중지, 냉각 시작 |
| 냉각 중 75°C 이하 | 추론 서비스 재시작 |
| 88°C 이상 60초 지속 | Jetson 재부팅 |

82°C 중지와 75°C 재개의 차이는 서비스가 반복적으로 켜지고 꺼지는 현상을 막는 히스테리시스다.

## 8. 권장 Jetson 점검 명령

```bash
tegrastats
```

```bash
cat /sys/class/thermal/thermal_zone*/type
cat /sys/class/thermal/thermal_zone*/temp
```

```bash
sudo nvpmodel -q
```

전력 모드를 바꾸기 전에는 현장 처리 속도와 온도를 함께 비교 테스트한다. 임의로 최고 성능 모드를 고정하기보다는 현재 추론 주기를 만족하는 가장 낮은 전력 모드를 선택하는 것이 좋다.

## 9. 일상 점검 주기

매일 또는 교대 시:

- 서비스 `active (running)` 확인
- PATLITE 연결 로그 확인
- 캡처카드 프레임 수신 확인
- 전일 WARNING/ABNORMAL 이벤트 확인

주 1회:

- `df -h`
- `du -sh event auto_frames logs history`
- 팬 회전 및 먼지 확인
- thermal watchdog 로그에서 75°C 이상 빈도 확인

월 1회:

- event 영상 외부 백업 또는 보존 정책 검토
- review_queue 수동 검토 및 정식 학습 데이터 반영
- 모델 재검증 여부 판단
