#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""RMV CST Jetson 온도 감시 Watchdog.

정책
- 75°C 이상: 경고 로그
- 82°C 이상: rmv_cst.service 중지 후 냉각 모드
- 냉각 중 75°C 이하: rmv_cst.service 재시작
- 88°C 이상이 60초 지속: 추론 서비스 중지 후 Jetson 재부팅
- 로그는 일 단위 파일로 기록하며 N일 지난 파일은 자동 삭제
"""

from __future__ import annotations

import argparse
import subprocess
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Optional


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def cleanup_old_logs(folder: Path, keep_days: int) -> None:
    cutoff = datetime.now() - timedelta(days=keep_days)
    for p in folder.glob("thermal_watchdog_*.log"):
        try:
            if datetime.fromtimestamp(p.stat().st_mtime) < cutoff:
                p.unlink()
        except OSError:
            pass


class DailyLogger:
    def __init__(self, folder: str | Path, keep_days: int = 30):
        self.folder = ensure_dir(folder)
        self.keep_days = keep_days
        self.current_date: Optional[str] = None

    def write(self, message: str) -> None:
        today = datetime.now().strftime("%Y%m%d")
        if self.current_date != today:
            self.current_date = today
            cleanup_old_logs(self.folder, self.keep_days)
        line = f"{datetime.now():%Y-%m-%d %H:%M:%S} {message}"
        print(line, flush=True)
        with open(self.folder / f"thermal_watchdog_{today}.log", "a", encoding="utf-8") as f:
            f.write(line + "\n")
            f.flush()


def read_thermal_zones() -> Dict[str, float]:
    result: Dict[str, float] = {}
    base = Path("/sys/class/thermal")
    for zone in sorted(base.glob("thermal_zone*")):
        try:
            zone_type = (zone / "type").read_text().strip()
            raw = float((zone / "temp").read_text().strip())
            temp_c = raw / 1000.0 if raw > 1000 else raw
            result[zone_type] = temp_c
        except (OSError, ValueError):
            continue
    return result


def max_temp(zones: Dict[str, float]) -> float:
    return max(zones.values()) if zones else -1.0


def run_systemctl(action: str, service: str, logger: DailyLogger) -> bool:
    completed = subprocess.run(
        ["systemctl", action, service],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        logger.write(
            f"SYSTEMCTL_FAIL action={action} service={service} "
            f"returncode={completed.returncode} stderr={completed.stderr.strip()}"
        )
        return False
    logger.write(f"SYSTEMCTL_OK action={action} service={service}")
    return True


def is_service_active(service: str) -> bool:
    completed = subprocess.run(
        ["systemctl", "is-active", "--quiet", service],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    return completed.returncode == 0


def reboot(logger: DailyLogger) -> None:
    logger.write("CRITICAL_REBOOT_REQUEST")
    subprocess.run(["systemctl", "reboot"], check=False)


def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="RMV CST thermal watchdog")
    p.add_argument("--service", default="rmv_cst.service")
    p.add_argument("--log_dir", default="/home/fab1innfo/rmv_cst/logs/thermal")
    p.add_argument("--keep_log_days", type=int, default=30)
    p.add_argument("--check_interval_sec", type=float, default=10.0)
    p.add_argument("--warn_temp", type=float, default=75.0)
    p.add_argument("--pause_temp", type=float, default=82.0)
    p.add_argument("--resume_temp", type=float, default=75.0)
    p.add_argument("--reboot_temp", type=float, default=88.0)
    p.add_argument("--reboot_hold_sec", type=float, default=60.0)
    p.add_argument("--log_every_checks", type=int, default=6)
    return p


def main() -> None:
    args = build_argparser().parse_args()
    logger = DailyLogger(args.log_dir, keep_days=args.keep_log_days)

    cooling = False
    critical_started_at: Optional[float] = None
    check_count = 0

    logger.write(
        "WATCHDOG_START "
        f"warn={args.warn_temp} pause={args.pause_temp} resume={args.resume_temp} "
        f"reboot={args.reboot_temp} hold={args.reboot_hold_sec}s service={args.service}"
    )

    while True:
        zones = read_thermal_zones()
        temp = max_temp(zones)
        check_count += 1

        if check_count % max(1, args.log_every_checks) == 0:
            zone_text = ",".join(f"{k}={v:.1f}" for k, v in sorted(zones.items()))
            logger.write(f"TEMP max={temp:.1f}C cooling={cooling} zones=[{zone_text}]")

        if temp < 0:
            logger.write("TEMP_READ_FAIL no thermal zone detected")
            time.sleep(args.check_interval_sec)
            continue

        if temp >= args.reboot_temp:
            if critical_started_at is None:
                critical_started_at = time.monotonic()
                logger.write(f"CRITICAL_TEMP_START max={temp:.1f}C")

            if not cooling:
                if is_service_active(args.service):
                    run_systemctl("stop", args.service, logger)
                cooling = True

            critical_elapsed = time.monotonic() - critical_started_at
            if critical_elapsed >= args.reboot_hold_sec:
                logger.write(
                    f"CRITICAL_TEMP_PERSIST max={temp:.1f}C elapsed={critical_elapsed:.1f}s"
                )
                reboot(logger)
                time.sleep(300)

        else:
            critical_started_at = None

            if temp >= args.pause_temp:
                if not cooling:
                    logger.write(f"COOLING_START max={temp:.1f}C")
                    if is_service_active(args.service):
                        run_systemctl("stop", args.service, logger)
                    cooling = True

            elif cooling and temp <= args.resume_temp:
                logger.write(f"COOLING_END max={temp:.1f}C")
                run_systemctl("start", args.service, logger)
                cooling = False

            elif temp >= args.warn_temp and not cooling:
                logger.write(f"TEMP_WARNING max={temp:.1f}C")

            elif not cooling and not is_service_active(args.service):
                logger.write("SERVICE_INACTIVE_OUTSIDE_COOLING restart requested")
                run_systemctl("start", args.service, logger)

        time.sleep(args.check_interval_sec)


if __name__ == "__main__":
    main()
