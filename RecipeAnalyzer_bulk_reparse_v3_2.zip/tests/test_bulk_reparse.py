"""독립 전체 Recipe 재파싱 스크립트 회귀 테스트."""
from __future__ import annotations

from argparse import Namespace
from types import SimpleNamespace

import pandas as pd
import pytest

import parse_all_recipes as bulk


def _opts(tmp_path, *cli):
    """테스트 전용 백업 경로와 실행 옵션을 구성한다."""
    return bulk.parse_arguments(["--data-base-dir", str(tmp_path), "--batch-size", "2", *cli])


def _setup_db(monkeypatch, rows, *, error_recipies=()):
    """PostgresCRUD를 모의화해 키셋 조회, 저장, 실패 상태를 검증한다."""
    state = {r["recipe_key"]: dict(r) for r in rows}
    saved = []
    errors = []
    queries = []

    def fake_select(sql, params):
        """실제 SQL 조건에 대응하는 소규모 메모리 조회를 수행한다."""
        queries.append((sql, params))
        last = params[0]
        picked = [r for r in state.values()
                  if r["recipe_key"] > last
                  and r.get("backup_file_path") is not None
                  and r["backup_file_path"].strip()]
        if "equip = ANY(%s)" in sql:
            picked = [r for r in picked if r["equip"] in params[1]]
        if "COALESCE(is_remove, FALSE)" in sql:
            picked = [r for r in picked if not r.get("is_remove")]
        if "parse_status IS DISTINCT FROM 'success'" in sql:
            picked = [r for r in picked if r.get("parse_status") != "success"]
        picked.sort(key=lambda x:x["recipe_key"])
        return pd.DataFrame(picked[:params[-1]])

    def fake_replace(results):
        """정상 트랜잭션과 오류 트랜잭션을 모의 처리한다."""
        if any(key in error_recipies for key, _ in results):
            raise ValueError("unrepresentable value")
        for key, para in results:
            saved.append((key, para))
            state[key]["parse_status"] = "success"
            state[key]["parse_error"] = None
        return len(results)

    def fake_fail(key, error):
        """파싱 오류 상태를 개별 Recipe에 기록한다."""
        errors.append((key,error))
        state[key]["parse_status"] = "failed"
        state[key]["parse_error"] = error

    monkeypatch.setattr(bulk.PostgresCRUD, "select_query", fake_select)
    monkeypatch.setattr(bulk.PostgresCRUD, "replace_recipe_parameters", fake_replace)
    monkeypatch.setattr(bulk.PostgresCRUD, "mark_parse_failure", fake_fail)
    return state, saved, errors, queries


def test_all_includes_existing_success_and_logically_removed(monkeypatch, tmp_path):
    """전체 재파싱 모드는 기존 success 및 논리 삭제 Recipe도 포함한다."""
    rows = [
        dict(recipe_key="A", equip="SMDI01", model="KLA2139", backup_file_path="/SMDI01/A/ins.dat", parse_status="success", is_remove=False),
        dict(recipe_key="B", equip="SMDI01", model="KLA2139", backup_file_path="/SMDI01/B/ins.dat", parse_status=None, is_remove=False),
        dict(recipe_key="C", equip="SMDI01", model="KLA2139", backup_file_path="/SMDI01/C/ins.dat", parse_status="failed", is_remove=True),
        dict(recipe_key="D", equip="SMDI01", model="KLA2139", backup_file_path="", parse_status=None, is_remove=False),
        dict(recipe_key="E", equip="SMDI01", model="KLA2139", backup_file_path=None, parse_status=None, is_remove=False),
    ]
    state, saved, errors, queries = _setup_db(monkeypatch, rows)
    monkeypatch.setattr(bulk, "parse_item", lambda item, root, cache: {"pixel": "0.6"})
    monkeypatch.setattr(bulk, "__file__", str(tmp_path / "parse_all_recipes.py"))

    result = bulk.run_bulk_parse(_opts(tmp_path))
    assert (result.scanned, result.success, result.failed) == (3, 3, 0)
    assert [key for key, _ in saved] == ["A", "B", "C"]
    assert [state[k]["parse_status"] for k in "ABC"] == ["success"] * 3
    assert "BTRIM(backup_file_path)" in queries[0][0]
    assert len(queries) == 3
    assert not errors


def test_parse_failure_is_recorded_and_success_batch_saved(monkeypatch, tmp_path):
    """한 Recipe의 파싱 실패가 나머지 성공 건의 DB 저장을 막지 않는다."""
    rows = [
        dict(recipe_key=k, equip="SMDI01", model="KLA2139", backup_file_path=f"/{k}.dat", parse_status=None)
        for k in "ABC"
    ]
    state, saved, errors, _ = _setup_db(monkeypatch, rows)

    def parse_one_item(item, root, cache):
        """Recipe B의 파싱을 일부러 실패하게 한다."""
        if item.recipe_key == "B":
            raise FileNotFoundError("missing backup")
        return {"pixel": "1.2"}

    monkeypatch.setattr(bulk, "parse_item", parse_one_item)
    monkeypatch.setattr(bulk, "__file__", str(tmp_path / "parse_all_recipes.py"))
    result = bulk.run_bulk_parse(_opts(tmp_path))
    assert (result.success, result.failed, result.parse_failed) == (2, 1, 1)
    assert state["B"]["parse_status"] == "failed"
    assert [x[0] for x in saved] == ["A", "C"]
    assert errors[0][0] == "B"
    assert list(tmp_path.glob("logs/bulk_parse_failed_*.csv"))


def test_db_batch_failure_falls_back_to_individual_recipe(monkeypatch, tmp_path):
    """DB 배치 저장 실패 시 한 건씩 다시 저장해 오류 Recipe만 실패 표시한다."""
    rows = [
        dict(recipe_key=k, equip="SMDI01", model="KLA2139", backup_file_path=f"/{k}.dat", parse_status=None)
        for k in "AB"
    ]
    state, saved, errors, _ = _setup_db(monkeypatch, rows, error_recipies={"A"})
    monkeypatch.setattr(bulk, "parse_item", lambda item, root, cache: {"pixel": "2"})
    monkeypatch.setattr(bulk, "__file__", str(tmp_path / "parse_all_recipes.py"))
    result = bulk.run_bulk_parse(_opts(tmp_path))
    assert (result.success, result.db_failed, result.failed) == (1, 1, 1)
    assert state["A"]["parse_status"] == "failed"
    assert state["B"]["parse_status"] == "success"
    assert [x[0] for x in saved] == ["B"]
    assert len(errors) == 1


def test_dry_run_changes_no_db_rows(monkeypatch, tmp_path):
    """dry-run 모드에서 실제 저장과 상태 갱신을 호출하지 않는다."""
    rows = [dict(recipe_key="A", equip="SMDI01", model="KLA2139", backup_file_path="A.dat", parse_status=None)]
    state, saved, errors, _ = _setup_db(monkeypatch, rows)
    monkeypatch.setattr(bulk, "parse_item", lambda item, root, cache: {"pixel": "0.3"})
    monkeypatch.setattr(bulk, "__file__", str(tmp_path / "parse_all_recipes.py"))
    result = bulk.run_bulk_parse(_opts(tmp_path, "--dry-run"))
    assert result.success == 1
    assert state["A"]["parse_status"] is None
    assert not saved and not errors


def test_only_unfinished_and_active_only_filters(monkeypatch, tmp_path):
    """이미 성공하거나 논리 삭제된 Recipe를 옵션에 따라 제외한다."""
    rows = [
        dict(recipe_key="A", equip="SMDI01", model="KLA2139", backup_file_path="A", parse_status="success", is_remove=False),
        dict(recipe_key="B", equip="SMDI01", model="KLA2139", backup_file_path="B", parse_status="failed", is_remove=False),
        dict(recipe_key="C", equip="SMDI01", model="KLA2139", backup_file_path="C", parse_status=None, is_remove=True),
    ]
    state, saved, errors, _ = _setup_db(monkeypatch, rows)
    monkeypatch.setattr(bulk, "parse_item", lambda item, root, cache: {"mode": "AUTO"})
    monkeypatch.setattr(bulk, "__file__", str(tmp_path / "parse_all_recipes.py"))
    res = bulk.run_bulk_parse(_opts(tmp_path, "--active-only", "--only-unfinished"))
    assert res.scanned == 1
    assert [k for k,_ in saved] == ["B"]
    assert state["A"]["parse_status"] == "success"


def test_parse_item_dispatches_by_database_model(monkeypatch, tmp_path):
    """Parser 선택은 YAML enabled와 무관하게 DB의 model 컬럼을 따른다."""
    invoked = []
    class FakeParser:
        """테스트용 모델 Parser."""
    monkeypatch.setattr(bulk, "PARSERS", {"KLA2139": FakeParser})
    monkeypatch.setattr(bulk, "parse_one", lambda key, path, parser, root: invoked.append(key) or {"pixel": "0.9"})
    row = SimpleNamespace(model="kla2139", recipe_key="A", equip="SMDI01", backup_file_path="/A/ins.dat")
    cache = {}
    assert bulk.parse_item(row, tmp_path, cache) == {"pixel": "0.9"}
    assert bulk.parse_item(row, tmp_path, cache) == {"pixel": "0.9"}
    assert len(cache) == 1
    assert invoked == ["A", "A"]
    with pytest.raises(ValueError, match="지원하지 않는"):
        bulk.parse_item(SimpleNamespace(model="UNKNOWN", recipe_key="B", equip="SMDI01", backup_file_path="x"), tmp_path, cache)


def test_argument_validation():
    """잘못된 배치 크기나 처리 제한 값은 즉시 거부한다."""
    with pytest.raises(SystemExit):
        bulk.parse_arguments(["--batch-size", "0"])
    with pytest.raises(SystemExit):
        bulk.parse_arguments(["--limit", "-1"])
